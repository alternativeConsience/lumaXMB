/* DesktopXMB's temporary response layer. Saved wallpaper controls stay intact. */
(function(root){
 'use strict';
 function createResponse(){
  let state=null,received=-Infinity,speed=1,light=1;
  const result={connected:false,mode:'Disconnected',speed:1,light:1};   // reused each frame
  return {
   accept(value,now){
    if(!value||value.version!==1||!['Full','Orbital','ActiveOrbital','Application','Hidden','SystemUi'].includes(value.mode)||!Number.isFinite(value.activation))return false;
    state=value;received=now;return true;
   },
   sample(now,dt){
    const connected=!!state&&now-received<2000&&state.enabled===true;
    const reactive=connected&&!state.reducedMotion;
    let targetSpeed=1,targetLight=1;
    if(reactive){
     const a=Math.max(0,Math.min(1,state.activation));
     if(state.mode==='Orbital'||state.mode==='ActiveOrbital'){targetSpeed=.65+.95*a;targetLight=.96+.18*a;}
     else if(state.mode==='Full'){targetSpeed=1.12;targetLight=1.08;}
    }
    // Integrate phase in wallpaper.js; changing speed never jumps the wave.
    const k=1-Math.exp(-Math.max(0,Math.min(.1,dt))*4.5);
    speed+=(targetSpeed-speed)*k;light+=(targetLight-light)*k;
    result.connected=connected;result.mode=connected?state.mode:'Disconnected';result.speed=speed;result.light=light;return result;
   }
  };
 }
 if(typeof module==='object'&&module.exports){module.exports={createResponse};return;}
 const response=createResponse();root.desktopXmbResponse=response;
 // Without DesktopXMB running, each probe fails at once; back off to one probe
 // every 15 s rather than one a second forever. A success resets the cadence.
 let stopped=false,misses=0;
 async function poll(){
  if(stopped)return;
  let ok=false;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),700);
  try{const r=await fetch('http://127.0.0.1:18765/state',{cache:'no-store',signal:controller.signal});if(r.ok)ok=response.accept(await r.json(),root.performance.now());}catch(_){}
  finally{clearTimeout(timer);misses=ok?0:Math.min(misses+1,6);if(!stopped)setTimeout(poll,ok?100:Math.min(15000,1000*Math.pow(2,misses-1)));}
 }
 // A manual install has no DesktopXMB companion configured; skip the probe there.
 const bridge=root.XMB_BRIDGE,standalone=!bridge||!bridge.token||/:0\/?$/.test(String(bridge.url||''));
 root.addEventListener('pagehide',()=>{stopped=true;});if(!standalone)poll();
})(typeof window==='object'?window:globalThis);
