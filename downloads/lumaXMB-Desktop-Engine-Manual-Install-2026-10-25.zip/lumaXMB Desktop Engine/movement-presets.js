'use strict';
// Movement presets: how the whole wave sits and moves in the frame, on top of
// its own animation. Choosing one sets the movement sliders together; moving
// any of them afterwards turns the preset to Custom.
//   waveRotation    a fixed turn of the wave, degrees (negative rises to the right)
//   waveSway        a slow rocking either side of that turn, degrees
//   waveBob         a slow rise and fall, 0 to 1
//   waveSwayPeriod  seconds for one sway and float cycle
window.MOVEMENT_PRESETS={
 classic:{label:'Classic (level)',values:{waveRotation:0,waveSway:0,waveBob:0,waveSwayPeriod:30}},
 sway:{label:'Gentle Sway',values:{waveRotation:0,waveSway:2.5,waveBob:.3,waveSwayPeriod:26}},
 float:{label:'Floating',values:{waveRotation:0,waveSway:1,waveBob:.8,waveSwayPeriod:18}},
 diagonal:{label:'Diagonal Rise',values:{waveRotation:-8,waveSway:1,waveBob:.2,waveSwayPeriod:40}},
 descent:{label:'Diagonal Fall',values:{waveRotation:7,waveSway:1,waveBob:.2,waveSwayPeriod:40}},
 pendulum:{label:'Slow Pendulum',values:{waveRotation:0,waveSway:6,waveBob:0,waveSwayPeriod:60}},
 drift:{label:'Tilted Drift',values:{waveRotation:4,waveSway:2.5,waveBob:.45,waveSwayPeriod:34}}
};
window.resolveMovementPresetChange=function(current,values){
 const params=Object.keys(window.MOVEMENT_PRESETS.classic.values);
 const selected=window.MOVEMENT_PRESETS[values.movementPreset];
 if(selected&&!params.some(k=>k in values))return {...selected.values,...values};
 if(!('movementPreset' in values)&&params.some(k=>k in values&&values[k]!==current[k]))return {...values,movementPreset:'custom'};
 return values;
};
