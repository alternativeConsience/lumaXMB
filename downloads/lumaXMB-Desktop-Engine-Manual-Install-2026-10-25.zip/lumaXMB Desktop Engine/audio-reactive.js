'use strict';
// Optional music response. Off by default, and nothing is registered with
// Wallpaper Engine until it is switched on with "Music playing on this PC".
//
// Wallpaper Engine hands the page 128 spectrum values about 30 times a second
// (64 bands for the left channel, then 64 for the right, low to high). They are
// folded into three bands and normalised by a slowly adapting peak, so quiet
// and loud music both read well. Nothing downstream ever follows a raw value:
// every output is an envelope with a soft rise and a slower fall, so the
// wallpaper breathes with the music instead of twitching to it.
//
//   glow     the music's presence; soft rise, unhurried fall (wave light)
//   sparkle  the treble, a little quicker (highlight shine)
//   swell    a slow tide of overall energy (sections of the wave rise and
//            settle, motion and colour flow)
//   bloom    a beat, rounded into a gentle bump that never flashes
//
// Presets for the response sliders live in music-presets.js.
// "Ambient pulse" needs no audio: slow, irregular swells from a few
// incommensurate sines, for movement without music.
//
// wallpaper.js calls sample() once per rendered frame and applies the result.
(() => {
 const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
 const raw={bass:0,mid:0,high:0,left:0,right:0,at:-1e9};
 const peak={bass:.08,mid:.05,high:.03};
 // Besides the shared envelopes (above), each band and the stereo balance get
 // their own: lowSwell (bass, long sections of the wave), ripple (treble, fine
 // shallow ripples) and pan (-1 left … 1 right, where the glow leans).
 const out={bass:0,mid:0,high:0,energy:0,glow:0,sparkle:0,swell:0,bloom:0,beat:0,lowSwell:0,ripple:0,pan:0,onsets:0,active:false,source:'off',frames:0,listening:false};
 let registered=false,beatAverage=0,lastBeat=0,lastSample=0,kick=0;

 function band(values,from,to){
  let sum=0;for(let i=from;i<to;i++)sum+=(values[i]||0)+(values[i+64]||0);
  return sum/(2*(to-from));
 }
 function listen(values){
  if(!values||values.length<128)return;
  raw.bass=band(values,0,6);raw.mid=band(values,6,24);raw.high=band(values,24,64);
  let l=0,r=0;for(let i=0;i<48;i++){l+=values[i]||0;r+=values[i+64]||0;}raw.left=l/48;raw.right=r/48;
  raw.at=performance.now();out.frames++;
 }
 function register(){
  if(registered||typeof window.wallpaperRegisterAudioListener!=='function')return;
  try{window.wallpaperRegisterAudioListener(listen);registered=true;out.listening=true;}catch(e){out.error=String(e);}
 }
 // Exponential follower with separate rise and fall time constants (seconds).
 const follow=(value,target,rise,fall,dt)=>value+(target-value)*(1-Math.exp(-dt/(target>value?rise:fall)));
 function ambient(t){
  const s=(a,b)=>.5+.5*Math.sin(t*a+b);
  const swell=s(.43,0)*.55+s(.71,1.7)*.3+s(1.19,4.1)*.15;
  const beatPhase=(t/2.4)%1;
  return {bass:clamp(swell*.85,0,1),mid:clamp(s(.37,2.2)*.6+swell*.25,0,1),high:clamp(s(.93,.4)*.5,0,1),onset:beatPhase<.02,pan:Math.sin(t*.21)*.6};
 }

 function sample(now,cfg){
  const dt=lastSample?clamp((now-lastSample)/1000,0,.1):0;lastSample=now;
  const enabled=Boolean(cfg.audioEnabled),source=cfg.audioSource==='ambient'?'ambient':'music';
  out.source=enabled?source:'off';
  let target={bass:0,mid:0,high:0},onset=false,pan=0;
  if(enabled&&source==='music'){
   register();
   if(now-raw.at<1200){
    // Adaptive peak: rises at once, falls back over several seconds, with a
    // floor so near-silence is never amplified into noise.
    for(const k of ['bass','mid','high']){
     const floor=k==='bass'?.05:k==='mid'?.03:.02;
     peak[k]=Math.max(raw[k],floor,peak[k]*Math.exp(-dt*.18));
     target[k]=clamp(raw[k]/peak[k],0,1);
    }
    // A bass onset: a jump well above its recent average, at most ~4 per second.
    beatAverage+=(raw.bass-beatAverage)*(1-Math.exp(-dt*3));
    onset=raw.bass>beatAverage*1.35+.02&&now-lastBeat>240;
    // Stereo balance; near silence counts as centred.
    pan=clamp((raw.right-raw.left)/(raw.right+raw.left+.02),-1,1);
   }
  }else if(enabled){
   const a=ambient(now/1000);target={bass:a.bass,mid:a.mid,high:a.high};onset=a.onset&&now-lastBeat>1000;pan=a.pan;
  }
  const gain=clamp(Number(cfg.audioSensitivity)||1,.25,3);
  for(const k of ['bass','mid','high'])target[k]=clamp(Math.pow(target[k],1.25)*gain,0,1.3);
  // Smoothing stretches every envelope: 0 is lively, 1 is a slow glide.
  const s=1+1.6*clamp(Number(cfg.audioSmoothing),0,1);
  for(const k of ['bass','mid','high'])out[k]=follow(out[k],target[k],.05*s,.18*s,dt);
  out.energy=clamp(out.bass*.55+out.mid*.3+out.high*.15,0,1.3);
  // The body of the glow is carried by the mids, where most music lives.
  out.glow=follow(out.glow,clamp(out.bass*.3+out.mid*.5+out.high*.2,0,1.2),.14*s,.75*s,dt);
  out.sparkle=follow(out.sparkle,out.high,.1*s,.45*s,dt);
  out.swell=follow(out.swell,out.energy,.9*s,1.8*s,dt);
  out.lowSwell=follow(out.lowSwell,out.bass,.8*s,1.6*s,dt);
  out.ripple=follow(out.ripple,out.high,.35*s,.9*s,dt);
  out.pan=follow(out.pan,enabled?pan:0,.5*s,.9*s,dt);
  // Beat: an impulse that fades over half a second, followed by a soft bump.
  if(onset){lastBeat=now;kick=1;out.onsets++;}
  kick*=Math.exp(-dt/(.45*s));
  out.bloom=follow(out.bloom,enabled?kick:0,.12*s,.6*s,dt);
  out.beat=kick;
  out.active=enabled&&(out.glow>.002||out.swell>.002||out.bloom>.002);
  return out;
 }
 window.XMBAudio={sample,state:out};
})();
