window.XMB_DISPLAY_LAYOUT={"monitors":[]};
