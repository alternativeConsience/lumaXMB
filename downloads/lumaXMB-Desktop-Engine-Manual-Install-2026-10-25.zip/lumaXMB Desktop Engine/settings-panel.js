'use strict';
(() => {
 const api=window.XMBSettings,schema=window.XMB_SETTINGS_SCHEMA,bridge=window.XMB_BRIDGE;
 if(!api||!schema)return;
 const BUILD='2026-10-26 reset, music, overview';window.XMB_PANEL_BUILD=BUILD;

 // Category order for the PC layout: the look first, system settings last.
 const groups={
  'Wave & glass':['wavePreset','waveFinish','waveTint','waveColor','waveTintStrength','waveAmplitude','waveFrequency','waveDetail','wavePosition','brightness','gloss','glassOpacity','waveIridescence','waveStrands'],
  'Breathing glow':['breatheEnabled','breathePreset','breatheMode','breathePeriod','breatheIntensity','breatheMinimum','breatheWidth','breatheSoftness','breatheRadius','breatheThreshold','breatheTint','breatheColor'],
  'Displays':['spanDisplays','spanGap','spanVerticalOffset'],
  'Motion':['animationPreset','speed','animationStrength','animationDirection','movementPreset','waveRotation','waveSway','waveBob','waveSwayPeriod'],
  'Background':['backgroundMode','backgroundPreset','customBlend','gradientStart','gradientMiddle','gradientEnd','gradientAngle','backgroundExposure','backgroundRotation','backgroundBlackLevel'],
  'Color shifting':['shiftingPreset','shiftingStyle','shiftingVibrance','shiftingBrightness','shiftingSpeed','shiftingStrength','shiftingPeriod','shiftingAngle','shiftingSoftness','shiftingColor1','shiftingColor2','shiftingColor3','shiftingColor4'],
  'Particles':['particlePreset','particleDensity','particleSize','particleSpeed','sparkle','particleTint','particleColor'],
  'Glow & blur':['glow','glowRadius','glowThreshold','glowTint','glowColor','blur','blurQuality'],
  'Line smoothing':['antiAliasing','edgeSoftness','highlightSoftness','highlightIntensity','meshQuality','highlightWidth'],
  'Clock':['clockEnabled','clockTheme','clockStyle','clockTint','clockTintStrength','clockDate','clockHours','clockSize','clockTextSize','clockLetterSpacing','clockGap','clockPadding','clockOpacity','clockBrightness','clockTextBrightness','clockGlowBrightness','clockGlow','clockShimmer','clockShimmerWidth','clockBreath'],
  'Music':['audioEnabled','audioPreset','audioSource','audioSensitivity','audioSmoothing','audioMotion','audioWave','audioGlow','audioBackground','audioColorShift','audioClock'],
  'Performance':['performancePreset','fpsMode','resolution','diagnosticsEnabled','advancedControls'],
  'Menu':['panelTransparency','panelWidth','panelHeight']
 };
 const names={advancedControls:'Sidebar detail group',resolution:'Render scale',fpsMode:'Frame rate target'};
 // XMB-style category icons along the horizontal axis.
 const icons={'Wave & glass':'∿','Breathing glow':'✧','Displays':'▭','Motion':'↻','Background':'▤','Color shifting':'◐','Particles':'✦','Glow & blur':'☼','Line smoothing':'≋','Clock':'◷','Music':'♪','Performance':'⚡','Menu':'☰'};

 const panel=document.createElement('aside');panel.id='xmb-panel';panel.setAttribute('aria-label','Live XMB settings');panel.setAttribute('aria-hidden','true');
 // XMB layout: categories run along a horizontal axis at the top, the chosen
 // category's settings run down the page beneath it, and option lists open as
 // a column beside the list, as on the PS3 system menu. Every element also
 // answers the mouse: click, hover, wheel and drag.
 panel.innerHTML=
  '<header><h1>lumaXMB Desktop Engine™</h1><button type="button" class="close" aria-label="Close settings">×</button></header>'+
  '<div class="layout"><nav class="categories" role="tablist" aria-label="Settings categories"></nav>'+
  '<div class="pane"><input class="search" type="search" placeholder="Find a setting…" aria-label="Find a setting">'+
  '<div class="scroll-shell"><div class="sections" id="xmb-sections" aria-label="Settings"></div>'+
  '<div class="scroll-track" role="scrollbar" aria-controls="xmb-sections" aria-orientation="vertical" aria-label="Settings scrollbar"><div class="scroll-thumb"></div></div></div></div></div>'+
  '<footer><span class="hint" aria-hidden="true"><span><b>Enter</b>Select</span><span><b>Esc</b>Back</span><span><b>↑↓</b>Move</span><span><b>←→</b>Adjust</span></span>'+
  '<span class="metrics" hidden><span class="metric"><strong id="xmb-size">—</strong></span><span class="metric"><strong id="xmb-cadence">—</strong></span><span class="metric"><strong id="xmb-aa">—</strong></span></span><span class="sync" hidden></span>'+
  '<span class="scroll-buttons"><button type="button" class="scroll-up" aria-label="Scroll up">↑</button><button type="button" class="scroll-down" aria-label="Scroll down">↓</button></span>'+
  '<button type="button" class="resize-handle" aria-label="Drag to resize menu" title="Drag to resize">⤢</button></footer>';
 document.body.appendChild(panel);
 const launch=document.createElement('button');launch.type='button';launch.id='xmb-launch';launch.textContent='⚙';launch.title='Live XMB settings (S)';launch.setAttribute('aria-label','Open live XMB settings');launch.setAttribute('aria-expanded','false');launch.setAttribute('aria-controls','xmb-panel');document.body.appendChild(launch);

 const sync=panel.querySelector('.sync'),sections=panel.querySelector('.sections'),nav=panel.querySelector('.categories'),search=panel.querySelector('.search'),pane=panel.querySelector('.pane');
 const track=panel.querySelector('.scroll-track'),thumb=panel.querySelector('.scroll-thumb');
 const rows=new Map(),controls=new Map(),pages=new Map();
 let config=api.get(),pending={},sending=false,sendTimer=0,revision=-1,observed={},observeTimer=0,connected=false;
 let focusedKey=null,wheelEvents=0,bridgeWheelEvents=0,bridgeKeyEvents=0;

 const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
 const number=v=>String(Number(Number(v).toFixed(3)));
 const toHex=v=>'#'+String(v).split(/\s+/).map(n=>Math.round(clamp(Number(n)||0,0,1)*255).toString(16).padStart(2,'0')).join('');
 const toRGB=v=>[1,3,5].map(i=>number(parseInt(v.slice(i,i+2),16)/255)).join(' ');
 const parseRGB=v=>{const rgb=String(v).trim().split(/\s+/).map(Number);return rgb.length===3&&rgb.every(Number.isFinite)?rgb.map(n=>clamp(n,0,1)):null;};
 const cssColor=(rgb,scale=1)=>'rgb('+rgb.map(v=>Math.round(clamp(v*scale,0,1)*255)).join(',')+')';
 const el=(tag,className,text)=>{const e=document.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e;};
 const button=(className,text,label)=>{const b=el('button',className,text);b.type='button';if(label)b.setAttribute('aria-label',label);b.tabIndex=-1;return b;};
 // Visual updates that are not answers to the user's own input (meters, the
 // overview, the menu tint) wait for the wave's next frame, so they land in a
 // frame that is being presented anyway instead of forcing one in between.
 // If the wave is not drawing they go ahead after a quarter of a second.
 const frameQueue=new Set();let frameFallback=0;
 function flushFrameQueue(now){clearTimeout(frameFallback);frameFallback=0;if(!frameQueue.size)return;const jobs=[...frameQueue];frameQueue.clear();for(const job of jobs)try{job(now);}catch(e){}}
 function onNextFrame(job){frameQueue.add(job);if(!frameFallback)frameFallback=setTimeout(()=>flushFrameQueue(performance.now()),250);}
 const frameHooks=window.XMBFrameHooks=window.XMBFrameHooks||[];frameHooks.push(flushFrameQueue);
 // Drags (menu move and resize, sliders) apply their latest value just before
 // the wave's next frame: one update per frame however fast the mouse reports,
 // and the menu, its glass and the wave change together. Jobs are stable
 // functions, so queuing one again within a frame is free.
 const beforeQueue=new Set();let beforeFallback=0;
 function flushBeforeQueue(){clearTimeout(beforeFallback);beforeFallback=0;if(!beforeQueue.size)return;const jobs=[...beforeQueue];beforeQueue.clear();for(const job of jobs)try{job();}catch(e){}}
 function onBeforeFrame(job){beforeQueue.add(job);if(!beforeFallback)beforeFallback=setTimeout(flushBeforeQueue,60);}
 (window.XMBBeforeFrameHooks=window.XMBBeforeFrameHooks||[]).push(flushBeforeQueue);
 // Drags can be driven by two streams on the desktop: the helper's forwarded
 // events (synthetic, isTrusted false) and the host's own mouse events (which
 // may include the press but often not the moves or the release, because the
 // desktop holds the mouse while the button is down). The rules:
 //  - a desktop (synthetic) drag owns the drag: the host's events cannot start
 //    a new one over it, move it, or end it by losing pointer capture;
 //  - a host-started drag ends as soon as a host move reports the button up,
 //    which is how a release the host never delivered shows itself;
 //  - any release ends a drag. A release the hook misses is caught by the
 //    helper, which checks the button on every move.
 const foreignTo=(syntheticDrag,e)=>syntheticDrag&&e.isTrusted;
 const hostReleased=(syntheticDrag,e)=>!syntheticDrag&&e.isTrusted&&e.pointerType==='mouse'&&e.buttons===0;
 const blockedStart=(activeSynthetic,e)=>activeSynthetic&&e.isTrusted;

 // Preview swatches. The static shader writes preset colours directly, so a CSS
 // gradient with the same stops matches the desktop; angle 90 runs top to bottom.
 const gradientCSS=(stops,angle)=>'linear-gradient('+(Number(angle)+90)+'deg,'+stops.join(',')+')';
 function backgroundSwatch(value,cfg){
  if(value==='custom'){
   const s=parseRGB(cfg.gradientStart)||[0,0,0],m=parseRGB(cfg.gradientMiddle)||[0,0,0],e=parseRGB(cfg.gradientEnd)||[0,0,0];
   return gradientCSS(cfg.customBlend==='two'?[cssColor(s),cssColor(e)]:[cssColor(s),cssColor(m),cssColor(e)],Number(cfg.gradientAngle)||90);
  }
  const p=window.BACKGROUND_PRESETS&&window.BACKGROUND_PRESETS[value];if(!p)return null;
  if(p.blackFloor){const bp=Math.round(clamp(p.blackPoint||0,0,.85)*100);return gradientCSS(['#000 0%','#000 '+bp+'%',cssColor(p.end)+' 100%'],p.angle);}
  return gradientCSS(p.twoTone?[cssColor(p.start),cssColor(p.end)]:[cssColor(p.start),cssColor(p.middle),cssColor(p.end)],p.angle);
 }
 function shiftingSwatch(value,cfg){
  let colors,angle,blackFloor=false,blackPoint=0;
  if(value==='custom'){colors=[1,2,3,4].map(i=>parseRGB(cfg['shiftingColor'+i])||[.03,.08,.25]);angle=Number(cfg.shiftingAngle)||90;}
  else{const p=window.ANIMATED_BACKGROUND_PRESETS&&window.ANIMATED_BACKGROUND_PRESETS[value];if(!p)return null;colors=p.colors;angle=p.angle;blackFloor=p.blackFloor;blackPoint=p.blackPoint||0;}
  // The animated shader lifts its palette from a dark base to a .9 peak; show the
  // four cycle colours along that ramp.
  const levels=[.12,.31,.6,.9],base=blackFloor?Math.round(clamp(blackPoint,0,.85)*100):0;
  const stops=colors.map((c,i)=>cssColor(c,levels[i])+' '+Math.round(base+(100-base)*i/(colors.length-1))+'%');
  return gradientCSS(blackFloor?['#000 0%','#000 '+base+'%',...stops]:stops,angle);
 }
 const tintColors={warm:[1,.68,.32],ice:[.27,.66,1],violet:[.64,.3,1],rose:[1,.3,.52]};
 const paletteSwatch=cfg=>cfg.backgroundMode==='shifting'?shiftingSwatch(cfg.shiftingPreset,cfg):backgroundSwatch(cfg.backgroundPreset,cfg);
 function swatchFor(key,value,cfg){
  switch(key){
   case 'backgroundPreset':return backgroundSwatch(value,cfg);
   case 'shiftingPreset':return shiftingSwatch(value,cfg);
   case 'waveTint':
    if(value==='silver')return 'linear-gradient(90deg,rgb(128,138,158),rgb(236,240,250))';
    if(value==='palette')return paletteSwatch(cfg);
    if(value==='custom')return cssColor(parseRGB(cfg.waveColor)||[.25,.65,1]);
    return tintColors[value]?cssColor(tintColors[value]):null;
   case 'breatheTint':
    if(value==='wave')return swatchFor('waveTint',cfg.waveTint,cfg);
    if(value==='palette')return paletteSwatch(cfg);
    if(value==='silver')return cssColor([.72,.84,1]);
    if(value==='custom')return cssColor(parseRGB(cfg.breatheColor)||[.3,.65,1]);
    return null;
   case 'glowTint':case 'particleTint':{
    const own=key==='glowTint'?cfg.glowColor:cfg.particleColor;
    if(value==='palette')return paletteSwatch(cfg);
    if(value==='silver')return cssColor([.85,.91,1]);
    if(value==='warm')return cssColor([1,.77,.5]);
    if(value==='custom')return cssColor(parseRGB(own)||[.7,.85,1]);
    return null;
   }
   case 'breathePreset':{
    const p=window.BREATHING_GLOW_PRESETS&&window.BREATHING_GLOW_PRESETS[value];
    if(!p)return value==='custom'?swatchFor('breatheTint',cfg.breatheTint,cfg):null;
    return swatchFor('breatheTint',p.values.breatheTint,{...cfg,breatheColor:p.values.breatheColor});
   }
   case 'clockTint':
    if(value==='palette')return paletteSwatch(cfg);
    if(value==='wave')return swatchFor('waveTint',cfg.waveTint,cfg);
    return 'linear-gradient(90deg,#e4ecf5,#ffffff)';
   case 'clockTheme':{
    // A theme's swatch shows the clock colour it brings; the background is untouched.
    const theme=window.CLOCK_THEMES&&window.CLOCK_THEMES[value];
    if(!theme)return value==='custom'?swatchFor('clockTint',cfg.clockTint,cfg):null;
    return swatchFor('clockTint',theme.clock.clockTint,cfg);
   }
   default:return null;
  }
 }
 // Long preset lists get group headings so the keyboard can run through one family.
 function groupOf(key,option){
  if(key==='backgroundPreset'){const i=option.label.indexOf(' — ');return i>0?option.label.slice(0,i):'Other';}
  if(key==='shiftingPreset')return option.value==='custom'?'Custom':option.label.startsWith('OLED — ')?'OLED':'Palettes';
  return null;
 }
 function optionLabel(key,option){
  if(key==='backgroundPreset'){const i=option.label.indexOf(' — ');return i>0?option.label.slice(i+3):option.label;}
  if(key==='shiftingPreset'&&option.label.startsWith('OLED — '))return option.label.slice(7);
  return option.label;
 }

 // The performance controls show the values a profile actually applies.
 function read(key){
  const cfg=api.get(),value=cfg[key];
  if(!['glow','blur','resolution','fpsMode'].includes(key))return value;
  const effective=window.resolvePerformanceSettings(cfg);
  return key==='glow'?effective.glow:key==='blur'?effective.blur:key==='resolution'?effective.resolution:String(effective.fps);
 }

 // Press-and-hold repeat for step and scroll buttons; the keyboard activates them too.
 function holdRepeat(target,action){
  // A repeat never outlives 3 s, so a release the desktop host fails to deliver
  // cannot leave a control stepping on its own.
  let timer=0,interval=0,repeats=0;
  const stop=()=>{clearTimeout(timer);clearInterval(interval);timer=0;interval=0;};
  target.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();action();stop();repeats=0;timer=setTimeout(()=>{interval=setInterval(()=>{if(++repeats>48){stop();return;}action();},55);},380);});
  for(const type of ['pointerup','pointercancel','pointerleave'])target.addEventListener(type,stop);
  target.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){action();e.preventDefault();e.stopPropagation();}});
 }

 // A slider drawn by the page: a click anywhere on the track sets the value, the
 // thumb drags with pointer capture, and the step buttons nudge by one step.
 function makeSlider({min,max,step,label,get,set,format}){
  const root=el('div','slider');
  const down=button('slider-step down','−',label+': decrease'),up=button('slider-step up','+',label+': increase');
  const trackEl=el('div','slider-track');trackEl.setAttribute('role','slider');trackEl.tabIndex=-1;trackEl.setAttribute('aria-label',label);trackEl.setAttribute('aria-valuemin',String(min));trackEl.setAttribute('aria-valuemax',String(max));
  const fill=el('div','slider-fill'),knob=el('div','slider-thumb');trackEl.append(fill,knob);
  const out=el('output');root.append(down,trackEl,up,out);
  const decimals=Math.max(0,(String(step).split('.')[1]||'').length);
  const snap=v=>Number(clamp(Math.round((clamp(v,min,max)-min)/step)*step+min,min,max).toFixed(Math.max(decimals,3)));
  const fromPointer=e=>{const r=trackEl.getBoundingClientRect();return snap(min+(max-min)*clamp((e.clientX-r.left)/Math.max(1,r.width),0,1));};
  let dragging=false,synthetic=false,pendingValue=null;
  const applyPending=()=>{if(pendingValue===null)return;const v=pendingValue;pendingValue=null;if(v!==get())set(v);};
  trackEl.addEventListener('pointerdown',e=>{if(e.button!==0||blockedStart(dragging&&synthetic,e))return;e.preventDefault();dragging=true;synthetic=!e.isTrusted;trackEl.classList.add('dragging');if(!synthetic)try{trackEl.setPointerCapture(e.pointerId);}catch(_){}set(fromPointer(e));});
  trackEl.addEventListener('pointermove',e=>{if(!dragging||foreignTo(synthetic,e))return;if(hostReleased(synthetic,e)){end();return;}pendingValue=fromPointer(e);onBeforeFrame(applyPending);});
  const end=()=>{if(dragging)applyPending();dragging=false;trackEl.classList.remove('dragging');};
  for(const type of ['pointerup','pointercancel'])trackEl.addEventListener(type,end);
  trackEl.addEventListener('lostpointercapture',()=>{if(!synthetic)end();});
  const nudge=(dir,big)=>set(snap(get()+dir*step*(big?10:1)));
  holdRepeat(down,()=>nudge(-1));holdRepeat(up,()=>nudge(1));
  function paint(){
   const v=get(),pct=clamp((v-min)/(max-min)*100,0,100);
   fill.style.width=pct+'%';knob.style.left=pct+'%';out.value=format?format(v):number(v);
   trackEl.setAttribute('aria-valuenow',String(v));trackEl.setAttribute('aria-valuetext',out.value);
  }
  return {el:root,focusTarget:trackEl,paint,horizontal(dir,big){nudge(dir,big);return true;}};
 }

 // Option picker drawn in the page: CEF's native select can terminate the renderer.
 // The list opens inline below its button, so it is never clipped by the scroll
 // area; Up/Down preview each option live, Enter keeps it and Escape restores.
 function makePicker(key,spec){
  const label=names[key]||spec.text;
  const root=el('div','picker-wrap');
  const toggleButton=button('picker',undefined,label);toggleButton.setAttribute('aria-haspopup','listbox');toggleButton.setAttribute('aria-expanded','false');
  const swatch=el('span','swatch'),text=el('span','picker-label'),chevron=el('span','chevron','⌄');toggleButton.append(swatch,text,chevron);
  // The option column lives in the pane, beside the list, so it is never clipped
  // by the scrolling list and can stand as tall as the pane allows.
  const menu=el('div','picker-menu');menu.hidden=true;menu.setAttribute('role','listbox');menu.id='xmb-options-'+key;toggleButton.setAttribute('aria-controls',menu.id);menu.dataset.key=key;
  menu.appendChild(el('div','picker-title',label));
  root.append(toggleButton);pane.appendChild(menu);
  const options=[];let lastGroup=null,openValue=null,highlight=-1;
  for(const o of spec.options){
   const group=groupOf(key,o);
   if(group!==null&&group!==lastGroup){menu.appendChild(el('div','picker-group',group));lastGroup=group;}
   const item=button('option',undefined);item.dataset.value=o.value;item.setAttribute('role','option');
   const itemSwatch=el('span','swatch');item.append(itemSwatch,el('span','option-label',optionLabel(key,o)));
   item.addEventListener('click',()=>{apply(o.value);close(true);});
   menu.appendChild(item);options.push({value:o.value,label:o.label,item,swatch:itemSwatch});
  }
  const current=()=>read(key),indexOf=v=>options.findIndex(o=>o.value===v);
  const apply=v=>change({[key]:v});
  function setHighlight(i,scroll=true){
   highlight=clamp(i,0,options.length-1);
   options.forEach((o,j)=>o.item.classList.toggle('highlight',j===highlight));
   if(scroll&&options[highlight])options[highlight].item.scrollIntoView({block:'nearest'});
  }
  function paint(){
   const v=current(),cfg=api.get(),chosen=spec.options.find(o=>o.value===v);
   text.textContent=chosen?chosen.label:String(v);
   const s=swatchFor(key,v,cfg);swatch.hidden=!s;if(s)swatch.style.background=s;root.classList.toggle('has-swatch',Boolean(s));
   for(const o of options){
    const selected=o.value===v;o.item.setAttribute('aria-selected',String(selected));o.item.classList.toggle('selected',selected);
    const os=swatchFor(key,o.value,cfg);o.swatch.hidden=!os;if(os)o.swatch.style.background=os;
   }
   if(!menu.hidden)setHighlight(indexOf(v),false);
  }
  // The column sits level with its row, clamped inside the pane.
  function position(){
   const paneRect=pane.getBoundingClientRect(),row=root.closest('.control'),rowRect=row.getBoundingClientRect();
   const maxHeight=Math.max(120,paneRect.height-16);menu.style.maxHeight=maxHeight+'px';
   const height=Math.min(menu.offsetHeight||maxHeight,maxHeight);
   menu.style.top=Math.max(8,Math.min(rowRect.top-paneRect.top,paneRect.height-8-height))+'px';
  }
  function open(){
   closeOpenControls();openValue=current();menu.hidden=false;toggleButton.setAttribute('aria-expanded','true');root.classList.add('open');
   const row=root.closest('.control');if(row)row.classList.add('expanded');panel.classList.add('choosing');openPicker={position,close};
   ensureVisible(row);position();setHighlight(indexOf(openValue),false);
   requestAnimationFrame(()=>{if(options[highlight])options[highlight].item.scrollIntoView({block:'center'});position();});
  }
  function close(commit){
   if(menu.hidden)return;
   if(!commit&&openValue!==null&&openValue!==current())apply(openValue);
   menu.hidden=true;toggleButton.setAttribute('aria-expanded','false');root.classList.remove('open');root.closest('.control')?.classList.remove('expanded');panel.classList.remove('choosing');openPicker=null;openValue=null;
   toggleButton.focus({preventScroll:true});
  }
  toggleButton.addEventListener('click',()=>menu.hidden?open():close(true));
  function move(dir){const i=indexOf(current()),n=clamp(i+dir,0,options.length-1);if(n!==i)apply(options[n].value);if(!menu.hidden)setHighlight(n);return true;}
  return {el:root,focusTarget:toggleButton,paint,
   isOpen:()=>!menu.hidden,
   vertical:dir=>menu.hidden?false:move(dir),
   horizontal:dir=>move(dir),
   page:dir=>menu.hidden?false:move(dir*5),
   jump(dir){if(menu.hidden)return false;const n=dir<0?0:options.length-1;apply(options[n].value);setHighlight(n);return true;},
   activate(){menu.hidden?open():close(true);},
   escape(){if(menu.hidden)return false;close(false);return true;},
   typeahead(ch){
    if(menu.hidden)return false;const start=indexOf(current()),c=ch.toLowerCase();
    for(let k=1;k<=options.length;k++){const o=options[(start+k)%options.length];if(optionLabel(key,{value:o.value,label:o.label}).toLowerCase().startsWith(c)){apply(o.value);setHighlight((start+k)%options.length);return true;}}
    return true;
   },
   close:()=>close(true)
  };
 }

 function makeToggle(key,spec){
  const b=button('switch',undefined,names[key]||spec.text);b.setAttribute('role','switch');
  const knob=el('span','knob'),state=el('span','switch-text');b.append(knob,state);
  const flip=()=>{change({[key]:!api.get()[key]});return true;};
  b.addEventListener('click',flip);
  return {el:b,focusTarget:b,paint(){const on=Boolean(api.get()[key]);b.setAttribute('aria-checked',String(on));b.classList.toggle('on',on);state.textContent=on?'On':'Off';},horizontal:flip,activate:flip};
 }

 // Colours are edited in the page as well: a swatch button opens three channel
 // sliders and a hex field. Up/Down choose the channel, Left/Right adjust it.
 function makeColor(key,spec){
  const label=names[key]||spec.text;
  const root=el('div','color-control');
  const toggleButton=button('color-button',undefined,label+' colour');toggleButton.setAttribute('aria-expanded','false');
  const swatch=el('span','swatch'),hexText=el('span','color-hex');toggleButton.append(swatch,hexText);
  const editor=el('div','color-editor');editor.hidden=true;
  let active=-1;
  const channels=['Red','Green','Blue'].map((name,i)=>{
   const row=el('div','channel');row.appendChild(el('span','channel-name',name[0]));
   const slider=makeSlider({min:0,max:255,step:1,label:label+' '+name,format:v=>String(v),
    get:()=>Math.round((parseRGB(api.get()[key])||[0,0,0])[i]*255),
    set:v=>{const rgb=parseRGB(api.get()[key])||[0,0,0];rgb[i]=v/255;change({[key]:rgb.map(number).join(' ')});}});
   row.appendChild(slider.el);editor.appendChild(row);
   row.addEventListener('pointerdown',()=>setActive(i));
   return {row,slider};
  });
  const hexInput=el('input','hex-input');hexInput.type='text';hexInput.placeholder='#RRGGBB';hexInput.setAttribute('aria-label',label+' hex or RGB values');hexInput.title='Enter #RRGGBB or three RGB values from 0 to 1';hexInput.tabIndex=-1;editor.appendChild(hexInput);
  hexInput.addEventListener('change',()=>{
   const raw=hexInput.value.trim(),hex=/^#?[0-9a-f]{6}$/i.test(raw),rgb=hex?toRGB('#'+raw.replace(/^#/,'')):raw,values=rgb.split(/\s+/).map(Number);
   if(values.length===3&&values.every(v=>Number.isFinite(v)&&v>=0&&v<=1)){hexInput.removeAttribute('aria-invalid');change({[key]:values.map(number).join(' ')});}
   else hexInput.setAttribute('aria-invalid','true');
  });
  root.append(toggleButton,editor);
  function setActive(i){active=i;channels.forEach((c,j)=>c.row.classList.toggle('active',j===i));}
  function paint(){
   const hex=toHex(api.get()[key]);swatch.style.background=hex;hexText.textContent=hex.toUpperCase();
   if(document.activeElement!==hexInput)hexInput.value=hex.toUpperCase();
   for(const c of channels)c.slider.paint();
  }
  function setOpenState(open){
   if(open)closeOpenControls();
   editor.hidden=!open;toggleButton.setAttribute('aria-expanded',String(open));root.classList.toggle('open',open);root.closest('.control')?.classList.toggle('expanded',open);setActive(open?0:-1);
   if(open)requestAnimationFrame(()=>{ensureVisible(root,editor);updateScrollThumb();});else requestAnimationFrame(updateScrollThumb);
  }
  toggleButton.addEventListener('click',()=>setOpenState(editor.hidden));
  return {el:root,focusTarget:toggleButton,paint,
   isOpen:()=>!editor.hidden,
   vertical(dir){if(editor.hidden)return false;const n=active+dir;if(n<0||n>2)return false;setActive(n);return true;},
   horizontal(dir,big){if(editor.hidden)return false;channels[Math.max(0,active)].slider.horizontal(dir,big);return true;},
   activate(){setOpenState(editor.hidden);},
   escape(){if(editor.hidden)return false;setOpenState(false);return true;},
   close:()=>setOpenState(false)
  };
 }

 let openPicker=null;const modeNotes=new Map();
 function closeOpenControls(){for(const c of controls.values())if(c.isOpen&&c.isOpen()&&c.close)c.close();}

 // Reset. Every row carries a small ↺ that returns it to its default, the
 // value the package ships with (defaults.js, written when the package is
 // built; project.json cannot serve, as the helper writes live values into it).
 // It rests faint at the default and wakes once the setting has been changed.
 // Delete resets the current row from the keyboard, and each page ends with a
 // two-press "reset page".
 const resets=new Map(),pageResets=new Map(),shipped=window.XMB_DEFAULTS||{};
 const defaultOf=key=>key in shipped?shipped[key]:schema[key].value;
 function isDefault(key){
  const spec=schema[key],value=api.get()[key],def=defaultOf(key);
  if(spec.type==='slider')return Math.abs(Number(value)-Number(def))<1e-6;
  if(spec.type==='color'){const a=parseRGB(value),b=parseRGB(def);return Boolean(a&&b)&&a.every((v,i)=>Math.abs(v-b[i])<1/510);}
  if(spec.type==='bool')return Boolean(value)===Boolean(def);
  return String(value)===String(def);
 }
 function resetKeys(keys){
  const values={};for(const k of keys)if(schema[k]&&schema[k].type!=='text'&&!isDefault(k))values[k]=defaultOf(k);
  if(!Object.keys(values).length)return false;
  closeOpenControls();change(values);return true;
 }

 // Performance overview: six live figures and a one-minute frame-rate trace.
 // It samples once a second in the background (a counter read) and draws only
 // while the Performance page is on screen, twice a second.
 const overview=(()=>{
  const root=el('div','perf-overview'),graph=el('canvas','perf-graph'),tiles={};
  graph.setAttribute('aria-hidden','true');root.appendChild(graph);
  const grid=el('div','perf-tiles');root.appendChild(grid);
  // Per-display usage: the frame's measured cost split by the pixels each
  // display actually draws (paused displays still draw; off displays do not).
  // An estimate, and labelled as one: a page cannot time one display's GPU work.
  const perDisplay=el('div','perf-displays');root.appendChild(perDisplay);let displaySig='';const displayRows=new Map();
  for(const [id,label] of [['fps','frame rate'],['pacing','frame pacing'],['cpu','cpu per frame'],['size','render size'],['aa','anti-aliasing'],['layers','active layers']]){
   const t=el('div','perf-tile'),v=el('strong','perf-value','—');t.append(v,el('span','perf-label',label));grid.appendChild(t);tiles[id]=v;
  }
  const history=[];let frames=window.waveStatus.frames,time=performance.now(),timer=0,lastDropped=0;
  const shown=()=>Boolean(api.get().settingsPanel)&&root.offsetParent!==null;
  function take(){
   const s=window.waveStatus,now=performance.now(),fps=(s.frames-frames)*1000/Math.max(1,now-time);frames=s.frames;time=now;
   if(!s.paused)history.push({t:now,fps});while(history.length&&now-history[0].t>60000)history.shift();
   const f=s.frameStats||{},n=f.count||0;
   const stats={fps:s.paused?0:fps,target:s.targetFps||60,avg:n?f.intervalSum/n:0,max:f.intervalMax||0,cpu:n?f.cpuSum/n:0,cpuMax:f.cpuMax||0};
   if(s.frameStats)Object.assign(s.frameStats,{count:0,intervalSum:0,intervalMax:0,cpuSum:0,cpuMax:0});
   return stats;
  }
  function layers(){
   const c=api.get(),s=window.waveStatus,list=['wave',c.backgroundMode==='shifting'?'shifting background':'gradient'];
   if(s.particleCount>0)list.push(s.particleCount+' particles');
   const perf=s.performance||{};if(perf.glow>0)list.push('glow');if(perf.blur>0)list.push('blur');
   if(c.breatheEnabled)list.push('breathing');if(c.clockEnabled)list.push('clock');if(c.audioEnabled)list.push('music');
   if(window.XMBGlass&&window.XMBGlass.stats.active)list.push('menu glass');
   return list.join(' · ');
  }
  function draw(){
   const dpr=window.devicePixelRatio||1,w=Math.max(1,Math.round(graph.clientWidth*dpr)),h=Math.max(1,Math.round(graph.clientHeight*dpr));
   if(graph.width!==w||graph.height!==h){graph.width=w;graph.height=h;}
   const g=graph.getContext('2d');g.clearRect(0,0,w,h);if(history.length<2)return;
   const target=window.waveStatus.targetFps||60,top=target*1.15,now=history[history.length-1].t;
   const x=t=>w-(now-t)/60000*w,y=v=>h-Math.min(1,v/top)*(h-2*dpr)-dpr;
   g.strokeStyle='rgba(220,232,248,.14)';g.lineWidth=dpr;g.setLineDash([3*dpr,4*dpr]);g.beginPath();g.moveTo(0,y(target));g.lineTo(w,y(target));g.stroke();g.setLineDash([]);
   const fill=g.createLinearGradient(0,0,0,h);fill.addColorStop(0,'rgba(200,220,250,.16)');fill.addColorStop(1,'rgba(200,220,250,0)');
   g.beginPath();history.forEach((p,i)=>i?g.lineTo(x(p.t),y(p.fps)):g.moveTo(x(p.t),y(p.fps)));
   g.strokeStyle='rgba(225,236,250,.62)';g.lineWidth=1.25*dpr;g.lineJoin='round';g.stroke();
   g.lineTo(x(now),h);g.lineTo(x(history[0].t),h);g.closePath();g.fillStyle=fill;g.fill();
  }
  function paintTiles(st){
   const s=window.waveStatus,size=s.fullRenderSize||s.backgroundRenderSize||[0,0],e=s.effects||{};
   tiles.fps.textContent=s.paused?'paused':Math.round(st.fps)+' / '+st.target;
   // Pacing: the refresh lock (every n-th refresh of the display) and whether
   // any refresh was missed since the last look.
   const p=s.pacing,missed=p?p.dropped-lastDropped:0;if(p)lastDropped=p.dropped;
   tiles.pacing.textContent=p&&p.refreshHz?Math.round(p.lockedFps)+' fps · 1:'+p.divisor+' of '+Math.round(p.refreshHz)+' hz · '+(missed>0?missed+' missed':'steady'):st.avg?st.avg.toFixed(1)+' ms':'—';
   // Load: the share of each frame's time budget spent preparing the frame.
   const load=st.cpu?st.cpu/(1000/st.target)*100:0;
   tiles.cpu.textContent=st.cpu?st.cpu.toFixed(2)+' ms · '+(load<10?load.toFixed(1):Math.round(load))+'%':'—';
   paintDisplays(load);
   tiles.size.textContent=size.join('×')+(s.resolution&&s.resolution<1?' @ '+Math.round(s.resolution*100)+'%':'');
   tiles.aa.textContent=e.warning?'unavailable':e.sceneSamples?e.sceneSamples+'× msaa':s.antialiasSamples?s.antialiasSamples+'× msaa':'off';
   tiles.layers.textContent=layers();
  }
  function paintDisplays(load){
   const span=window.XMB_SPAN,views=span&&span.active&&span.views?span.views:null;
   const self=window.XMBMonitorState&&window.XMBMonitorState.self||'on';
   const list=views?views.map(v=>({key:v.key,name:v.name,state:v.state||'on',area:v.viewport[2]*v.viewport[3]})):[{key:'self',name:'this display',state:self,area:1}];
   const drawn=list.reduce((sum,d)=>sum+(d.state==='off'?0:d.area),0)||1;
   const sig=list.map(d=>d.key+d.name).join('|');
   if(sig!==displaySig){
    displaySig=sig;perDisplay.textContent='';displayRows.clear();
    perDisplay.appendChild(el('div','perf-displays-title','usage by display · estimated from drawn pixels'));
    for(const d of list){
     const row=el('div','perf-display'),name=el('span','perf-display-name',d.name),bar=el('span','perf-display-bar'),fill=el('i'),value=el('span','perf-display-value','—');
     bar.appendChild(fill);row.append(name,bar,value);perDisplay.appendChild(row);displayRows.set(d.key,{row,fill,value});
    }
   }
   for(const d of list){
    const r=displayRows.get(d.key);if(!r)continue;
    const pct=d.state==='off'?0:load*d.area/drawn;
    r.fill.style.transform='scaleX('+Math.min(1,pct/Math.max(5,load||5)).toFixed(3)+')';
    r.value.textContent=d.state==='off'?'off':(pct<10?pct.toFixed(1):Math.round(pct))+'%'+(d.state==='paused'?' · paused':'');
    r.row.classList.toggle('dimmed',d.state!=='on');
   }
  }
  function tick(){
   const visibleNow=shown(),st=take();
   if(visibleNow)onNextFrame(()=>{paintTiles(st);draw();});
   timer=setTimeout(tick,visibleNow?500:1000);
  }
  timer=setTimeout(tick,1000);
  return {el:root,wake(){if(shown()){clearTimeout(timer);timer=setTimeout(tick,60);}}};
 })();

 // Music meter: shows whether audio is arriving and how the three bands move,
 // so the response can be tuned by eye. Runs only while the Music page is shown.
 const meter=(()=>{
  const root=el('div','music-meter'),text=el('span','music-status'),bars=el('span','music-bars'),parts={};
  for(const k of ['bass','mid','high','beat']){const b=el('span','music-bar '+k);b.appendChild(el('i'));b.title=k;bars.appendChild(b);parts[k]=b.firstChild;}
  // Left/right balance: a dot on a short track, centred when both channels match.
  const balance=el('span','music-balance'),dot=el('i');balance.title='left / right';balance.appendChild(dot);
  root.append(text,balance,bars);let active=false,lastPaint=0;
  function status(){
   const c=api.get(),a=window.XMBAudio&&window.XMBAudio.state;
   if(!c.audioEnabled)return 'off · switch on to let the wave and glow follow music';
   if(c.audioSource==='ambient')return 'ambient pulse · no audio needed';
   if(typeof window.wallpaperRegisterAudioListener!=='function')return 'music is heard inside wallpaper engine only';
   return a&&a.frames&&a.energy>.01?'listening':'waiting for audio · play something';
  }
  // Painted from the wave's frames, about 30 times a second, while shown.
  frameHooks.push(now=>{
   if(!active||now-lastPaint<31)return;lastPaint=now;
   if(!api.get().settingsPanel||root.offsetParent===null){active=false;return;}
   const a=window.XMBAudio&&window.XMBAudio.state||{},label=status();if(text.textContent!==label)text.textContent=label;
   for(const k of ['bass','mid','high','beat'])parts[k].style.transform='scaleY('+Math.min(1,Math.max(.04,a[k]||0)).toFixed(3)+')';
   dot.style.transform='translateX('+(Math.max(-1,Math.min(1,a.pan||0))*13).toFixed(1)+'px)';
  });
  return {el:root,wake(){active=true;}};
 })();

 // Displays: each monitor the wave covers can be on, paused (its wave and
 // colour hold still) or off (black, not drawn). A wallpaper placed on one
 // display offers the same choice for that display alone.
 const displayList=(()=>{
  const root=el('div','display-list');let signature='';
  function parse(){const map={};for(const part of String(api.get().displayStates||'').split(';')){const [k,v]=part.split('=').map(x=>(x||'').trim());if(k&&(v==='paused'||v==='off'))map[k]=v;}return map;}
  function set(key,state){const map=parse();if(state==='on')delete map[key];else map[key]=state;change({displayStates:Object.entries(map).map(([k,v])=>k+'='+v).join(';')});}
  function entries(){
   const span=window.XMB_SPAN;
   if(span&&span.active&&span.views)return span.views.map(v=>({key:v.key,name:v.name,detail:v.rect?v.rect[2]+'×'+v.rect[3]:'',primary:v.primary}));
   return [{key:'self',name:'this display',detail:'',primary:false}];
  }
  function paint(){
   const list=entries(),map=parse(),sig=JSON.stringify([list,map]);if(sig===signature)return;signature=sig;
   root.textContent='';
   const head=el('div','display-head');head.appendChild(el('span','display-title','displays'));
   const reset=button('reset display-reset','↺','Turn every display back on');reset.title='All displays on';reset.disabled=!Object.keys(map).length;reset.tabIndex=0;
   reset.addEventListener('click',()=>resetKeys(['displayStates']));head.appendChild(reset);root.appendChild(head);
   for(const d of list){
    const row=el('div','display-row'),info=el('span','display-name',d.name);
    if(d.primary)info.appendChild(el('span','display-tag','main'));
    if(d.detail)info.appendChild(el('span','display-detail',d.detail));
    const current=map[d.key]||'on',seg=el('span','display-seg');seg.setAttribute('role','radiogroup');seg.setAttribute('aria-label',d.name);
    for(const [state,label] of [['on','on'],['paused','pause'],['off','off']]){
     const b=button('seg'+(current===state?' active':''),label,d.name+': '+label);b.setAttribute('role','radio');b.setAttribute('aria-checked',String(current===state));b.tabIndex=0;
     b.addEventListener('click',()=>set(d.key,state));seg.appendChild(b);
    }
    row.classList.toggle('dimmed',current!=='on');row.append(info,seg);root.appendChild(row);
   }
  }
  return {el:root,paint};
 })();

 // Build the sidebar and pages.
 let activePage=(()=>{try{const v=localStorage.getItem('xmb-panel-page');return v&&groups[v]?v:Object.keys(groups)[0];}catch(e){return Object.keys(groups)[0];}})();
 function selectPage(title,focus='row'){
  const all=Object.keys(groups),from=all.indexOf(activePage),to=all.indexOf(title);
  activePage=title;try{localStorage.setItem('xmb-panel-page',title);}catch(e){}
  if(search.value)search.value='';
  closeOpenControls();sections.scrollTop=0;filter();
  // The new page glides in from the side of the category it came from,
  // clearing from a soft blur, as one pane of glass slides over another.
  const page=pages.get(title);
  if(page&&from!==to&&!reducedMotion()){page.classList.remove('enter-l','enter-r');void page.offsetWidth;page.classList.add(to>from?'enter-r':'enter-l');}updateScrollThumb();requestAnimationFrame(()=>{updateScrollThumb();overview.wake();meter.wake();});
  const tab=nav.querySelector('[data-title="'+CSS.escape(title)+'"]');
  if(tab)tab.scrollIntoView({inline:'nearest',block:'nearest',behavior:reducedMotion()?'auto':'smooth'});
  if(focus==='tab')tab?.focus({preventScroll:true});
  else if(focus==='row'){const first=visibleRows()[0];if(first)setFocus(first.dataset.key,{element:true});}
 }
 const reducedMotion=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 for(const [title,keys] of Object.entries(groups)){
  const page=el('section','page');page.dataset.title=title;page.appendChild(el('h2',undefined,title));sections.appendChild(page);pages.set(title,page);
  const tab=button('category',undefined,title);tab.dataset.title=title;tab.setAttribute('role','tab');
  tab.append(el('span','icon',icons[title]||'◇'),el('span','name',title));
  tab.addEventListener('click',()=>selectPage(title,'tab'));
  nav.appendChild(tab);
  for(const key of keys){
   const spec=schema[key];if(!spec)continue;
   const row=el('div','control');row.dataset.key=key;row.dataset.label=(names[key]||spec.text).toLowerCase();page.appendChild(row);rows.set(key,row);
   const label=el('label',undefined,names[key]||spec.text);label.htmlFor='xmb-'+key;row.appendChild(label);
   const field=el('div','field');row.appendChild(field);
   let control;
   if(spec.type==='combo')control=makePicker(key,spec);
   else if(spec.type==='slider'){field.classList.add('slider-field');control=makeSlider({min:Number(spec.min),max:Number(spec.max),step:Number(spec.step)||1,label:names[key]||spec.text,get:()=>Number(read(key)),set:v=>change({[key]:v})});}
   else if(spec.type==='bool'){row.classList.add('toggle');control=makeToggle(key,spec);}
   else if(spec.type==='color')control=makeColor(key,spec);
   else continue;
   control.focusTarget.id='xmb-'+key;control.key=key;field.appendChild(control.el);controls.set(key,control);
   const reset=button('reset','↺','Reset '+(names[key]||spec.text)+' to default');reset.title='Reset to default';
   reset.addEventListener('click',e=>{e.stopPropagation();resetKeys([key]);});
   row.appendChild(reset);resets.set(key,reset);
   // Any click inside a row makes it the keyboard's current row.
   row.addEventListener('pointerdown',()=>setFocus(key,{element:false,scroll:false}));
   control.focusTarget.addEventListener('focus',()=>setFocus(key,{element:false,scroll:false}));
  }
  if(title==='Performance'){page.insertBefore(overview.el,page.children[1]);page.appendChild(el('p','profile-note'));}
  if(title==='Music')page.insertBefore(meter.el,page.children[1]);
  {
   // Two presses within three seconds, so a stray click never wipes a page.
   const pageReset=button('page-reset',undefined,'Reset every '+title+' setting to its default');let armTimer=0;
   const idle='reset '+title.toLowerCase(),disarm=()=>{clearTimeout(armTimer);pageReset.classList.remove('armed');pageReset.textContent=idle;};
   pageReset.textContent=idle;
   // The Displays page also owns the per-display on / pause / off states.
   const resetSet=title==='Displays'?[...keys,'displayStates']:title==='Menu'?[...keys,'panelPosition']:keys;
   pageReset.addEventListener('click',()=>{
    if(!pageReset.classList.contains('armed')){pageReset.classList.add('armed');pageReset.textContent='press again to reset';clearTimeout(armTimer);armTimer=setTimeout(disarm,3000);return;}
    disarm();resetKeys(resetSet);
   });
   page.appendChild(pageReset);pageResets.set(title,{button:pageReset,keys:resetSet});
  }
  if(title==='Displays'){page.insertBefore(displayList.el,page.children[1]);page.appendChild(el('p','span-note'));}
  // Background and Color shifting are two modes of one setting; the page whose
  // mode is off says so instead of standing empty, with a switch to the other mode.
  if(title==='Background'||title==='Color shifting'){
   const note=el('div','mode-note');note.hidden=true;const text=el('span','mode-text'),sw=button('mode-switch');sw.tabIndex=0;note.append(text,sw);
   page.insertBefore(note,page.children[1]);modeNotes.set(title,{note,text,sw});
   sw.addEventListener('click',()=>change({backgroundMode:title==='Background'?'static':'shifting'}));
  }
 }

 function visible(key){
  if(key==='breatheEnabled'||key==='breathePreset')return true;
  if(key.startsWith('breathe'))return config.breatheEnabled&&(key!=='breatheColor'||config.breatheTint==='custom')&&(!['breatheWidth','breatheSoftness'].includes(key)||config.breatheMode!=='full');
  if(['customBlend','gradientStart','gradientMiddle','gradientEnd','gradientAngle'].includes(key))return config.backgroundMode==='static'&&config.backgroundPreset==='custom'&&(key!=='gradientMiddle'||config.customBlend!=='two');
  if(key==='backgroundPreset')return config.backgroundMode==='static';
  if(key.startsWith('shifting'))return config.backgroundMode==='shifting'&&(!/^shifting(Color|Angle)/.test(key)||config.shiftingPreset==='custom');
  if(key==='waveColor')return config.waveTint==='custom';
  if(key==='waveTintStrength')return config.waveTint!=='silver';
  if(key==='particleColor')return config.particleTint==='custom';
  if(key==='glowColor')return config.glowTint==='custom';
  if(key==='clockTintStrength')return Boolean(config.clockEnabled)&&config.clockTint!=='white';
  if(key==='clockOpacity'||key==='clockPadding')return Boolean(config.clockEnabled)&&['strip','glass','dark','fade'].includes(config.clockStyle);
  if(key==='clockGap')return Boolean(config.clockEnabled)&&Boolean(config.clockDate);
  if(key.startsWith('clock')&&key!=='clockEnabled')return Boolean(config.clockEnabled);
  if(key.startsWith('audio')&&key!=='audioEnabled')return Boolean(config.audioEnabled);
  if(key==='waveSwayPeriod')return config.waveSway>0||config.waveBob>0;
  return true;
 }

 // Keyboard focus moves along the visible rows of the current page (or of all
 // matches while searching). Only the current row's control is in the tab order.
 function visibleRows(){return Array.from(sections.querySelectorAll('.page:not([hidden]) .control:not([hidden])'));}
 function ensureVisible(row,extra){
  const margin=14,top=row.offsetTop-margin,bottom=(extra?extra.offsetTop+extra.offsetHeight:row.offsetTop+row.offsetHeight)+margin;
  if(top<sections.scrollTop)sections.scrollTop=top;
  else if(bottom>sections.scrollTop+sections.clientHeight)sections.scrollTop=Math.min(top,bottom-sections.clientHeight);
 }
 function setFocus(key,{element=true,scroll=true}={}){
  const row=rows.get(key),control=controls.get(key);if(!row||!control)return;
  if(focusedKey&&focusedKey!==key){const old=controls.get(focusedKey);rows.get(focusedKey)?.classList.remove('focused');if(old)old.focusTarget.tabIndex=-1;if(old&&old.isOpen&&old.isOpen()&&old.close)old.close();}
  focusedKey=key;row.classList.add('focused');control.focusTarget.tabIndex=0;
  if(scroll)ensureVisible(row);
  if(element&&api.get().settingsPanel)control.focusTarget.focus({preventScroll:true});
 }
 function moveFocus(dir){
  const list=visibleRows();if(!list.length)return false;
  let i=list.findIndex(r=>r.dataset.key===focusedKey);
  i=i<0?(dir>0?0:list.length-1):clamp(i+dir,0,list.length-1);
  setFocus(list[i].dataset.key);return true;
 }
 function focusEdge(dir){const list=visibleRows();if(!list.length)return false;setFocus(list[dir<0?0:list.length-1].dataset.key);return true;}
 function shiftPage(dir){const all=Object.keys(groups),i=all.indexOf(activePage);selectPage(all[clamp(i+dir,0,all.length-1)],'row');}

 // One handler serves real key presses and the ones forwarded from the desktop.
 function handleKey(key,mods={}){
  if(!api.get().settingsPanel)return false;
  const target=document.activeElement,inPanel=target&&panel.contains(target);
  const typing=inPanel&&target.tagName==='INPUT';
  const onTab=inPanel&&target.classList.contains('category');
  const focused=focusedKey?controls.get(focusedKey):null;
  const open=Boolean(focused&&focused.isOpen&&focused.isOpen());
  if(key==='Escape'){
   if(focused&&focused.escape&&focused.escape())return true;
   if(typing&&target.value){target.value='';if(target===search)filter();return true;}
   change({settingsPanel:false});launch.focus();return true;
  }
  if(key==='PageDown'||key==='PageUp'){
   const dir=key==='PageDown'?1:-1;
   if(open&&focused.page&&focused.page(dir))return true;
   sections.scrollTop+=dir*sections.clientHeight*.7;return true;
  }
  if(key==='['||key===']'){if(typing)return false;shiftPage(key===']'?1:-1);return true;}
  if(onTab){
   // The category column runs top to bottom; Right or Enter steps into its list.
   // Left/Right also walk the column when it is folded into a strip.
   const all=Object.keys(groups),i=all.indexOf(target.dataset.title),strip=panel.classList.contains('compact');
   const prevNext=strip?['ArrowLeft','ArrowRight']:['ArrowUp','ArrowDown'],enter=strip?'ArrowDown':'ArrowRight';
   if(prevNext.includes(key)){selectPage(all[clamp(i+(key===prevNext[1]?1:-1),0,all.length-1)],'tab');return true;}
   if(key==='Home'){selectPage(all[0],'tab');return true;}
   if(key==='End'){selectPage(all[all.length-1],'tab');return true;}
   if(key===enter||key==='Enter'){selectPage(target.dataset.title,'row');return true;}
   return false;
  }
  if(key==='ArrowDown'||key==='ArrowUp'){
   const dir=key==='ArrowDown'?1:-1;
   if(open&&focused.vertical&&focused.vertical(dir))return true;
   if(typing&&target!==search)return false;
   if(target===search&&dir<0)return false;
   if(target===search)search.blur();
   return moveFocus(dir);
  }
  if(key==='ArrowLeft'||key==='ArrowRight'){
   if(typing)return false;
   if(focused&&focused.horizontal)return focused.horizontal(key==='ArrowRight'?1:-1,Boolean(mods.shift))||true;
   return false;
  }
  if(key==='Home'||key==='End'){
   if(typing)return false;
   if(open&&focused.jump&&focused.jump(key==='Home'?-1:1))return true;
   return focusEdge(key==='Home'?-1:1);
  }
  if(key==='Enter'){
   if(target===search){return moveFocus(1);}
   if(typing)return false;
   if(focused&&focused.activate){focused.activate();return true;}
   return false;
  }
  if(key==='Delete'){
   if(typing)return false;
   if(open&&focused.escape)focused.escape();
   return focusedKey?(resetKeys([focusedKey]),true):false;
  }
  if(key==='Backspace'){
   if(typing)return false;
   closeOpenControls();nav.querySelector('.category.active')?.focus({preventScroll:true});return true;
  }
  if(open&&key.length===1&&!mods.ctrl&&!mods.alt&&focused.typeahead)return focused.typeahead(key);
  return false;
 }
 panel.addEventListener('keydown',e=>{
  if(e.ctrlKey||e.altKey||e.metaKey)return;
  if(handleKey(e.key,{shift:e.shiftKey})){e.preventDefault();e.stopPropagation();}
 });
 document.addEventListener('keydown',e=>{
  if(panel.contains(e.target))return;
  if(e.key==='Escape'&&api.get().settingsPanel){change({settingsPanel:false});launch.focus();}
  else if(e.key.toLowerCase()==='s'&&!e.ctrlKey&&!e.altKey&&!e.metaKey&&!/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)){change({settingsPanel:!api.get().settingsPanel});e.preventDefault();}
  else if(api.get().settingsPanel&&['ArrowDown','ArrowUp','ArrowLeft','ArrowRight','PageDown','PageUp','Home','End','Enter','[',']','Backspace','Delete'].includes(e.key)&&!e.ctrlKey&&!e.altKey&&!e.metaKey){if(handleKey(e.key,{shift:e.shiftKey}))e.preventDefault();}
 });

 let controlsSignature='',refreshQueued=false,wasOpen=false,lastGeometry='',geometryTimer=0;
 function setOpen(open){
  panel.classList.toggle('open',open);document.body.classList.toggle('xmb-panel-open',open);panel.setAttribute('aria-hidden',String(!open));panel.inert=!open;launch.setAttribute('aria-expanded',String(open));
  if(open&&!wasOpen){requestAnimationFrame(()=>{overview.wake();meter.wake();});filter();const list=visibleRows();const key=focusedKey&&list.some(r=>r.dataset.key===focusedKey)?focusedKey:list[0]&&list[0].dataset.key;if(key)setFocus(key,{element:true,scroll:true});}
  if(!open)closeOpenControls();
  wasOpen=open;
 }
 function scheduleRefresh(){if(refreshQueued)return;refreshQueued=true;queueMicrotask(()=>{refreshQueued=false;refresh();});}
 // Placement. The menu's home is the top right of the main display (beneath
 // the PS3 clock when it is on); dragging the header moves it from there, and
 // the offset is kept as "x,y" in panelPosition. While the header or the
 // resize handle is held, size and place are applied straight to the page once
 // per frame and saved once on release, so the drag follows the pointer
 // without repainting the menu's rows.
 let liveSize=null,liveOffset=null,layoutQueued=false;
 function homeArea(){
  // When one wave spans several displays the page covers all of them; keep the
  // menu and its launcher on the main display instead of the combined edge.
  const span=window.XMB_SPAN&&window.XMB_SPAN.active?window.XMB_SPAN.primaryCss:null;
  const area=span||{left:0,top:0,width:innerWidth,height:innerHeight};
  const clock=window.ps3ClockStatus,top=clock&&clock.enabled&&clock.stripBottom?Math.round(clock.stripBottom+14):32;
  return {area,top};
 }
 function savedOffset(){const [x,y]=String(config.panelPosition||'').split(',').map(Number);return {x:Number.isFinite(x)?x:0,y:Number.isFinite(y)?y:0};}
 function layoutPanel(){
  const {area,top}=homeArea();
  const w=Math.round(Math.max(360,Math.min(liveSize?liveSize.w:config.panelWidth,area.width-48)));
  const h=Math.round(Math.max(320,Math.min(liveSize?liveSize.h:config.panelHeight,area.height-24)));
  const off=liveOffset||savedOffset(),homeLeft=area.left+area.width-32-w,homeTop=area.top+top;
  // Always wholly on the main display, 8px clear of its edges.
  const left=Math.round(clamp(homeLeft+off.x,area.left+8,area.left+area.width-w-8)),y=Math.round(clamp(homeTop+off.y,area.top+8,Math.max(area.top+8,area.top+area.height-h-8)));
  panel.style.left=left+'px';panel.style.right='auto';panel.style.top=y+'px';panel.style.width=w+'px';panel.style.height=h+'px';
  // Narrow menus fold the category column into a strip and stack each row.
  panel.classList.toggle('compact',w<620);updateScrollThumb();reportGeometry();if(openPicker)openPicker.position();
  return {left,top:y,w,h,homeLeft,homeTop};
 }
 const layoutJob=()=>{layoutQueued=false;layoutPanel();};
 function queueLayout(){if(layoutQueued)return;layoutQueued=true;onBeforeFrame(layoutJob);}
 function refresh(){
  config=api.get();setOpen(Boolean(config.settingsPanel));
  const {area}=homeArea();
  launch.style.right=(innerWidth-(area.left+area.width)+28)+'px';launch.style.bottom=(innerHeight-(area.top+area.height)+28)+'px';
  panel.style.setProperty('--surface-opacity',String(1-config.panelTransparency/100));
  layoutPanel();
  const spanNote=panel.querySelector('.span-note');if(spanNote&&window.XMB_SPAN)spanNote.textContent=window.XMB_SPAN.reason+(window.XMB_SPAN.displays&&window.XMB_SPAN.displays.length?' Detected: '+window.XMB_SPAN.displays.join(', ')+'.':'');
  const {settingsPanel,...controlValues}=config,signature=JSON.stringify(controlValues);
  if(signature===controlsSignature)return;controlsSignature=signature;
  for(const [key,control] of controls){
   control.paint();const row=rows.get(key),modified=!isDefault(key);row.hidden=!visible(key);
   row.classList.toggle('modified',modified);resets.get(key).disabled=!modified;
  }
  for(const {button:b,keys} of pageResets.values())b.hidden=keys.every(k=>!schema[k]||isDefault(k));
  displayList.paint();
  applyTint();
  for(const [title,{note,text,sw}] of modeNotes){
   const shifting=config.backgroundMode==='shifting',relevant=title==='Background'?shifting:!shifting;note.hidden=!relevant;
   if(relevant){text.textContent=title==='Background'?'Background mode is Color shifting, so the static gradient controls are not in use.':'Background mode is Static gradients, so these controls are not in use.';sw.textContent=title==='Background'?'Use static gradients':'Use color shifting';}
  }
  panel.querySelector('.profile-note').textContent=window.waveStatus.performance.description+' Frame targets also respect Wallpaper Engine’s global limit.';
  filter();requestAnimationFrame(()=>{updateScrollThumb();overview.wake();meter.wake();});
 }
 // Browsing shows one category page; a search spans every category, with each
 // page title kept as a group heading over its matches.
 function filter(){
  const term=search.value.trim().toLowerCase();
  for(const [key,row] of rows)row.hidden=!visible(key)||Boolean(term&&!row.dataset.label.includes(term));
  for(const [title,page] of pages){const any=Array.from(page.querySelectorAll('.control')).some(r=>!r.hidden);page.hidden=term?!any:title!==activePage;}
  for(const tab of nav.children){const on=!term&&tab.dataset.title===activePage;tab.classList.toggle('active',on);tab.setAttribute('aria-selected',String(on));tab.tabIndex=on||(term&&tab===nav.firstElementChild)?0:-1;}
  panel.classList.toggle('searching',Boolean(term));
 }
 // The menu surface takes its colour from the live background, following the
 // colour-shifting phase, so the menu always sits in the same light as the wave.
 let lastTint='';
 function applyTint(){
  const hi=window.sceneHighlight?window.sceneHighlight(api.get()):null;if(!hi)return;
  // Keep the hue, lift dark palettes, and cap brightness so white type stays readable.
  const peak=Math.max(...hi),target=clamp(.12+peak*.45,.14,.40),k=peak>.002?target/peak:0;
  const base=peak>.002?hi.map(v=>clamp(v*k,0,1)):[target*.6,target*.8,target];
  const stop=(scale)=>base.map(v=>Math.round(v*scale*255)).join(',');
  const tint=[stop(1),stop(.62),stop(.36)];if(tint.join('|')===lastTint)return;lastTint=tint.join('|');
  panel.style.setProperty('--tint-a',tint[0]);panel.style.setProperty('--tint-b',tint[1]);panel.style.setProperty('--tint-c',tint[2]);
 }
 function tintLoop(){if(api.get().settingsPanel)onNextFrame(applyTint);setTimeout(tintLoop,api.get().settingsPanel?120:1000);}
 tintLoop();

 // The footer stays quiet while everything is in order; it speaks only when a
 // change could not be saved or applied.
 function status(message,error=false){sync.textContent=error?message:'';sync.hidden=!error;sync.classList.toggle('error',error);}
 // Standalone: installed by hand, with no helper. Nothing is sent anywhere; the
 // gear menu's choices are kept in this wallpaper's own storage and restored on
 // the next start, after Wallpaper Engine has applied its saved properties.
 const standalone=!bridge||!bridge.token||/:0\/?$/.test(String(bridge.url||''));
 // Keyed to this wallpaper's folder, so separate copies keep separate choices.
 const STORE='lumaxmb-desktop-settings:'+String(location.pathname||'').replace(/[^/]*$/,'');let storeTimer=0;
 function remember(){
  if(!standalone)return;clearTimeout(storeTimer);
  storeTimer=setTimeout(()=>{try{const {settingsPanel,...values}=api.get();localStorage.setItem(STORE,JSON.stringify(values));}catch(e){}},400);
 }
 function restore(){
  if(!standalone)return;
  try{
   const saved=JSON.parse(localStorage.getItem(STORE)||'null');if(!saved||typeof saved!=='object')return;
   const values=Object.fromEntries(Object.entries(saved).filter(([key])=>key in schema&&key!=='settingsPanel'));
   if(Object.keys(values).length)api.set(values,'restore');
  }catch(e){}
 }
 window.XMBPanelMode={standalone,storageKey:STORE};
 async function request(route,body){
  if(standalone)throw Error('No helper in a manual install');
  const response=await fetch(bridge.url+route,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-XMB-Token':bridge.token},...(body?{body:JSON.stringify(body)}:{})});
  const result=await response.json();if(!response.ok)throw Error(result.error||'Sidebar unavailable');return result;
 }
 function change(values){
  if('settingsPanel' in values)setOpen(Boolean(values.settingsPanel));
  const current=api.get();
  if(current.performancePreset!=='custom'&&['fpsMode','resolution','glow','blur'].some(k=>k in values)){
   const effective=window.resolvePerformanceSettings(current);
   values={performancePreset:'custom',fpsMode:String(effective.fps),resolution:effective.resolution,glow:effective.glow,blur:effective.blur,particleDensity:Math.max(.2,current.particleDensity*effective.particleScale),...values};
  }
  api.set(values,'panel');const normalized=api.get();
  if(standalone){remember();return;}
  Object.assign(pending,Object.fromEntries([...new Set([...Object.keys(values),...Object.keys(normalized).filter(key=>normalized[key]!==current[key])])].map(key=>[key,normalized[key]])));
  // The page previews at once; the helper hears from it a few times a second.
  clearTimeout(sendTimer);sendTimer=setTimeout(flush,140);
 }
 function reportApply(result){if(result&&'applyError' in result)status(result.applyError||'',Boolean(result.applyError));}
 async function flush(){
  if(sending)return;if(!Object.keys(pending).length)return;
  const values=pending;pending={};sending=true;status('Saving to sidebar…');
  try{const result=await request('/properties',values);revision=result.revision;connected=true;reportApply(result);}
  catch(e){Object.assign(pending,values,pending);connected=false;status('Not saved · helper not running',true);}
  finally{sending=false;if(Object.keys(pending).length&&connected)sendTimer=setTimeout(flush,140);}
 }
 window.addEventListener('xmb-settings',e=>{
  scheduleRefresh();
  // In a manual install, changes made in Wallpaper Engine's own panel are kept too.
  if(standalone){if(e.detail.source==='host')remember();return;}
  if(e.detail.source==='host'){
   // Echo host changes to the companion, never back to Wallpaper Engine.
   const values=Object.fromEntries(Object.keys(e.detail.props).filter(k=>k in schema).map(k=>[k,api.get()[k]]));
   Object.assign(observed,values);clearTimeout(observeTimer);
   observeTimer=setTimeout(async()=>{const values=observed;observed={};try{const result=await request('/observed',values);revision=result.revision;connected=true;reportApply(result);}catch(e){Object.assign(observed,values,observed);status('Not saved · helper not running',true);}},100);
  }
 });
 // State is polled briskly while the menu is open and slowly while it is closed;
 // changes made in the host arrive through its own callback regardless.
 async function poll(){
  try{
   if(Object.keys(pending).length&&!sending)await flush();
   if(!sending&&!Object.keys(pending).length){const result=await request('/state?lite=1&rev='+revision);window.XMBDisplays?.accept(result.displayLayout);if(revision!==result.revision){api.set(result.values,'bridge');revision=result.revision;}connected=true;reportApply(result);
    const tuneSpec=result.ui&&result.ui.glassTune;if(tuneSpec&&window.XMBGlass&&window.XMBGlass.tune&&JSON.stringify(tuneSpec)!==window.XMBGlass.lastTune){window.XMBGlass.lastTune=JSON.stringify(tuneSpec);window.XMBGlass.tune(tuneSpec);}}
  }catch(e){connected=false;status('Not saved · helper not running',true);}
  setTimeout(poll,api.get().settingsPanel?750:2500);
 }

 // Wheel: the page scrolls its own list (or an open option list) because the host
 // does not scroll the document. Desktop wheel and keys arrive through the helper.
 let axisWheelAt=0;
 function wheelAt(target,deltaY,deltaMode=0){
  if(target.closest('.categories')){
   // A wheel turn over the category axis steps along it, one category per notch.
   const now=performance.now();if(now-axisWheelAt<140)return;axisWheelAt=now;shiftPage(deltaY>0?1:-1);return;
  }
  const menu=target.closest('.picker-menu'),scroller=menu&&!menu.hidden?menu:sections;
  scroller.scrollTop+=deltaY*(deltaMode===1?24:deltaMode===2?scroller.clientHeight:1);
 }
 panel.addEventListener('wheel',e=>{
  wheelEvents++;if(!api.get().settingsPanel||!e.deltaY)return;
  wheelAt(e.target,e.deltaY,e.deltaMode);e.preventDefault();e.stopPropagation();
 },{passive:false});
 // A click outside an open option column or colour editor settles it.
 document.addEventListener('pointerdown',e=>{
  if(!api.get().settingsPanel)return;
  if(e.target.closest('.picker-menu,.picker,.color-editor,.color-button'))return;
  closeOpenControls();
 },true);
 sections.addEventListener('scroll',()=>{if(openPicker)openPicker.position();},{passive:true});
 for(const page of pages.values())page.addEventListener('animationend',()=>page.classList.remove('enter-l','enter-r')); launch.addEventListener('click',()=>change({settingsPanel:!api.get().settingsPanel}));
 panel.querySelector('.close').addEventListener('click',()=>{change({settingsPanel:false});launch.focus();});
 search.addEventListener('input',()=>{filter();updateScrollThumb();requestAnimationFrame(updateScrollThumb);});

 const panelRect=()=>{const r=panel.getBoundingClientRect();return {left:r.left/innerWidth,top:r.top/innerHeight,right:r.right/innerWidth,bottom:r.bottom/innerHeight};};
 // The frame this page's viewport covers on the physical desktop. One wave
 // spanning several displays covers the monitors' bounding box; otherwise the
 // page is one monitor and the helper measures against the monitor itself.
 function pageFrame(){
  const span=window.XMB_SPAN,list=window.XMB_DISPLAY_LAYOUT&&window.XMB_DISPLAY_LAYOUT.monitors;
  if(span&&span.active&&Array.isArray(list)&&list.length){
   const left=Math.min(...list.map(m=>m.rect[0])),top=Math.min(...list.map(m=>m.rect[1]));
   const right=Math.max(...list.map(m=>m.rect[0]+m.rect[2])),bottom=Math.max(...list.map(m=>m.rect[1]+m.rect[3]));
   return {kind:'desktop',rect:[left,top,right-left,bottom-top]};
  }
  return {kind:'monitor'};
 }
 // The helper scopes desktop wheel, drag and key forwarding to the menu's
 // rectangle; tell it about geometry changes at once rather than at the next tick.
 function reportGeometry(){
  const open=Boolean(api.get().settingsPanel),geometry=JSON.stringify([open,open?panelRect():null,pageFrame()]);
  if(geometry===lastGeometry)return;lastGeometry=geometry;clearTimeout(geometryTimer);
  if(standalone)return;
  geometryTimer=setTimeout(()=>{request('/telemetry',{panel:{open,rect:panelRect(),frame:pageFrame(),viewport:[innerWidth,innerHeight]},time:Date.now(),geometryOnly:true}).catch(()=>{});},60);
 }
 let metricFrames=window.waveStatus.frames,metricTime=window.performance.now();
 function metrics(){
  const now=window.performance.now(),s=window.waveStatus,elapsed=now-metricTime,fps=(s.frames-metricFrames)*1000/elapsed;metricFrames=s.frames;metricTime=now;
  const open=Boolean(api.get().settingsPanel),diagnostics=Boolean(api.get().diagnosticsEnabled);
  // Render figures appear only with diagnostics on; the menu is otherwise quiet.
  panel.querySelector('.metrics').hidden=!diagnostics;
  panel.querySelector('#xmb-size').textContent=(s.fullRenderSize||s.backgroundRenderSize).join('×');
  panel.querySelector('#xmb-cadence').textContent=s.paused?'Paused':fps.toFixed(0)+' fps';
  panel.querySelector('#xmb-aa').textContent=s.effects.warning?'AA unavailable':s.effects.sceneSamples?s.effects.sceneSamples+'× MSAA':'AA off';
  // A full report every second while the menu is open or diagnostics are on;
  // otherwise a small heartbeat every five seconds.
  if(standalone){setTimeout(metrics,open||diagnostics?1000:5000);return;}
  if(!open&&!diagnostics){
   request('/telemetry',{panel:{build:BUILD,open,rect:panelRect(),frame:pageFrame(),viewport:[innerWidth,innerHeight]},time:Date.now(),drawFps:fps,frames:s.frames,paused:s.paused,pacing:s.pacing||null,backgroundDraws:s.backgroundDraws||0,clockDraws:window.ps3ClockStatus?window.ps3ClockStatus.draws:0,heartbeat:true}).catch(()=>{});
   setTimeout(metrics,5000);return;
  }
  request('/telemetry',{panel:{build:BUILD,schemaKeys:Object.keys(schema).length,hasClockTheme:'clockTheme' in schema,open,rect:panelRect(),frame:pageFrame(),viewport:[innerWidth,innerHeight],scrollTop:sections.scrollTop,scrollHeight:sections.scrollHeight,clientHeight:sections.clientHeight,transparency:api.get().panelTransparency,width:panel.clientWidth,height:panel.clientHeight,wheelEvents,bridgeWheelEvents,bridgeKeyEvents,bridgeDragEvents,focusedKey,meshVertices:s.meshVertices,aaRequested:s.effects.requestedSamples,aaIndependent:s.effects.independentAA,aaWarning:s.effects.warning},time:Date.now(),drawFps:fps,frames:s.frames,paused:s.paused,nativeSize:s.nativeSize,fullRenderSize:s.fullRenderSize,backgroundRenderSize:s.backgroundRenderSize,waveRenderSize:s.renderSize,msaa:s.effects.active?s.effects.sceneSamples:s.antialiasSamples,target:s.targetFps,desktopXmb:s.desktopXmb,displayMapping:s.span,displayTransition:window.XMBDisplayRuntime?.stats(),breathingGlow:s.breathingGlow,breathingRuntime:s.effects.breathing,waveAppearance:s.waveAppearance,waveTintColor:s.waveTintColor,glass:window.XMBGlass?window.XMBGlass.stats:null,audio:window.waveStatus.audio||null,pacing:window.waveStatus.pacing||null,backgroundDraws:window.waveStatus.backgroundDraws||0,regions:window.waveStatus.regions||null,inputLog:inputLog.slice(-60),helperInput,haloFormat:window.waveStatus.effects?window.waveStatus.effects.haloFormat:null,clockDraws:window.ps3ClockStatus?window.ps3ClockStatus.draws:0,clock:window.ps3ClockStatus?{enabled:window.ps3ClockStatus.enabled,fontPx:window.ps3ClockStatus.area&&window.ps3ClockStatus.area.fontPx,stripBottom:window.ps3ClockStatus.stripBottom,draws:window.ps3ClockStatus.draws,error:window.ps3ClockStatus.error||null}:null,physicalPresentationMeasured:false}).catch(()=>{});
  setTimeout(metrics,1000);
 }

 // Scrollbar drawn by the page: drag the thumb with pointer capture, or click the
 // track to jump there. The footer arrows page through the list.
 function updateScrollThumb(){
  const total=sections.scrollHeight,visibleHeight=sections.clientHeight,travel=track.clientHeight;
  const scrollable=total>visibleHeight+1;track.classList.toggle('inactive',!scrollable);
  const height=scrollable?Math.max(36,travel*visibleHeight/Math.max(total,1)):travel;
  thumb.style.height=Math.min(travel,height)+'px';thumb.style.top=(scrollable?(travel-height)*sections.scrollTop/Math.max(1,total-visibleHeight):0)+'px';
  track.setAttribute('aria-valuenow',String(scrollable?Math.round(sections.scrollTop/(total-visibleHeight)*100):0));
 }
 sections.addEventListener('scroll',updateScrollThumb,{passive:true});
 new ResizeObserver(updateScrollThumb).observe(sections);
 holdRepeat(panel.querySelector('.scroll-up'),()=>{sections.scrollTop-=sections.clientHeight*.35;});
 holdRepeat(panel.querySelector('.scroll-down'),()=>{sections.scrollTop+=sections.clientHeight*.35;});
 let drag=null;
 const syntheticDragActive=()=>Boolean(drag&&drag.synthetic);
 // Pointer capture only for host-started drags; desktop drags need none.
 const capture=(el,e)=>{if(e.isTrusted)try{el.setPointerCapture(e.pointerId);}catch(_){}};
 const endScroll=()=>{if(drag&&drag.kind==='scroll')drag=null;thumb.classList.remove('dragging');};
 thumb.addEventListener('pointerdown',e=>{if(e.button!==0||blockedStart(syntheticDragActive(),e))return;e.preventDefault();e.stopPropagation();drag={kind:'scroll',y:e.clientY,scroll:sections.scrollTop,synthetic:!e.isTrusted};thumb.classList.add('dragging');capture(thumb,e);});
 thumb.addEventListener('pointermove',e=>{if(!drag||drag.kind!=='scroll'||foreignTo(drag.synthetic,e))return;if(hostReleased(drag.synthetic,e)){endScroll();return;}const travel=track.clientHeight-thumb.clientHeight;sections.scrollTop=drag.scroll+(e.clientY-drag.y)/Math.max(1,travel)*(sections.scrollHeight-sections.clientHeight);});
 for(const type of ['pointerup','pointercancel'])thumb.addEventListener(type,endScroll);
 thumb.addEventListener('lostpointercapture',()=>{if(!syntheticDragActive())endScroll();});
 track.addEventListener('pointerdown',e=>{if(e.target===thumb||e.button!==0)return;const rect=track.getBoundingClientRect();sections.scrollTop=(e.clientY-rect.top)/rect.height*sections.scrollHeight-sections.clientHeight/2;});
 // Resize: the handle sits at the bottom left, so the right and top edges stay
 // put. Pixel-exact while dragging; saved once on release.
 const resizeHandle=panel.querySelector('.resize-handle');
 resizeHandle.addEventListener('pointerdown',e=>{if(e.button!==0||blockedStart(syntheticDragActive(),e))return;e.preventDefault();e.stopPropagation();drag={kind:'resize',x:e.clientX,y:e.clientY,width:panel.clientWidth,height:panel.clientHeight,synthetic:!e.isTrusted};panel.classList.add('resizing');capture(resizeHandle,e);});
 resizeHandle.addEventListener('pointermove',e=>{
  if(!drag||drag.kind!=='resize'||foreignTo(drag.synthetic,e))return;
  if(hostReleased(drag.synthetic,e)){endResize();return;}
  liveSize={w:Math.max(360,Math.min(1600,drag.width+drag.x-e.clientX)),h:Math.max(420,Math.min(1800,drag.height+e.clientY-drag.y))};
  queueLayout();
 });
 function endResize(){
  if(!drag||drag.kind!=='resize')return;drag=null;panel.classList.remove('resizing');
  const placed=layoutPanel();liveSize=null;change({panelWidth:placed.w,panelHeight:placed.h});
 }
 for(const type of ['pointerup','pointercancel'])resizeHandle.addEventListener(type,endResize);
 resizeHandle.addEventListener('lostpointercapture',()=>{if(!syntheticDragActive())endResize();});
 // Move: press anywhere on the header (not the close button) and drag.
 // Double-click the header to send the menu home.
 // Grips: the whole top of the menu moves it. The header (title bar) moves it
 // at once; the category strip beneath moves it once the pointer has travelled
 // a few pixels, so a plain click there still picks a category. A click that
 // ends a move is swallowed, so letting go over a tab does not select it.
 const header=panel.querySelector('header'),GRIP_THRESHOLD=6;let suppressClickUntil=0;
 panel.addEventListener('click',e=>{if(performance.now()<suppressClickUntil){e.stopPropagation();e.preventDefault();}},true);
 function attachGrip(el,threshold){
  el.addEventListener('pointerdown',e=>{
   if(e.button!==0||e.target.closest('.close')||blockedStart(syntheticDragActive(),e))return;
   drag={kind:threshold?'grip':'move',x:e.clientX,y:e.clientY,offset:savedOffset(),synthetic:!e.isTrusted,el};
   // A pending grip takes no capture yet, so a plain click reaches its tab.
   if(!threshold){e.preventDefault();panel.classList.add('moving');capture(el,e);}
  });
  el.addEventListener('pointermove',e=>{
   if(!drag||drag.el!==el||(drag.kind!=='move'&&drag.kind!=='grip')||foreignTo(drag.synthetic,e))return;
   if(hostReleased(drag.synthetic,e)){endMove();return;}
   if(drag.kind==='grip'){
    if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<threshold)return;
    drag.kind='move';panel.classList.add('moving');capture(el,e);suppressClickUntil=Infinity;
   }
   liveOffset={x:drag.offset.x+e.clientX-drag.x,y:drag.offset.y+e.clientY-drag.y};queueLayout();
  });
  for(const type of ['pointerup','pointercancel'])el.addEventListener(type,endMove);
  el.addEventListener('lostpointercapture',()=>{if(!syntheticDragActive())endMove();});
 }
 function endMove(){
  if(!drag||(drag.kind!=='move'&&drag.kind!=='grip'))return;
  const moved=drag.kind==='move';drag=null;panel.classList.remove('moving');
  if(!moved)return;
  suppressClickUntil=performance.now()+350;
  if(!liveOffset)return;
  // Keep the offset the menu actually took after being held on screen.
  const placed=layoutPanel();liveOffset=null;
  const x=placed.left-placed.homeLeft,y=placed.top-placed.homeTop;
  change({panelPosition:x||y?x+','+y:''});
 }
 attachGrip(header,0);attachGrip(nav,GRIP_THRESHOLD);
 header.addEventListener('dblclick',e=>{if(e.target.closest('.close'))return;liveOffset=null;change({panelPosition:''});});
 window.addEventListener('blur',()=>{endResize();endMove();drag=null;});
 window.addEventListener('resize',()=>{controlsSignature='';refresh();});
 window.addEventListener('xmb-viewport',()=>{controlsSignature='';refresh();});
 window.addEventListener('xmb-clock-layout',()=>{controlsSignature='';refresh();});

 // Desktop input forwarded by the helper: wheel over the open menu, a press on a
 // slider, the scrollbar thumb or the resize handle with the drag that follows
 // (the desktop shell captures the mouse during a hold, so the page never sees
 // those moves by itself), and the navigation keys while the desktop is in front.
 let lastInput=0,desktopDrag=null,bridgeDragEvents=0;
 const DRAG_TARGETS='.slider-track,.scroll-thumb,.resize-handle,header,.categories';
 function syntheticPointer(type,target,x,y){
  target.dispatchEvent(new PointerEvent(type,{clientX:x,clientY:y,button:type==='pointermove'?-1:0,buttons:type==='pointerup'?0:1,pointerId:1,pointerType:'mouse',isPrimary:true,bubbles:true,cancelable:true}));
 }
 function desktopPointer(event){
  const x=event.x*innerWidth,y=event.y*innerHeight;
  if(event.phase==='down'){
   const hit=document.elementFromPoint(x,y),target=hit&&panel.contains(hit)?hit.closest(DRAG_TARGETS):null;
   desktopDrag=target?{target}:null;
   if(target){bridgeDragEvents++;syntheticPointer('pointerdown',target,x,y);}
  }else if(desktopDrag){
   bridgeDragEvents++;syntheticPointer(event.phase==='up'?'pointerup':'pointermove',desktopDrag.target,x,y);
   if(event.phase==='up')desktopDrag=null;
  }
 }
 // Input log (diagnostics): the last 60 pointer events seen by the menu and
 // desktop events received from the helper, sent with telemetry while the
 // menu is open, so a real drag on the desktop can be examined. Entries are
 // [ms, kind, trusted, buttons, x, y, drag state].
 const inputLog=[],helperInput={lastClass:'',status:''};
 function logInput(kind,trusted,buttons,x,y){inputLog.push([Math.round(performance.now()),kind,trusted?1:0,buttons,Math.round(x),Math.round(y),drag?drag.kind+(drag.synthetic?'*':''):desktopDrag?'desk':'']);if(inputLog.length>60)inputLog.shift();}
 for(const type of ['pointerdown','pointermove','pointerup','pointercancel','lostpointercapture','gotpointercapture'])
  panel.addEventListener(type,e=>{if(type==='pointermove'&&!drag&&!desktopDrag)return;logInput(type.replace('pointer','').replace('lost','lost-').replace('got','got-'),e.isTrusted,e.buttons,e.clientX,e.clientY);},true);
 window.XMBInputLog=inputLog;
 function handleDesktopEvent(event){
  if(event.kind==='pointer')logInput('D'+event.phase+'#'+event.id,false,-1,event.x*innerWidth,event.y*innerHeight);
  if(event.kind==='key'){bridgeKeyEvents++;handleKey(event.key,{shift:Boolean(event.shift)});return;}
  if(event.kind==='pointer'){desktopPointer(event);return;}
  const target=document.elementFromPoint(event.x*innerWidth,event.y*innerHeight);if(!target||!panel.contains(target))return;
  wheelAt(target,Number(event.delta)||0);bridgeWheelEvents++;
 }
 // Long poll: the helper holds each request until an event arrives (up to
 // 450 ms), so an idle open menu costs about two requests a second instead of
 // twenty-five, while a wheel turn or key still lands within a frame or two. A
 // helper that answers at once (an older build) falls back to a short cadence.
 async function pollDesktopInput(){
  const open=api.get().settingsPanel;let delay=open?0:1500;
  if(open)try{
   const started=performance.now(),result=await request('/input?after='+lastInput+'&wait=450');
   const events=result.events||[];helperInput.lastClass=result.last_class||'';helperInput.status=result.status||'';
   for(const event of events){
    if(event.id<=lastInput)continue;lastInput=event.id;if(event.time<performance.timeOrigin)continue;
    handleDesktopEvent(event);
   }
   if(!events.length&&performance.now()-started<60)delay=desktopDrag?20:40;
  }catch(e){delay=600;}
  setTimeout(pollDesktopInput,delay);
 }
 if(!standalone)pollDesktopInput();
 // Local diagnostics only: lets a test feed the same events the helper would.
 window.XMBPanelInput={inject:handleDesktopEvent,counters:()=>({wheelEvents,bridgeWheelEvents,bridgeKeyEvents,bridgeDragEvents})};

 refresh();metrics();
 // Let the host's initial property callback arrive before companion polling,
 // or, in a manual install, before the remembered choices are restored.
 setTimeout(async()=>{if(standalone){restore();return;}try{await request('/observed',api.get());}catch(e){}poll();},600);
})();
