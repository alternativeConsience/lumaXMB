'use strict';
// The colour the background is showing now: the brightest stop of a static
// gradient, or the colour-shifting palette at its current phase. Shared by the
// settings menu's surface tint and the clock's colour coordination.
(function(root){
 const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
 function paletteAt(colors,p){
  const slot=(((p%1)+1)%1)*4,i=Math.floor(slot)%4,f=slot-Math.floor(slot),s=f*f*(3-2*f),a=colors[i],b=colors[(i+1)%4];
  return a.map((v,k)=>v+(b[k]-v)*s);
 }
 root.sceneHighlight=function(cfg){
  cfg=cfg||(root.XMBSettings?root.XMBSettings.get():{});
  if(cfg.backgroundMode==='shifting'&&root.BACKGROUND_MOTION_SETTINGS){
   const s=root.BACKGROUND_MOTION_SETTINGS,colors=(s.colors||[]).length===4?s.colors:[[.03,.12,.52],[.24,.07,.56],[.08,.22,.58],[.15,.12,.42]];
   const clocks=root.XMBDisplayRuntime&&root.XMBDisplayRuntime.stats().clocks,t=clocks?clocks.backgroundTime:0;
   const cycle=clamp(Number(s.cycleLength)||90,12,600),strength=clamp(Number(s.strength),0,1),phase=strength===0?0:(((t%cycle)+cycle)%cycle)/cycle;
   const cycleAt=o=>paletteAt(colors,o).map((v,k)=>v+(paletteAt(colors,phase+o)[k]-v)*strength);
   return cycleAt(.28).map(v=>v*.9*(Number(s.exposure)||1));
  }
  const g=root.waveStatus&&root.waveStatus.gradient;if(!g)return null;
  const stops=[g.end,g.middle,g.start].filter(Array.isArray);if(!stops.length)return null;
  const brightest=stops.reduce((best,c)=>Math.max(...c)>Math.max(...best)?c:best,stops[0]);
  return brightest.map(v=>v*(Number(g.exposure)||1));
 };
 // The same colour as a hue only (its brightest channel at 1), for tinting.
 root.sceneTint=function(cfg){
  const hi=root.sceneHighlight(cfg);if(!hi)return [1,1,1];
  const peak=Math.max(...hi);return peak>.002?hi.map(v=>clamp(v/peak,0,1)):[.72,.78,.85];
 };
})(window);
