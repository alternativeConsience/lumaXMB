'use strict';
// A restrained accent layer: small glass, dust, and light forms rather than white glitter.
// Presets share one deterministic 800-point buffer; changing a preset never reseeds it.
window.PARTICLE_PRESETS = {
  dust: {label:'Micro Dust',count:210,style:0,flow:0,sizeBase:1.0,sizeVar:1.1,flowSpeed:.040,opacityScale:.58},
  facets: {label:'Glass Facets',count:82,style:1,flow:0,sizeBase:3.8,sizeVar:3.6,flowSpeed:.030,opacityScale:.68},
  glow: {label:'Soft Motes',count:54,style:2,flow:0,sizeBase:5.0,sizeVar:6.0,flowSpeed:.025,opacityScale:.56},
  orbit: {label:'Orbital Dust',count:116,style:0,flow:1,sizeBase:1.0,sizeVar:1.4,flowSpeed:.030,opacityScale:.66},
  horizon: {label:'Horizon Drift',count:154,style:0,flow:2,sizeBase:1.0,sizeVar:1.3,flowSpeed:.055,opacityScale:.63},
  embers: {label:'Rising Embers',count:96,style:2,flow:3,sizeBase:1.6,sizeVar:2.2,flowSpeed:.045,opacityScale:.63},
  stars: {label:'Fine Starfield',count:278,style:3,flow:4,sizeBase:1.0,sizeVar:1.4,flowSpeed:.025,opacityScale:.63},
  comets: {label:'Silk Streaks',count:64,style:4,flow:5,sizeBase:3.2,sizeVar:3.2,flowSpeed:.055,opacityScale:.53},
  snow: {label:'Silver Fall',count:122,style:0,flow:6,sizeBase:1.1,sizeVar:1.3,flowSpeed:.060,opacityScale:.66},
  fireflies: {label:'Breathing Lights',count:48,style:2,flow:7,sizeBase:4.0,sizeVar:3.0,flowSpeed:.028,opacityScale:.52},
  prism: {label:'Prism Flecks',count:76,style:1,flow:8,sizeBase:3.2,sizeVar:3.6,flowSpeed:.027,opacityScale:.63},
  halos: {label:'Glass Halos',count:38,style:5,flow:2,sizeBase:6.0,sizeVar:7.0,flowSpeed:.030,opacityScale:.40},
};
window.PARTICLE_SETTINGS = {
  count:0,
  opacity:.55,
  sizeScale:1,
  speed:1,
  color:[.72,.84,1],
  style:0,
  flow:0,
  sizeBase:1.0,
  sizeVar:1.1,
  flowSpeed:.040,
  opacityScale:.58,
};
window.PARTICLE_SETTINGS_META = {
  count:{min:0,max:800,step:1,decimals:0},
  opacity:{min:0,max:1,step:.01},
  sizeScale:{min:.3,max:2.5,step:.05},
  speed:{min:0,max:3,step:.05},
};
