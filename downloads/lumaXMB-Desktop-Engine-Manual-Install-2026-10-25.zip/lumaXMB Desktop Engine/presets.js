'use strict';
(() => {
  const rgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255);
  const twoTone = (label, startHex, endHex, angle = 90) => {
    const start = rgb(startHex), end = rgb(endHex);
    return {label, start, middle:start.map((value, i) => (value + end[i]) / 2), end,
      angle, twoTone:true, blackFloor:false, blackPoint:0};
  };
  const threeTone = (label, start, middle, end, angle) =>
    ({label, start, middle, end, angle, twoTone:false, blackFloor:false, blackPoint:0});
  const oled = (label, endHex, angle, blackPoint) => ({
    ...twoTone('OLED — ' + label, '#000000', endHex, angle),
    blackFloor:true, blackPoint
  });

  // Original colors and keys remain exact, including the six three-stop ramps.
  // Palette names describe authored interpretations rather than firmware samples.
  window.BACKGROUND_PRESETS = {
    ps3_obsidian:twoTone('PS3 — Obsidian / Silver', '#030508', '#59616c'),
    ps3_blue:twoTone('PS3 — Midnight / Cobalt', '#030b29', '#184cb0'),
    ps3_violet:twoTone('PS3 — Indigo / Violet', '#120c32', '#8654ab'),
    ps3_rose:twoTone('PS3 — Burgundy / Rose', '#27081e', '#bb527d'),
    ps3_amber:twoTone('PS3 — Umber / Amber', '#25140a', '#c78e38'),
    ps3_emerald:twoTone('PS3 — Forest / Emerald', '#051d16', '#389270'),
    ps3_teal:twoTone('PS3 — Navy / Teal', '#041927', '#398f9c'),
    ps3_crimson:twoTone('PS3 — Wine / Crimson', '#210709', '#b43842'),
    psp_silver:twoTone('PSP-3000 — Slate / Pearl', '#4b5669', '#dce5ec'),
    psp_blue:twoTone('PSP-3000 — Royal Blue / Sky', '#16377e', '#66c3ee'),
    psp_aqua:twoTone('PSP-3000 — Teal / Aqua', '#12626c', '#91e8dc'),
    psp_lime:twoTone('PSP-3000 — Olive / Lime', '#48622a', '#cae98e'),
    psp_gold:twoTone('PSP-3000 — Ochre / Gold', '#966424', '#ffe59a'),
    psp_orange:twoTone('PSP-3000 — Copper / Apricot', '#9a432a', '#ffbd84'),
    psp_pink:twoTone('PSP-3000 — Raspberry / Pink', '#822859', '#f0a0cb'),
    psp_lilac:twoTone('PSP-3000 — Violet / Lilac', '#4b347a', '#c5afea'),
    midnight:threeTone('Classic — Midnight Blue', [.001,.001,.009], [.004,.006,.028], [.018,.019,.086], 90),
    lavender:threeTone('Classic — Lavender', [.36,.40,.51], [.24,.22,.36], [.17,.10,.28], 110),
    aurora:threeTone('Classic — Aurora', [.015,.045,.12], [.035,.22,.25], [.19,.055,.28], 35),
    sunset:threeTone('Classic — Sunset', [.12,.035,.23], [.40,.10,.24], [.73,.29,.13], 90),
    ocean:threeTone('Classic — Ocean', [.005,.025,.085], [.025,.12,.25], [.055,.32,.35], 75),
    graphite:threeTone('Classic — Graphite', [.015,.018,.025], [.065,.075,.095], [.17,.19,.23], 90),

    // Dark gradients hold their luminance low without flattening the color ramp.
    dark_carbon:twoTone('Dark — Carbon / Steel', '#020305', '#222a35', 90),
    dark_ink:twoTone('Dark — Ink / Slate', '#03060b', '#1e3043', 110),
    dark_navy:twoTone('Dark — Navy / Deep Cobalt', '#020613', '#163763', 90),
    dark_denim:twoTone('Dark — Denim / Storm Blue', '#070b13', '#29465f', 75),
    dark_petrol:twoTone('Dark — Petrol / Blue Steel', '#020b10', '#1a3e4b', 105),
    dark_teal:twoTone('Dark — Abyss / Deep Teal', '#02090a', '#145045', 90),
    dark_jade:twoTone('Dark — Black Pine / Jade', '#030906', '#244836', 65),
    dark_forest:twoTone('Dark — Forest / Moss', '#030804', '#2a3c23', 105),
    dark_olive:twoTone('Dark — Olive / Bronze', '#080906', '#42412a', 90),
    dark_bronze:twoTone('Dark — Espresso / Bronze', '#0b0704', '#4f3823', 110),
    dark_copper:twoTone('Dark — Charcoal / Copper', '#0b0504', '#5b332b', 90),
    dark_rust:twoTone('Dark — Smoked Ember / Rust', '#0d0403', '#54251b', 75),
    dark_oxblood:twoTone('Dark — Oxblood / Garnet', '#0b0205', '#4c1c2d', 105),
    dark_burgundy:twoTone('Dark — Burgundy / Plum', '#090309', '#44253e', 90),
    dark_mulberry:twoTone('Dark — Mulberry / Mauve', '#0a050c', '#50344c', 70),
    dark_amethyst:twoTone('Dark — Aubergine / Amethyst', '#07040f', '#3e2860', 110),
    dark_indigo:twoTone('Dark — Indigo / Iris', '#030412', '#292d60', 90),
    dark_lavender:twoTone('Dark — Charcoal / Dusty Lavender', '#07070b', '#474457', 115),
    dark_smoke:twoTone('Dark — Smoke / Pewter', '#080a0c', '#3c444b', 90),
    dark_warmgray:twoTone('Dark — Anthracite / Warm Gray', '#090807', '#4c443d', 65),
    dark_sand:twoTone('Dark — Coffee / Faded Sand', '#0a0706', '#5c4c3a', 110),
    dark_midnightcyan:twoTone('Dark — Midnight / Arctic Blue', '#01060b', '#215364', 90),
    dark_rosewood:twoTone('Dark — Rosewood / Ash Rose', '#0b0607', '#5b3d41', 75),
    dark_prussian:twoTone('Dark — Prussian / Sea Glass', '#020810', '#25464c', 110),

    // A real black endpoint and black plateau precede each restrained hue.
    // The static shader keeps the plateau black; dithering starts in the ramp.
    oled_cobalt:oled('Black / Cobalt', '#063480', 90, .38),
    oled_sapphire:oled('Black / Sapphire', '#084960', 110, .35),
    oled_electricblue:oled('Black / Electric Blue', '#0841a3', 75, .43),
    oled_glacier:oled('Black / Glacier', '#286579', 90, .42),
    oled_cyan:oled('Black / Cyan', '#056774', 105, .40),
    oled_teal:oled('Black / Teal', '#055346', 90, .32),
    oled_emerald:oled('Black / Emerald', '#07542a', 65, .38),
    oled_viridian:oled('Black / Viridian', '#126044', 110, .43),
    oled_lime:oled('Black / Acid Lime', '#425715', 90, .45),
    oled_olive:oled('Black / Olive Gold', '#4b4815', 75, .32),
    oled_gold:oled('Black / Antique Gold', '#705216', 105, .42),
    oled_amber:oled('Black / Amber', '#7c4310', 90, .38),
    oled_copper:oled('Black / Copper', '#693621', 65, .35),
    oled_ember:oled('Black / Ember', '#7a2612', 110, .44),
    oled_crimson:oled('Black / Crimson', '#680b23', 90, .40),
    oled_ruby:oled('Black / Ruby', '#80092f', 75, .45),
    oled_rose:oled('Black / Rose', '#702e50', 105, .35),
    oled_magenta:oled('Black / Magenta', '#6e1462', 90, .40),
    oled_orchid:oled('Black / Orchid', '#622b79', 65, .42),
    oled_violet:oled('Black / Violet', '#462083', 110, .38),
    oled_indigo:oled('Black / Indigo', '#252c74', 90, .35),
    oled_lilac:oled('Black / Lilac', '#514567', 75, .43),
    oled_silver:oled('Black / Silver', '#545c67', 105, .45),
    oled_warmwhite:oled('Black / Warm Pearl', '#6d6151', 90, .44)
  };
})();
