'use strict';
// A separate animated background renderer. Static gradients keep their cached,
// one-draw path; this layer is used only when Color shifting is selected.
(() => {
  const palette=(label,colors,angle=90,blackFloor=false,blackPoint=0)=>({label,colors,angle,blackFloor,blackPoint});
  window.ANIMATED_BACKGROUND_PRESETS={
    console:palette('Console — Cobalt & Violet',[[.035,.12,.52],[.24,.07,.56],[.08,.22,.58],[.15,.12,.42]]),
    pspPrism:palette('PSP — Prism Cycle',[[.22,.5,.85],[.53,.19,.67],[.78,.29,.18],[.2,.64,.43]],100),
    royalBlue:palette('Royal Blue Drift',[[.02,.12,.48],[.08,.3,.72],[.04,.2,.54],[.16,.12,.45]]),
    violetHour:palette('Violet Hour',[[.19,.05,.36],[.42,.16,.58],[.27,.13,.5],[.16,.21,.46]],110),
    aurora:palette('Aurora — Emerald & Iris',[[.04,.44,.31],[.04,.38,.5],[.23,.1,.5],[.12,.39,.25]],105),
    deepSea:palette('Deep Sea',[[.015,.12,.2],[.015,.27,.34],[.045,.14,.35],[.025,.22,.24]],95),
    sunset:palette('Sunset — Rose & Apricot',[[.68,.18,.27],[.83,.4,.2],[.56,.23,.48],[.4,.13,.38]],100),
    dawn:palette('Dawn — Blush & Lilac',[[.57,.29,.37],[.62,.42,.53],[.39,.29,.6],[.33,.44,.61]],88),
    champagne:palette('Champagne & Pearl',[[.5,.37,.2],[.58,.49,.36],[.37,.42,.49],[.47,.36,.38]],80),
    copper:palette('Copper & Plum',[[.48,.2,.11],[.55,.3,.18],[.36,.12,.28],[.41,.18,.3]],100),
    emerald:palette('Emerald Current',[[.025,.26,.15],[.08,.46,.25],[.02,.36,.33],[.09,.23,.23]],95),
    glacier:palette('Glacier — Ice & Azure',[[.21,.45,.65],[.16,.57,.62],[.25,.32,.63],[.25,.51,.59]],92),
    roseQuartz:palette('Rose Quartz',[[.57,.19,.31],[.62,.29,.45],[.4,.19,.48],[.47,.27,.4]],100),
    sapphireTeal:palette('Sapphire & Teal',[[.035,.19,.56],[.03,.4,.43],[.07,.3,.61],[.05,.31,.26]],112),
    dusk:palette('Dusk — Indigo & Ember',[[.13,.09,.33],[.34,.12,.35],[.49,.22,.14],[.19,.13,.39]],105),
    moonstone:palette('Moonstone',[[.27,.31,.4],[.37,.42,.49],[.38,.34,.45],[.25,.38,.39]],90),
    oledCyan:palette('OLED — Cyan Afterglow',[[.01,.34,.5],[.02,.51,.58],[.025,.24,.49],[.015,.43,.39]],90,true,.4),
    oledViolet:palette('OLED — Violet Afterglow',[[.22,.035,.4],[.4,.09,.61],[.11,.065,.47],[.32,.045,.35]],100,true,.42),
    oledAurora:palette('OLED — Aurora Edge',[[.015,.36,.19],[.015,.31,.4],[.22,.06,.43],[.05,.33,.23]],108,true,.43),
    oledBlue:palette('OLED — Electric Blue',[[.015,.07,.45],[.02,.23,.65],[.07,.11,.51],[.035,.18,.45]],90,true,.45),
    oledCrimson:palette('OLED — Crimson Glow',[[.38,.015,.075],[.58,.05,.16],[.28,.025,.18],[.47,.04,.045]],96,true,.42),
    oledAmber:palette('OLED — Amber Embers',[[.4,.16,.025],[.61,.33,.05],[.37,.11,.035],[.48,.22,.07]],92,true,.43),
    oledPearl:palette('OLED — Silver Halo',[[.3,.35,.42],[.43,.48,.52],[.38,.36,.45],[.28,.4,.42]],90,true,.46),
    oledPrism:palette('OLED — Prism Edge',[[.02,.34,.45],[.29,.05,.47],[.47,.1,.2],[.06,.37,.2]],100,true,.45),
    // Vivid palettes push saturation and brightness to the top of the ramp.
    vividNeon:palette('Vivid — Neon Prism',[[.04,.62,.98],[.82,.08,.72],[.98,.42,.04],[.08,.88,.36]],100),
    vividUltraviolet:palette('Vivid — Ultraviolet',[[.46,.04,.98],[.92,.08,.62],[.18,.22,.98],[.66,.04,.86]],108),
    vividTropic:palette('Vivid — Tropic Lagoon',[[0,.78,.72],[.96,.56,.04],[.92,.14,.42],[.04,.6,.98]],95),
    vividMint:palette('Vivid — Laser Mint',[[.04,.96,.56],[.04,.56,.96],[.36,.96,.24],[0,.82,.82]],92),
    vividSunburst:palette('Vivid — Sunburst',[[.98,.72,.04],[.96,.24,.08],[.98,.46,0],[.9,.1,.36]],100),
    vividCandy:palette('Vivid — Electric Candy',[[.98,.2,.66],[.3,.5,.98],[.6,.14,.98],[.98,.5,.2]],104),
    vividAurora:palette('Vivid — Polar Aurora',[[.04,.9,.46],[.1,.6,.98],[.56,.1,.96],[.04,.96,.76]],110),
    vividLava:palette('Vivid — Lava Flow',[[.96,.3,0],[.98,.76,.04],[.82,.04,.14],[.96,.5,.04]],96),
    vividOcean:palette('Vivid — Deep Reef',[[0,.5,.98],[.02,.9,.82],[.14,.2,.98],[0,.72,.6]],100),
    vividCyber:palette('Vivid OLED — Cyberwave',[[0,.86,.96],[.96,0,.66],[.3,0,.96],[0,.96,.56]],100,true,.42),
    vividArcade:palette('Vivid OLED — Arcade Night',[[0,.5,.98],[.76,0,.9],[.98,.16,.46],[0,.9,.6]],92,true,.44),
    vividEmber:palette('Vivid OLED — Molten Ember',[[.98,.4,0],[.98,.82,.1],[.9,.06,.22],[.98,.56,.02]],104,true,.42)
  };
  window.BACKGROUND_MOTION_STYLES={
    flow:{label:'Color Flow',mode:0},
    spectrum:{label:'Spectrum Sweep',mode:1},
    aurora:{label:'Aurora Drift',mode:2},
    orbit:{label:'Orbital Glow',mode:3}
  };
  window.BACKGROUND_MOTION_SETTINGS={
    preset:'console',colors:window.ANIMATED_BACKGROUND_PRESETS.console.colors,
    speed:1,strength:1,style:'flow',angle:90,rotation:0,cycleLength:90,
    exposure:1,blackFloor:false,blackPoint:0,blur:0,
    clipBounds:[0,1],fullHeight:0
  };
  // The host can omit rows guaranteed to remain pure black for the entire
  // cycle. Bounds use the same full-resolution pixel grid as the full canvas;
  // there is no downsampling or reduction in animated frame cadence.
  window.backgroundRenderBounds=function(settings,viewportHeight,dpr){
    const s=settings||window.BACKGROUND_MOTION_SETTINGS;
    const fullHeight=Math.max(1,Math.round(viewportHeight*dpr));
    if(!s.blackFloor||!Number.isFinite(fullHeight))return [0,1];
    const finite=(value,fallback)=>Number.isFinite(Number(value))?Number(value):fallback;
    const limit=(value,lo,hi)=>Math.min(hi,Math.max(lo,value));
    const chosen=window.ANIMATED_BACKGROUND_PRESETS[s.preset]||window.ANIMATED_BACKGROUND_PRESETS.console;
    const strength=limit(finite(s.strength,1),0,1),softness=limit(finite(s.blur,0)/24,0,1);
    const angle=(finite(s.angle,chosen.angle)+finite(s.rotation,0))*Math.PI/180;
    const amplitude=.11*strength*(1-softness*.7),lo=angle-amplitude,hi=angle+amplitude;
    // A horizontal direction or a changing vertical sign cannot share a
    // guaranteed black edge across every phase, so keep the complete canvas.
    if(Math.ceil(lo/Math.PI)*Math.PI<=hi)return [0,1];
    const sinLo=Math.sin(lo),sinHi=Math.sin(hi);
    if(sinLo*sinHi<=0)return [0,1];
    const ratio=a=>Math.abs(Math.cos(a))/(Math.abs(Math.cos(a))+Math.abs(Math.sin(a)));
    const rx=Math.max(ratio(lo),ratio(hi))+1e-6;
    let threshold=limit(finite(s.blackPoint,0),0,.85)-1e-6;
    const style=window.BACKGROUND_MOTION_STYLES[s.style]||window.BACKGROUND_MOTION_STYLES.flow;
    if(style.mode===2)threshold-=.12*strength*(1-softness*.8);
    else if(style.mode===3){
      const blend=.62*strength*(1-softness*.45);
      if(threshold<=blend)return [0,1];
      threshold=(threshold-blend)/(1-blend);
    }
    const edge=(threshold-rx)/(1-rx);
    // Retain one extra row beside the bound for floating-point rounding.
    const pixels=Math.max(0,Math.min(fullHeight-1,Math.floor(edge*fullHeight)-1));
    return sinLo>0?[pixels/fullHeight,1]:[0,1-pixels/fullHeight];
  };
  function shader(gl,type,source){
    const object=gl.createShader(type);gl.shaderSource(object,source);gl.compileShader(object);
    if(!gl.getShaderParameter(object,gl.COMPILE_STATUS)){
      const message=gl.getShaderInfoLog(object);gl.deleteShader(object);throw Error(message);
    }
    return object;
  }
  window.createAnimatedBackgroundLayer=function(gl,canvas){
    const vertex=shader(gl,gl.VERTEX_SHADER,`#version 300 es
      precision highp float;
      out vec2 uv;uniform vec2 clipBounds;
      void main(){
        vec2 position=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));
        uv=vec2(position.x,mix(1.-clipBounds.y,1.-clipBounds.x,position.y));gl_Position=vec4(position*2.-1.,0.,1.);
      }`);
    const fragment=shader(gl,gl.FRAGMENT_SHADER,`#version 300 es
      precision highp float;
      in vec2 uv;out vec4 frag;
      uniform vec3 color0,color1,color2,color3;
      uniform float phase,strength,style,angle,exposure,blackFloor,blackPoint,softness;
      uniform float ditherOffset,pulse;
      vec3 palette(float p){
        float slot=fract(p)*4.,fraction=smoothstep(0.,1.,fract(slot));
        if(slot<1.)return mix(color0,color1,fraction);
        if(slot<2.)return mix(color1,color2,fraction);
        if(slot<3.)return mix(color2,color3,fraction);
        return mix(color3,color0,fraction);
      }
      vec3 cycle(float offset){return mix(palette(offset),palette(phase+offset),strength);}
      void main(){
        const float tau=6.28318530718;
        float a=phase*tau;
        vec2 p=vec2(uv.x,1.-uv.y),center=p-.5;
        float rotation=.11*sin(a)*strength*(1.-softness*.7);
        vec2 direction=vec2(cos(angle+rotation),sin(angle+rotation));
        float extent=abs(direction.x)+abs(direction.y);
        float g=clamp(dot(center,direction)/extent+.5,0.,1.);
        if(style>1.5&&style<2.5){
          float bend=sin(p.x*5.2+a)*.075+sin(p.x*2.7-p.y*1.8-a)*.045;
          g=clamp(g+bend*strength*(1.-softness*.8),0.,1.);
        }else if(style>2.5){
          vec2 focus=vec2(.14*cos(a),.12*sin(a))*strength;
          float halo=1.-smoothstep(.08,.95,length(center-focus));
          g=clamp(mix(g,halo,.62*strength*(1.-softness*.45)),0.,1.);
        }
        // OLED palettes retain an exactly black region throughout the cycle.
        if(blackFloor>.5&&g<=blackPoint){frag=vec4(0.,0.,0.,1.);return;}
        g=clamp((g-blackPoint)/max(.05,1.-blackPoint),0.,1.);
        // Gradient softness broadens the colored region analytically. There
        // is no full-screen convolution or intermediate texture in this layer.
        g=mix(g,sqrt(g),softness*.24);
        vec3 low=cycle(.52)*(.026*(1.-blackFloor)),middle=cycle(.12)*.31,high=cycle(.28)*.9;
        vec3 color=g<.5 ? mix(low,middle,smoothstep(0.,.5,g)) : mix(middle,high,smoothstep(.5,1.,g));
        if(style>.5&&style<1.5){
          vec3 spectrum=mix(palette(g*.72),palette(phase+g*.72),strength);
          color=mix(color,spectrum*(.026*(1.-blackFloor)+.874*smoothstep(0.,1.,g)),.78);
        }
        // Music bloom: brightens the lit end of the gradient only, so black
        // regions stay black however loud the music gets.
        color*=exposure*(1.+pulse*smoothstep(.12,1.,g));
        // Spatial dither is fixed to pixel coordinates; no temporal grain.
        float dither=fract(52.9829189*fract(dot(gl_FragCoord.xy+vec2(0.,ditherOffset),vec2(.06711056,.00583715))));
        frag=vec4(clamp(color+(dither-.5)/255.,0.,1.),1.);
      }`);
    const program=gl.createProgram();gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);
    gl.deleteShader(vertex);gl.deleteShader(fragment);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
    const vao=gl.createVertexArray(),uniforms={};
    for(const name of ['color0','color1','color2','color3','clipBounds','ditherOffset','phase','strength','style','angle','exposure','blackFloor','blackPoint','softness','pulse'])uniforms[name]=gl.getUniformLocation(program,name);
    const clamp=(value,lo,hi)=>Math.min(hi,Math.max(lo,Number.isFinite(Number(value))?Number(value):lo));
    let dirty=true,lastWidth=0,lastHeight=0,cycleLength=90,cachedStrength=1,lastPhase=NaN,lastPulse=NaN,draws=0,settingUploads=0;
    function upload(){
      const s=window.BACKGROUND_MOTION_SETTINGS,defaultPalette=window.ANIMATED_BACKGROUND_PRESETS.console;
      const chosen=window.ANIMATED_BACKGROUND_PRESETS[s.preset]||defaultPalette;
      // wallpaper.js supplies the colours in use (preset or custom), which lets
      // a change of palette cross-fade instead of snapping.
      const colors=Array.isArray(s.colors)&&s.colors.length===4?s.colors:chosen.colors;
      for(let i=0;i<4;i++){
        const c=colors[i]||chosen.colors[i];
        gl.uniform3f(uniforms['color'+i],clamp(c[0],0,1),clamp(c[1],0,1),clamp(c[2],0,1));
      }
      const style=window.BACKGROUND_MOTION_STYLES[s.style]||window.BACKGROUND_MOTION_STYLES.flow;
      cachedStrength=clamp(s.strength,0,1);
      gl.uniform1f(uniforms.style,style.mode);gl.uniform1f(uniforms.strength,cachedStrength);
      gl.uniform1f(uniforms.angle,((s.angle??chosen.angle)+(s.rotation||0))*Math.PI/180);
      gl.uniform1f(uniforms.exposure,clamp(s.exposure??1,0,3));
      gl.uniform1f(uniforms.blackFloor,s.blackFloor?1:0);
      gl.uniform1f(uniforms.blackPoint,clamp(s.blackPoint||0,0,.85));
      gl.uniform1f(uniforms.softness,clamp((s.blur||0)/24,0,1));
      const bounds=s.clipBounds||[0,1],low=clamp(bounds[0],0,1),high=clamp(bounds[1],low,1);
      gl.uniform2f(uniforms.clipBounds,low,high);
      const fullHeight=Math.max(1,Math.round(Number(s.fullHeight)||canvas.height/Math.max(.001,high-low)));
      gl.uniform1f(uniforms.ditherOffset,Math.round(fullHeight*(1-high)));
      cycleLength=clamp(s.cycleLength||90,12,600);dirty=false;settingUploads++;
    }
    return {
      render(timeSeconds){
        const time=Number.isFinite(timeSeconds)?timeSeconds:0;
        const resized=canvas.width!==lastWidth||canvas.height!==lastHeight;
        const wrap=t=>cachedStrength===0?0:((t%cycleLength)+cycleLength)%cycleLength/cycleLength;
        let currentPhase=wrap(time);
        // A stopped background needs no GPU submission. Strength zero also
        // freezes its palette and spatial motion while the wave keeps moving.
        const pulse=clamp(window.BACKGROUND_MOTION_SETTINGS.pulse||0,0,2);
        // The palette moves very slowly: at the default 90 s cycle, one drawn
        // frame shifts it by far less than one 8-bit step. Redraw only once it
        // has moved by 1/24 of a second of cycle time (24 redraws a second at
        // normal speed, more when the cycle runs faster), instead of on every
        // frame of the wave. Any settings or display change redraws at once.
        let moved=Math.abs(currentPhase-lastPhase);if(moved>.5)moved=1-moved;
        if(!dirty&&!resized&&pulse===lastPulse&&!(moved>=1/(cycleLength*24)))return false;
        gl.useProgram(program);gl.bindVertexArray(vao);
        gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);
        if(resized){
          lastWidth=canvas.width;lastHeight=canvas.height;
          gl.viewport(0,0,lastWidth,lastHeight);
        }
        if(dirty)upload();
        // Only this one uniform changes per moving frame. Wrapping a closed
        // cycle avoids loss of float precision after days of running.
        currentPhase=wrap(time);
        gl.uniform1f(uniforms.phase,currentPhase);
        if(pulse!==lastPulse){gl.uniform1f(uniforms.pulse,pulse);lastPulse=pulse;}
        const span=window.XMB_SPAN,views=span&&span.active&&span.views?span.views:null;
        if(views){
          // Spanning: draw each display's rectangle only (the canvas's bounding
          // box includes area no display shows). Off displays are cleared to
          // black; paused ones are drawn at the phase they were paused at.
          // View rectangles are in full-frame pixels; this canvas may hold only a
          // band of the frame, starting this many rows above the frame's bottom.
          const s=window.BACKGROUND_MOTION_SETTINGS,bounds=s.clipBounds||[0,1],fullHeight=Math.max(1,Math.round(Number(s.fullHeight)||canvas.height)),below=Math.round(fullHeight*(1-clamp(bounds[1],0,1)));
          gl.enable(gl.SCISSOR_TEST);
          for(let i=0;i<views.length;i++){
            const v=views[i];gl.scissor(v.viewport[0],v.viewport[1]-below,v.viewport[2],v.viewport[3]);
            if(v.state==='off'){gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT);continue;}
            if(v.state==='paused'){gl.uniform1f(uniforms.phase,wrap(Number(v.frozenBackground)||0));gl.drawArrays(gl.TRIANGLES,0,3);gl.uniform1f(uniforms.phase,currentPhase);}
            else gl.drawArrays(gl.TRIANGLES,0,3);
          }
          gl.disable(gl.SCISSOR_TEST);
        }else gl.drawArrays(gl.TRIANGLES,0,3);
        draws++;lastPhase=currentPhase;
        return true;   // drawn this call; the menu glass copies fresh frames only
      },
      invalidate(){dirty=true;lastPhase=NaN;},
      getStats(){return {draws,settingUploads,cycleLength};},
      dispose(){gl.deleteVertexArray(vao);gl.deleteProgram(program);}
    };
  };
})();
