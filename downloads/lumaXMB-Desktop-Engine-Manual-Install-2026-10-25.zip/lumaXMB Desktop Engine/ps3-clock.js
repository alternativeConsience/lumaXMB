'use strict';
// PS3 system clock, ported from lumaXMB's PS3 status strip (draw_info in
// shell.c), with further designs built on the same parts. A highlight travels
// left to right on a breathing cycle: it lifts the outline, sweeps through the
// type as a shimmer, raises its glow and lights the clock glyph's halo. The
// date sits beside the time. Only the main display draws it: when one wave
// spans several displays the clock is placed on the primary's area.
//
// Designs: strip (the PS3 status strip), glass (a frosted pill), dark (a smoked
// pill), fade (type over a fading underline), bare (type alone), psp (the PSP's
// unboxed date and time). Colour follows the background or the wave when asked.
(() => {
 const canvas=document.createElement('canvas');canvas.id='clock-canvas';canvas.setAttribute('aria-hidden','true');
 canvas.style.cssText='position:absolute;left:0;top:0;pointer-events:none;z-index:5;display:none';
 document.body.appendChild(canvas);
 const ctx=canvas.getContext('2d');
 const FONT="'XMB Rodin','Segoe UI',system-ui,sans-serif";
 const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
 const ease=p=>{p=clamp(p,0,1);return p*p*(3-2*p);};
 const settings={clockEnabled:false,clockStyle:'strip',clockDate:true,clockHours:'24',clockSize:100,clockGlow:12,clockBrightness:100,clockBreath:6,clockOpacity:100,clockTint:'white',clockTintStrength:35,
  clockTextSize:100,clockLetterSpacing:0,clockGap:100,clockPadding:100,clockShimmer:100,clockShimmerWidth:30,clockTextBrightness:100,clockGlowBrightness:100};
 let reduced=false,area=null,dpr=1,lastDraw=0,hidden=document.hidden,fontPx=20,framePx=20;
 const origin=performance.now();
 const status={enabled:false,draws:0};
 window.ps3ClockStatus=status;

 function readSettings(){
  const cfg=window.XMBSettings?window.XMBSettings.get():{};
  for(const key of Object.keys(settings))if(key in cfg)settings[key]=cfg[key];
  reduced=Boolean(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches);
 }
 // The type is sized from the main display's physical size (about 4 mm cap
 // height at 100%) when the display reports it, else from its pixel height.
 function baseFont(){
  const list=window.XMB_DISPLAY_LAYOUT&&window.XMB_DISPLAY_LAYOUT.monitors;
  const primary=Array.isArray(list)?(list.find(m=>m.primary)||list[0]):null;
  let px;
  if(primary&&Array.isArray(primary.mm)&&primary.mm[1]>50&&Array.isArray(primary.rect)&&primary.rect[3]>0)px=area.height/primary.mm[1]*4.2;
  else px=area.height*.0115;
  return clamp(px,12,48)*settings.clockSize/100;
 }
 const centerY=()=>Math.max(Math.max(fontPx,framePx)*1.7,area.height*.028);
 function layout(){
  const span=window.XMB_SPAN&&window.XMB_SPAN.active?window.XMB_SPAN.primaryCss:null;
  area=span||{left:0,top:0,width:innerWidth,height:innerHeight};
  dpr=window.devicePixelRatio||1;
  // The frame (strip, glyph, padding) follows Clock size; the type also follows Text size.
  framePx=baseFont();fontPx=framePx*clamp(settings.clockTextSize,50,200)/100;
  const sc=framePx/17,height=Math.ceil(centerY()+Math.max(fontPx,framePx)*1.9+10*sc*clamp(settings.clockPadding,0,300)/100+8);
  canvas.style.left=area.left+'px';canvas.style.top=area.top+'px';canvas.style.width=area.width+'px';canvas.style.height=height+'px';
  const w=Math.round(area.width*dpr),h=Math.round(height*dpr);
  if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;
  status.area={...area,canvasHeight:height,fontPx};
  const estimate=centerY()+Math.max(fontPx,framePx)*.72+9*sc;
  if(!status.strip||Math.abs((status.stripBottom||0)-estimate)>4){status.stripBottom=estimate;window.dispatchEvent(new CustomEvent('xmb-clock-layout'));}
 }
 function labels(){
  const now=new Date();
  let time;
  if(settings.clockHours==='12'){const h=now.getHours()%12||12;time=h+':'+String(now.getMinutes()).padStart(2,'0')+(now.getHours()<12?' AM':' PM');}
  else time=String(now.getHours()).padStart(2,'0')+':'+String(now.getMinutes()).padStart(2,'0');
  let date='';
  if(settings.clockDate){try{date=new Intl.DateTimeFormat(undefined,{month:'2-digit',day:'2-digit'}).format(now);}catch(e){date=String(now.getMonth()+1).padStart(2,'0')+'/'+String(now.getDate()).padStart(2,'0');}}
  return {time,date};
 }
 // The ink: white, or white leaning towards the background's or the wave's hue.
 function inkColor(){
  const strength=clamp(settings.clockTintStrength/100,0,1)*.8;
  let hue=null;
  if(settings.clockTint==='palette'&&window.sceneTint)hue=window.sceneTint();
  else if(settings.clockTint==='wave'&&window.waveStatus&&Array.isArray(window.waveStatus.waveTintColor)){const c=window.waveStatus.waveTintColor,peak=Math.max(...c);hue=peak>.002?c.map(v=>clamp(v/peak,0,1)):null;}
  if(!hue||strength<=0)return [1,1,1];
  return hue.map(v=>1-(1-v)*strength);
 }
 const rgba=(rgb,a)=>'rgba('+rgb.map(v=>Math.round(clamp(v,0,1)*255)).join(',')+','+clamp(a,0,1).toFixed(4)+')';
 // Glow sprites: the blurred shadow of a label, rendered once per distinct text,
 // size, colour and blur, then composited each frame. The ink colour is
 // quantised so a slowly drifting tint does not rebuild them every frame.
 const glowCache=new Map();
 function glowSprite(value,size,color,blur,alpha){
  const inkKey=color.map(v=>Math.round(v*24)).join(',');
  let spacing='0px';try{spacing=ctx.letterSpacing||'0px';}catch(e){}
  const key=[value,size.toFixed(1),inkKey,blur.toFixed(1),alpha.toFixed(3),spacing,dpr].join('|');
  const cached=glowCache.get(key);if(cached)return cached;
  if(glowCache.size>32)glowCache.clear();
  const pad=Math.ceil(blur*2.5+4),w=Math.ceil(ctx.measureText(value).width)+pad*2,h=Math.ceil(size*1.5)+pad*2,baselineOffset=pad+size*1.1;
  const sprite=document.createElement('canvas');sprite.width=Math.max(1,Math.round(w*dpr));sprite.height=Math.max(1,Math.round(h*dpr));
  const g=sprite.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.font=ctx.font;g.textBaseline='alphabetic';
  try{g.letterSpacing=spacing;}catch(e){}
  // Draw the text far off the sprite with a shadow offset back onto it, so only the blur lands.
  const rgb=color.map(v=>Math.round(clamp(v,0,1)*255)).join(',');
  g.shadowColor='rgba('+rgb+','+alpha.toFixed(4)+')';g.shadowBlur=blur;g.shadowOffsetX=4096;g.fillStyle='#000';
  g.fillText(value,pad-4096,baselineOffset);
  const entry={canvas:sprite,pad,baseline:baselineOffset,w,h};glowCache.set(key,entry);return entry;
 }
 function pill(x,y,w,h,r){
  const rr=Math.min(r,h/2,w/2);
  ctx.beginPath();ctx.moveTo(x+rr,y);ctx.lineTo(x+w-rr,y);ctx.arcTo(x+w,y,x+w,y+rr,rr);ctx.lineTo(x+w,y+h-rr);ctx.arcTo(x+w,y+h,x+w-rr,y+h,rr);ctx.lineTo(x+rr,y+h);ctx.arcTo(x,y+h,x,y+h-rr,rr);ctx.lineTo(x,y+rr);ctx.arcTo(x,y,x+rr,y,rr);ctx.closePath();
 }
 function draw(now){
  // The clock lives on the main display; when that display is off, so is the clock.
  if(window.XMBMonitorState&&window.XMBMonitorState.primaryOff){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);return;}
  const style=settings.clockStyle,sc=framePx/17,glow=settings.clockGlow,b=clamp(settings.clockBrightness/100,.1,2.5),o=clamp(settings.clockOpacity/100,0,1);
  const shimmer=clamp(settings.clockShimmer/100,0,2.5),shimmerWidth=clamp(settings.clockShimmerWidth/100,.1,.8);
  // Music response (off unless enabled): the cached peak glow is laid over the
  // type in proportion to the music, so no sprite is rebuilt per frame.
  const music=clamp(window.XMBAudio&&window.XMBAudio.clockLevel||0,0,1);
  const tb=clamp(settings.clockTextBrightness/100,.1,2),gb=clamp(settings.clockGlowBrightness/100,0,2.5);
  const gap=14*sc*clamp(settings.clockGap,0,300)/100,pad=7*sc*clamp(settings.clockPadding,0,300)/100;
  const breath=Math.max(2,settings.clockBreath)*1000,t=now-origin;
  const phase=(t/breath)%1,pulse=reduced?0:.5-.5*Math.cos(t*2*Math.PI/breath);
  const highlight=reduced?.28:-.30+1.60*phase;
  const ink=inkColor(),white=a=>rgba(ink,a),black=a=>'rgba(0,0,0,'+clamp(a,0,1).toFixed(4)+')';
  const {time,date}=labels();
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,area.width,canvas.height/dpr);
  const size=style==='psp'?fontPx*1.25:fontPx;
  ctx.font=size+'px '+FONT;ctx.textBaseline='alphabetic';
  try{ctx.letterSpacing=(size*clamp(settings.clockLetterSpacing,-5,40)/100).toFixed(2)+'px';}catch(e){}
  const m=ctx.measureText('00:00'),ascent=m.actualBoundingBoxAscent||size*.72,descent=m.actualBoundingBoxDescent||0;
  const textH=Math.max(size*.6,ascent+descent),cy=centerY(),baseline=cy+(ascent-descent)/2;
  const boxed=style==='strip'||style==='glass'||style==='dark';
  const edge=style==='strip'?area.width+24*sc:area.width-16*sc;        // the PS3 strip runs off the right edge
  const timeW=ctx.measureText(time).width,dateW=date?ctx.measureText(date).width:0;
  let timeX,left,glyphX;
  if(style==='psp'){timeX=area.width-16*sc-timeW;left=timeX-(date?dateW+gap:0);glyphX=null;}
  else{timeX=area.width-Math.max(16,22*sc)-timeW;left=timeX-(date?dateW+gap:0)-33*sc;glyphX=left+15*sc;}
  const y=cy-textH/2-pad,h=textH+2*pad,width=edge-left,line=Math.max(1,sc*.8);
  // The travelling glow: its reach scales with Shimmer, its breadth with Shimmer width.
  const light=x=>ease(clamp(1-Math.abs((x-left)/Math.max(1,width)-highlight)/shimmerWidth,0,1))*shimmer;
  const segments=10;
  const alongX=(x0,x1,alphaAt)=>{const g=ctx.createLinearGradient(x0,0,x1,0);for(let i=0;i<=segments;i++){const u=i/segments;g.addColorStop(u,alphaAt(x0+(x1-x0)*u,u));}return g;};

  if(style==='strip'){
   // Glass: a cool translucent sheet, brighter at its top edge, shadow beneath.
   const sheet=ctx.createLinearGradient(0,y,0,y+h);sheet.addColorStop(0,white(.075*b*o));sheet.addColorStop(.5,white(.035*b*o));sheet.addColorStop(1,white(.05*b*o));
   ctx.fillStyle=sheet;ctx.fillRect(left,y,width,h);
   const shade=ctx.createLinearGradient(0,y+h,0,y+h+6*sc);shade.addColorStop(0,black(.22*o));shade.addColorStop(1,black(0));ctx.fillStyle=shade;ctx.fillRect(left+1,y+h,width,6*sc);
   // Bevel: four bands above and below each edge, lifted by the passing highlight.
   for(let band=0;band<4;band++)for(let e=0;e<2;e++){
    const by=e?y+h+band*line:y-(band+1)*line;
    let strength=band===0?(e?55:85):glow*(band===1?.70:band===2?.30:.10);strength*=(1+.055*pulse)*b*o;
    const lift=glow*(band===0?(e?5:6):band===1?2.4:band===2?1.05:.34)*b*o,x0=left-band*line;
    ctx.fillStyle=alongX(x0,edge,x=>white(clamp(strength+lift*light(x),0,255)/255));ctx.fillRect(x0,by,edge-x0,line);
   }
   ctx.fillStyle=alongX(left,edge,x=>white((.10+.30*light(x))*b*o));ctx.fillRect(left+line,y+line,width-line,line);
   ctx.fillStyle=white((75+glow*3*light(left))/255*b*o);ctx.fillRect(left,y,line,h);
   ctx.fillStyle=black(30/255*o);ctx.fillRect(left+line,y+1,line,h-2);
  }else if(style==='glass'||style==='dark'){
   // A pill of frosted (or smoked) glass: translucent body, inner top reflection,
   // a rim that brightens where the highlight passes, a sheen sweeping across,
   // and a soft outer glow breathing with the cycle.
   const dark=style==='dark',r=h/2,px=left-4*sc,pw=edge-px;
   ctx.save();pill(px,y,pw,h,r);ctx.clip();
   const sheet=ctx.createLinearGradient(0,y,0,y+h);
   if(dark){sheet.addColorStop(0,black(.42*o));sheet.addColorStop(1,black(.58*o));}
   else{sheet.addColorStop(0,white(.24*b*o));sheet.addColorStop(.55,white(.11*b*o));sheet.addColorStop(1,white(.16*b*o));}
   ctx.fillStyle=sheet;ctx.fillRect(px,y,pw,h);
   const reflection=ctx.createLinearGradient(0,y,0,y+h*.45);reflection.addColorStop(0,white((dark?.14:.30)*b*o));reflection.addColorStop(1,white(0));ctx.fillStyle=reflection;ctx.fillRect(px,y,pw,h*.45);
   const sheenX=px+pw*highlight,sheenW=pw*.30;
   const sheen=ctx.createLinearGradient(sheenX-sheenW,0,sheenX+sheenW,0);sheen.addColorStop(0,white(0));sheen.addColorStop(.5,white((dark?.09:.14)*b*o*(.7+.3*pulse)));sheen.addColorStop(1,white(0));
   ctx.fillStyle=sheen;ctx.fillRect(px,y,pw,h);
   ctx.restore();
   ctx.save();pill(px,y,pw,h,r);
   ctx.shadowColor=white((dark?.18:.22)*b*o*(.5+.5*pulse)*glow/12);ctx.shadowBlur=10*sc;
   ctx.lineWidth=Math.max(1,sc*.9);ctx.strokeStyle=alongX(px,px+pw,x=>white(((dark?.28:.22)+.5*light(x))*b*o));ctx.stroke();
   ctx.restore();
   const shade=ctx.createLinearGradient(0,y+h,0,y+h+8*sc);shade.addColorStop(0,black(.18*o));shade.addColorStop(1,black(0));ctx.fillStyle=shade;ctx.fillRect(px+r*.5,y+h,pw-r,8*sc);
  }else if(style==='fade'){
   // No sheet: a shade fading in towards the right edge for legibility, and a
   // hairline beneath the type that fades in from the left and shimmers.
   const shade=ctx.createLinearGradient(left-40*sc,0,area.width,0);shade.addColorStop(0,black(0));shade.addColorStop(1,black(.22*o));ctx.fillStyle=shade;ctx.fillRect(left-40*sc,y-2*sc,area.width-left+40*sc,h+4*sc);
   ctx.fillStyle=alongX(left-30*sc,edge,(x,u)=>white(clamp(u*1.4,0,1)*(.22+.55*light(x))*b*o));ctx.fillRect(left-30*sc,y+h+1,edge-left+30*sc,line);
  }
  // Clock glyph with its halo.
  if(glyphX!==null){
   const gx=glyphX,gy=y+h/2,shine=light(gx)*glow/50,gs=14*sc;
   if(shine>.01&&gb>0){const halo=ctx.createRadialGradient(gx,gy,0,gx,gy,13*sc);halo.addColorStop(0,white(shine*.42*b*gb));halo.addColorStop(1,white(0));ctx.fillStyle=halo;ctx.fillRect(gx-13*sc,gy-13*sc,26*sc,26*sc);}
   ctx.strokeStyle=white(clamp((.84*b+.16*light(gx))*tb,0,1));ctx.lineWidth=Math.max(1,gs*.085);ctx.lineCap='round';
   ctx.beginPath();ctx.arc(gx,gy,gs*.42,0,Math.PI*2);ctx.stroke();
   ctx.beginPath();ctx.moveTo(gx,gy-gs*.29);ctx.lineTo(gx,gy);ctx.lineTo(gx+gs*.23,gy+gs*.10);ctx.stroke();
  }
  // Type: a drop shadow; the glow, drawn from two cached sprites (resting and
  // peak) blended by the passing light instead of blurring text every frame;
  // then the glyphs filled by a gradient whose bright crest sits where the
  // highlight is, so text and outline shimmer as one. Minimal Fade breathes.
  const breathe=style==='fade'?.78+.22*(1-pulse):1,blurScale=clamp(glow/12,.2,2.5);
  const text=(x,value)=>{
   const w=ctx.measureText(value).width,center=x+w/2,l=clamp(light(center),0,1);
   ctx.save();
   ctx.fillStyle=black(.42*clamp(b,0,1)*breathe);ctx.fillText(value,x+1.2*sc,baseline+1.7*sc);
   if(gb>0){
    const rest=glowSprite(value,size,ink,2*sc*blurScale,clamp(b*gb*.08,0,.95)),peak=glowSprite(value,size,ink,14*sc*blurScale,clamp(b*gb*.55*glow/30,0,.95));
    ctx.globalAlpha=breathe;ctx.drawImage(rest.canvas,x-rest.pad,baseline-rest.baseline,rest.w,rest.h);
    const lit=clamp(l+music*(1-l),0,1);
    if(lit>.01){ctx.globalAlpha=breathe*lit;ctx.drawImage(peak.canvas,x-peak.pad,baseline-peak.baseline,peak.w,peak.h);}
    ctx.globalAlpha=1;
   }
   const fill=ctx.createLinearGradient(x,0,x+w,0);
   for(let i=0;i<=6;i++){const u=i/6,lu=light(x+w*u);fill.addColorStop(u,white(clamp(b*tb*(.72+.28*lu),0,1)*breathe));}
   ctx.fillStyle=fill;ctx.fillText(value,x,baseline);
   ctx.restore();
  };
  if(date)text(style==='psp'?left:left+31*sc,date);
  text(timeX,time);
  status.draws++;status.left=left;status.strip=[y,h];status.phase=phase;status.style=style;status.ink=ink;
  const bottom=y+h+(boxed?4:2)*sc;if(Math.abs((status.stripBottom||0)-bottom)>1){status.stripBottom=bottom;window.dispatchEvent(new CustomEvent('xmb-clock-layout'));}
 }
 // The clock redraws only right after the wave draws a frame (wallpaper.js
 // runs XMBFrameHooks then), about 30 times a second: every 2nd frame at 60 fps,
 // every 4th at 120. Its own timer used to land between the wave's frames, and
 // each such update made the host present an extra full-desktop frame.
 let lastTick=0;
 function tick(now){
  lastTick=performance.now();
  if(!settings.clockEnabled||hidden)return;
  const interval=reduced?1000:33;
  if(now-lastDraw>=interval-2){lastDraw=now;try{draw(now);}catch(e){status.error=String(e);}}
 }
 (window.XMBFrameHooks=window.XMBFrameHooks||[]).push(tick);
 // While the wave is not drawing (paused), keep the time current once a second.
 setInterval(()=>{if(settings.clockEnabled&&!hidden&&performance.now()-lastTick>600){const now=performance.now();lastDraw=now;try{draw(now);}catch(e){status.error=String(e);}}},1000);
 function apply(){
  readSettings();status.enabled=Boolean(settings.clockEnabled);
  if(!settings.clockEnabled){canvas.style.display='none';status.strip=null;status.stripBottom=0;window.dispatchEvent(new CustomEvent('xmb-clock-layout'));return;}
  layout();canvas.style.display='block';lastDraw=0;
 }
 window.addEventListener('xmb-settings',e=>{if(Object.keys(e.detail.props||{}).some(k=>k.startsWith('clock'))||!status.enabled!==!(e.detail.config&&e.detail.config.clockEnabled))apply();});
 window.addEventListener('xmb-viewport',apply);
 window.addEventListener('xmb-display-layout',apply);
 window.addEventListener('resize',apply);
 document.addEventListener('visibilitychange',()=>{hidden=document.hidden;lastDraw=0;});
 if(document.fonts&&document.fonts.load)document.fonts.load("17px 'XMB Rodin'").then(()=>{lastDraw=0;}).catch(()=>{});
 apply();
})();
