'use strict';
// Opt-in spatial effects. Disabled effects use the existing native-MSAA canvas
// directly; enabled effects reuse GPU targets and never retain an earlier frame.
(() => {
  window.EFFECT_SETTINGS=window.EFFECT_SETTINGS||{glow:0,glowRadius:12,glowThreshold:.55,glowTint:[.7,.85,1],blur:0,blurQuality:'balanced'};
  const vertex=`#version 300 es
    out vec2 uv;
    void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);uv=p;gl_Position=vec4(p*2.-1.,0.,1.);}`;
  const breathingMask=`
    uniform float breathPhase,breathMode,breathWidth,breathSoftness,breathMinimum;
    float breathingMask(float x){
      float envelope;
      if(breathMode<.5){
        envelope=.5-.5*cos(6.28318530718*breathPhase);
        envelope=envelope*envelope*(3.-2.*envelope);
      }else{
        float radius=max(.025,breathWidth*.5);
        float center=mix(-radius,1.+radius,breathPhase);
        if(breathMode>1.5&&breathMode<2.5)center=1.-center;
        else if(breathMode>2.5&&breathMode<3.5)center=.5-.5*cos(6.28318530718*breathPhase);
        if(breathMode>3.5){x=abs(x-.5)*2.;if(breathMode>4.5)x=1.-x;}
        envelope=1.-smoothstep(radius*(1.-breathSoftness),radius,abs(x-center));
      }
      return mix(breathMinimum,1.,envelope);
    }`;
  window.createEffectsLayer=function(gl,canvas){
    const maximumSize=Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE),gl.getParameter(gl.MAX_RENDERBUFFER_SIZE));
    const normalSamples=gl.getInternalformatParameter(gl.RENDERBUFFER,gl.RGBA8,gl.SAMPLES);
    const supportedSamples=Array.from(normalSamples).filter(value=>value>0).sort((a,b)=>a-b);
    const bestSamples=list=>Math.max(0,...Array.from(list));
    const capabilities={webgl2MSAA:true,supportedSamples,maxSamples:bestSamples(normalSamples),independentAA:true,output:'SDR RGBA8',maxTextureSize:maximumSize};
    const stats={active:false,allocationCount:0,gpuTargetCount:0,programCount:0,drawsPerFrame:0,sceneSamples:0,sceneFormat:'direct',bloomSize:[0,0],blurSize:[0,0],warning:null};
    const targets=Object.create(null);
    let scene=null,resolved=null,vao=null,programs=null,format=null,type=null;
    // Halo images (glow, breathing, blur, and their shared quarter-size copy)
    // hold long, faint gradients; at 8 bits, stretched four times over, each
    // step shows as a band. They use 16-bit float where the GPU can render to
    // it, 8-bit otherwise. The resolved scene stays 8-bit: it is a straight
    // copy of the 8-bit multisampled scene.
    let haloFormat=gl.getExtension('EXT_color_buffer_float')?gl.RGBA16F:gl.RGBA8;
    const haloType=()=>haloFormat===gl.RGBA16F?gl.HALF_FLOAT:gl.UNSIGNED_BYTE;
    stats.haloFormat=haloFormat===gl.RGBA16F?'RGBA16F':'RGBA8';
    let width=0,height=0,frameActive=false,blockedWidth=0,blockedHeight=0,blockedQuality='',activeGlow=0,activeBlur=0,activeBreath=0;
    // Work regions (spanning; see wallpaper.js): when set, only these
    // rectangles are resolved and composited. A change of regions clears the
    // whole scene once, so nothing from the old layout can linger outside them.
    let regions=null,regionKey='',fullClear=true;
    const BREATH_MODES=['full','ltr','rtl','bounce','center','edges'];
    stats.breathing={enabled:false,phase:0,mode:'full',intensity:0,tint:null};
    function eachRegion(fn){if(!regions){fn(0,0,width,height);return;}for(let i=0;i<regions.length;i++){const r=regions[i];fn(r[0],r[1],r[2],r[3]);}}
    const current={glowRadius:12,glowThreshold:.55,glowTint:[.7,.85,1],blurQuality:'balanced'};
    const bounded=(value,fallback,low,high)=>Number.isFinite(Number(value))?Math.min(high,Math.max(low,Number(value))):fallback;
    function program(fragment,names){
      const result=gl.createProgram();
      for(const [kind,source] of [[gl.VERTEX_SHADER,vertex],[gl.FRAGMENT_SHADER,fragment]]){
        const shader=gl.createShader(kind);gl.shaderSource(shader,source);gl.compileShader(shader);
        if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(shader)||'Effects shader failed');
        gl.attachShader(result,shader);gl.deleteShader(shader);
      }
      gl.linkProgram(result);
      if(!gl.getProgramParameter(result,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(result)||'Effects program failed');
      const uniforms=Object.create(null);for(const name of names)uniforms[name]=gl.getUniformLocation(result,name);
      stats.programCount++;return {value:result,u:uniforms,previous:Object.create(null)};
    }
    function uniform1f(p,name,value){
      if(p.previous[name]===value)return;
      gl.uniform1f(p.u[name],value);p.previous[name]=value;
    }
    function uniform2f(p,name,x,y){
      let previous=p.previous[name];
      if(previous&&previous[0]===x&&previous[1]===y)return;
      gl.uniform2f(p.u[name],x,y);
      if(!previous)previous=p.previous[name]=[x,y];else{previous[0]=x;previous[1]=y;}
    }
    function uniform3fv(p,name,value){
      let previous=p.previous[name];
      if(previous&&previous[0]===value[0]&&previous[1]===value[1]&&previous[2]===value[2])return;
      gl.uniform3fv(p.u[name],value);
      if(!previous)previous=p.previous[name]=[value[0],value[1],value[2]];
      else{previous[0]=value[0];previous[1]=value[1];previous[2]=value[2];}
    }
    function ensurePrograms(){
      if(programs)return;
      vao=gl.createVertexArray();
      const downsample=program(`#version 300 es
        precision highp float;in vec2 uv;out vec4 frag;
        uniform sampler2D source;uniform vec2 sampleOffset;uniform float threshold,extract;
        uniform float breathExtract;
        ${breathingMask}
        void main(){
          vec4 c=(texture(source,uv+vec2(-sampleOffset.x,-sampleOffset.y))+
            texture(source,uv+vec2(sampleOffset.x,-sampleOffset.y))+
            texture(source,uv+vec2(-sampleOffset.x,sampleOffset.y))+
            texture(source,uv+sampleOffset))*.25;
          if(extract>.5){
            float peak=max(c.r,max(c.g,c.b));
            float knee=max(.025,threshold*.4);
            float contribution=smoothstep(max(0.,threshold-knee),threshold+knee,peak);
            c=vec4(c.rgb*contribution,max(c.a,peak*.12)*contribution);
          }
          if(breathExtract>.5)c*=breathingMask(uv.x);
          frag=c;
        }`,['source','sampleOffset','threshold','extract','breathExtract','breathPhase','breathMode','breathWidth','breathSoftness','breathMinimum']);
      const blur=program(`#version 300 es
        precision highp float;in vec2 uv;out vec4 frag;
        uniform sampler2D source;uniform vec2 direction;
        void main(){
          vec4 c=texture(source,uv)*.2270270270;
          c+=(texture(source,uv+direction*1.3846153846)+texture(source,uv-direction*1.3846153846))*.3162162162;
          c+=(texture(source,uv+direction*3.2307692308)+texture(source,uv-direction*3.2307692308))*.0702702703;
          frag=c;
        }`,['source','direction']);
      const composite=program(`#version 300 es
        precision highp float;in vec2 uv;out vec4 frag;
        uniform sampler2D scene,bloom,breathBloom;
        uniform float glow,breathStrength;
        uniform vec3 glowTint,breathTint;
        ${breathingMask}
        void main(){
          vec4 c=texture(scene,uv);
          vec4 light=glow>0.?texture(bloom,uv):vec4(0.);
          c.rgb+=light.rgb*glowTint*glow;
          // The sheet deliberately carries additive reflections (RGB > alpha).
          // Preserve those values; a halo adds only a small absorption term.
          c.a=clamp(c.a+light.a*glow*.12,0.,1.);
          if(breathStrength>0.){
            vec4 halo=texture(breathBloom,uv);
            // A restrained core lift keeps the breath visible on Clear glass;
            // the separately blurred, masked source supplies the soft halo.
            vec3 core=texture(scene,uv).rgb*breathingMask(uv.x)*.65;
            c.rgb+=(core+halo.rgb)*breathTint*breathStrength;
            c.a=clamp(c.a+halo.a*breathStrength*.08,0.,1.);
          }
          // The halos arrive with fractional precision; a fixed, decorrelated
          // dither of under half a step carries it into the 8-bit screen as an
          // even gradient instead of bands. Empty pixels stay exactly empty.
          float n1=fract(52.9829189*fract(dot(gl_FragCoord.xy,vec2(.06711056,.00583715))))-.5;
          float n2=fract(52.9829189*fract(dot(gl_FragCoord.xy+vec2(17.,31.),vec2(.06711056,.00583715))))-.5;
          frag=vec4(max(c.rgb+vec3(n1*.98/255.),0.),clamp(c.a+n2*.98/255.,0.,1.));
        }`,['scene','bloom','glow','glowTint','breathBloom','breathStrength','breathTint','breathPhase','breathMode','breathWidth','breathSoftness','breathMinimum']);
      programs={downsample,blur,composite};
      gl.useProgram(downsample.value);gl.uniform1i(downsample.u.source,0);
      gl.useProgram(blur.value);gl.uniform1i(blur.u.source,0);
      gl.useProgram(composite.value);gl.uniform1i(composite.u.scene,0);gl.uniform1i(composite.u.bloom,1);
      gl.uniform1i(composite.u.breathBloom,2);
    }
    function checkTarget(){
      const status=gl.checkFramebufferStatus(gl.FRAMEBUFFER);
      if(status!==gl.FRAMEBUFFER_COMPLETE)throw Error('Effects framebuffer unavailable ('+status+')');
    }
    function textureTarget(name,w,h,halo=false){
      let target=targets[name];
      if(!target){target=targets[name]={texture:gl.createTexture(),framebuffer:gl.createFramebuffer(),width:0,height:0,format:null};stats.gpuTargetCount++;}
      const fmt=halo?haloFormat:format,typ=halo?haloType():type;
      if(target.width!==w||target.height!==h||target.format!==fmt){
        gl.bindTexture(gl.TEXTURE_2D,target.texture);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
        gl.texImage2D(gl.TEXTURE_2D,0,fmt,w,h,0,gl.RGBA,typ,null);
        gl.bindFramebuffer(gl.FRAMEBUFFER,target.framebuffer);
        gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,target.texture,0);
        // A GPU that cannot render to 16-bit float falls back to 8-bit halos.
        if(halo&&fmt!==gl.RGBA8&&gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE){
          haloFormat=gl.RGBA8;stats.haloFormat='RGBA8';target.format=null;return textureTarget(name,w,h,true);
        }
        checkTarget();target.width=w;target.height=h;target.format=fmt;stats.allocationCount++;
      }
      return target;
    }
    function releaseTextureTarget(name){
      const target=targets[name];if(!target)return;
      gl.deleteTexture(target.texture);gl.deleteFramebuffer(target.framebuffer);delete targets[name];stats.gpuTargetCount--;
    }
    function releaseScene(){
      if(!scene)return;
      gl.deleteFramebuffer(scene.framebuffer);gl.deleteRenderbuffer(scene.buffer);scene=null;stats.gpuTargetCount--;
    }
    function ensureScene(){
      ensurePrograms();
      const nextWidth=Math.max(1,Math.min(maximumSize,canvas.width)),nextHeight=Math.max(1,Math.min(maximumSize,canvas.height));
      const nextFormat=gl.RGBA8;
      // A substantial spatial blur removes subpixel edges. Keep four samples
      // for subtle blur, sharp glow, and the explicit High quality option.
      const requested=Number(current.antiAliasing),available=supportedSamples.filter(value=>value<=requested);
      const samples=requested===0?0:available.length?Math.max(...available):supportedSamples[0]||0;
      stats.requestedSamples=requested;stats.independentAA=true;
      format=nextFormat;type=gl.UNSIGNED_BYTE;
      width=nextWidth;height=nextHeight;
      resolved=textureTarget('resolved',width,height);
      // Single-sample blurred scenes can render into their texture directly.
      // Sharp scenes keep the same four-sample renderbuffer and resolve.
      if(samples===0)releaseScene();
      else{
        if(!scene){scene={framebuffer:gl.createFramebuffer(),buffer:gl.createRenderbuffer(),width:0,height:0,format:null,samples:0};stats.gpuTargetCount++;}
        if(scene.width!==width||scene.height!==height||scene.format!==format||scene.samples!==samples){
          gl.bindRenderbuffer(gl.RENDERBUFFER,scene.buffer);
          gl.renderbufferStorageMultisample(gl.RENDERBUFFER,samples,format,width,height);
          gl.bindFramebuffer(gl.FRAMEBUFFER,scene.framebuffer);
          gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.RENDERBUFFER,scene.buffer);
          checkTarget();Object.assign(scene,{width,height,format,samples});stats.allocationCount++;
        }
      }
      stats.sceneSamples=samples;stats.sceneFormat='RGBA8';
      if(activeGlow>0){
        const w=Math.max(1,Math.ceil(width*.25)),h=Math.max(1,Math.ceil(height*.25));
        textureTarget('glowA',w,h,true);textureTarget('glowB',w,h,true);stats.bloomSize[0]=w;stats.bloomSize[1]=h;
      }else{releaseTextureTarget('glowA');releaseTextureTarget('glowB');stats.bloomSize[0]=stats.bloomSize[1]=0;}
      if(activeBreath>0){
        const w=Math.max(1,Math.ceil(width*.25)),h=Math.max(1,Math.ceil(height*.25));
        textureTarget('breathA',w,h,true);textureTarget('breathB',w,h,true);
      }else{releaseTextureTarget('breathA');releaseTextureTarget('breathB');}
      // Glow and breathing together share one quarter-size copy of the scene.
      if(activeGlow>0&&activeBreath>0)textureTarget('quarter',Math.max(1,Math.ceil(width*.25)),Math.max(1,Math.ceil(height*.25)),true);
      else releaseTextureTarget('quarter');
      if(activeBlur>0){
        const scale=current.blurQuality==='high'?1:current.blurQuality==='fast'?.25:.5;
        const w=Math.max(1,Math.ceil(width*scale)),h=Math.max(1,Math.ceil(height*scale));
        textureTarget('blurA',w,h,true);textureTarget('blurB',w,h,true);stats.blurSize[0]=w;stats.blurSize[1]=h;
      }else{releaseTextureTarget('blurA');releaseTextureTarget('blurB');stats.blurSize[0]=stats.blurSize[1]=0;}
    }
    function bindSource(texture,unit=0){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,texture);}
    function pass(program,target,texture){
      gl.bindFramebuffer(gl.FRAMEBUFFER,target.framebuffer);gl.viewport(0,0,target.width,target.height);
      gl.useProgram(program.value);bindSource(texture);gl.drawArrays(gl.TRIANGLES,0,3);stats.drawsPerFrame++;
    }
    function uploadBreathing(p){
      for(const name of ['breathPhase','breathMode','breathWidth','breathSoftness','breathMinimum'])uniform1f(p,name,current[name]);
    }
    // offset .5 averages four taps around each target texel (a downsample);
    // offset 0 reads one texel exactly (an extract from a same-size copy).
    function downsample(source,target,extract,breathing=false,offset=.5){
      const p=programs.downsample;gl.useProgram(p.value);
      uniform2f(p,'sampleOffset',offset/target.width,offset/target.height);
      uniform1f(p,'extract',extract?1:0);uniform1f(p,'threshold',breathing?current.breatheThreshold:current.glowThreshold);
      uniform1f(p,'breathExtract',breathing?1:0);uploadBreathing(p);
      pass(p,target,source.texture);
    }
    function spatialBlur(a,b,radius){
      const p=programs.blur,scale=canvas.width/Math.max(1,window.innerWidth||canvas.width),distance=radius*scale/3.2307692308;
      gl.useProgram(p.value);uniform2f(p,'direction',distance/width,0);pass(p,b,a.texture);
      gl.useProgram(p.value);uniform2f(p,'direction',0,distance/height);pass(p,a,b.texture);
      return a;
    }
    function releaseTargets(){
      gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindRenderbuffer(gl.RENDERBUFFER,null);
      for(const name of Object.keys(targets))releaseTextureTarget(name);
      releaseScene();resolved=null;width=0;height=0;stats.gpuTargetCount=0;stats.sceneSamples=0;
      stats.bloomSize[0]=stats.bloomSize[1]=stats.blurSize[0]=stats.blurSize[1]=0;
    }
    function begin(time=0){
      const s=window.EFFECT_SETTINGS||{};
      activeGlow=bounded(s.glow,0,0,3);activeBlur=bounded(s.blur,0,0,32);
      activeBreath=s.breatheEnabled?bounded(s.breatheIntensity,.85,0,3):0;
      const period=bounded(s.breathePeriod,9,2,60);
      current.breathPhase=((time%period)+period)%period/period;
      current.breathMode=Math.max(0,BREATH_MODES.indexOf(s.breatheMode));
      current.breathWidth=bounded(s.breatheWidth,60,5,150)/100;
      current.breathSoftness=bounded(s.breatheSoftness,.9,.1,1);
      current.breathMinimum=bounded(s.breatheMinimum,4,0,100)/100;
      current.breatheThreshold=bounded(s.breatheThreshold,.025,0,1);
      current.breatheRadius=bounded(s.breatheRadius,22,2,60);
      current.breathTint=s.breatheTintMode==='wave'?(window.waveStatus.waveTintColor||s.breatheTint||[1,1,1]):s.breatheTintMode==='palette'?backgroundTint(s):s.breatheTint||[.72,.84,1];
      const b=stats.breathing;b.enabled=activeBreath>0;b.phase=current.breathPhase;b.mode=s.breatheMode||'full';b.intensity=activeBreath;b.tint=current.breathTint;
      stats.active=true;stats.drawsPerFrame=0;frameActive=false;
      if(!stats.active){
        // Release large GPU images once on disable, while keeping compiled
        // programs. Ordinary off frames retain the allocation-free direct path.
        if(resolved)releaseTargets();stats.sceneFormat='direct';
        gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);return null;
      }
      current.antiAliasing=String(s.antiAliasing??'4');
      current.glowRadius=bounded(s.glowRadius,12,1,80);current.glowThreshold=bounded(s.glowThreshold,.55,0,1.5);
      current.glowTint=s.glowTint||current.glowTint;current.blurQuality=s.blurQuality||'balanced';
      if(blockedWidth===canvas.width&&blockedHeight===canvas.height&&blockedQuality===current.blurQuality+current.antiAliasing){
        stats.active=false;gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);return null;
      }
      try{ensureScene();}catch(error){
        blockedWidth=canvas.width;blockedHeight=canvas.height;blockedQuality=current.blurQuality+current.antiAliasing;
        stats.warning=String(error.message||error);stats.active=false;
        gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);return null;
      }
      stats.warning=null;
      const next=(window.SPLINE_SETTINGS&&window.SPLINE_SETTINGS.regions)||null,key=next?next.join('|'):'';
      if(key!==regionKey){regionKey=key;fullClear=true;}
      regions=next;stats.regions=regions?regions.length:0;
      if(fullClear){
        // Once per layout change: the whole scene and resolved image to clear.
        gl.disable(gl.SCISSOR_TEST);gl.clearColor(0,0,0,0);
        if(scene){gl.bindFramebuffer(gl.FRAMEBUFFER,scene.framebuffer);gl.clear(gl.COLOR_BUFFER_BIT);}
        gl.bindFramebuffer(gl.FRAMEBUFFER,resolved.framebuffer);gl.clear(gl.COLOR_BUFFER_BIT);fullClear=false;
      }
      const framebuffer=scene?scene.framebuffer:resolved.framebuffer;
      frameActive=true;gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer);gl.viewport(0,0,width,height);
      return framebuffer;
    }
    function end(){
      if(!frameActive)return;
      gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);gl.bindVertexArray(vao);
      const plain=!(activeBlur>0||activeGlow>0||activeBreath>0);
      if(scene){
        // With no glow, blur or breathing the multisampled scene resolves
        // straight into the canvas: no intermediate image, no copy pass.
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,scene.framebuffer);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,plain?null:resolved.framebuffer);
        eachRegion((x,y,w,h)=>gl.blitFramebuffer(x,y,x+w,y+h,x,y,x+w,y+h,gl.COLOR_BUFFER_BIT,gl.NEAREST));
        stats.sceneFormat=plain?'direct resolve':'RGBA8';
        if(plain){gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);gl.bindVertexArray(null);frameActive=false;return;}
      }
      let output=resolved;
      if(activeBlur>0){downsample(resolved,targets.blurA,false);output=spatialBlur(targets.blurA,targets.blurB,activeBlur);}
      if(activeGlow>0&&activeBreath>0){
        // One read of the full-size scene feeds both halos; each extract then
        // reads the shared quarter-size copy texel for texel, which gives the
        // same values as extracting from the full-size scene directly.
        downsample(resolved,targets.quarter,false);
        downsample(targets.quarter,targets.glowA,true,false,0);spatialBlur(targets.glowA,targets.glowB,current.glowRadius);
        downsample(targets.quarter,targets.breathA,true,true,0);spatialBlur(targets.breathA,targets.breathB,current.breatheRadius);
      }else{
        if(activeGlow>0){downsample(resolved,targets.glowA,true);spatialBlur(targets.glowA,targets.glowB,current.glowRadius);}
        if(activeBreath>0){downsample(resolved,targets.breathA,true,true);spatialBlur(targets.breathA,targets.breathB,current.breatheRadius);}
      }
      const p=programs.composite;gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);gl.useProgram(p.value);
      bindSource(output.texture);bindSource(activeGlow>0?targets.glowA.texture:resolved.texture,1);
      uniform1f(p,'glow',activeGlow);uniform3fv(p,'glowTint',current.glowTint);
      bindSource(activeBreath>0?targets.breathA.texture:resolved.texture,2);
      uniform1f(p,'breathStrength',activeBreath);uniform3fv(p,'breathTint',current.breathTint);uploadBreathing(p);
      // The composite shades only the work regions.
      if(regions){gl.enable(gl.SCISSOR_TEST);eachRegion((x,y,w,h)=>{gl.scissor(x,y,w,h);gl.drawArrays(gl.TRIANGLES,0,3);});gl.disable(gl.SCISSOR_TEST);}
      else gl.drawArrays(gl.TRIANGLES,0,3);
      stats.drawsPerFrame++;gl.bindVertexArray(null);gl.activeTexture(gl.TEXTURE0);frameActive=false;
    }
    function resize(){blockedWidth=0;blockedHeight=0;blockedQuality='';fullClear=true;}
    function backgroundTint(s){
      if(!s.breathePaletteAnimated)return s.breathePaletteColor||[.72,.78,.85];
      const a=window.BACKGROUND_MOTION_SETTINGS,colors=a.colors;
      const phase=((s.breatheBackgroundTime%a.cycleLength)+a.cycleLength)%a.cycleLength/a.cycleLength;
      function palette(p){const slot=((p%1)+1)%1*4,i=Math.floor(slot),f=slot-i,t=f*f*(3-2*f);return colors[i].map((v,c)=>v+(colors[(i+1)%4][c]-v)*t);}
      const low=palette(.12),high=palette(phase+.12),color=low.map((v,c)=>v+(high[c]-v)*a.strength),peak=Math.max(...color);
      return peak>.0001?color.map(v=>v/peak):[.72,.78,.85];
    }
    function dispose(){
      releaseTargets();
      if(programs)for(const p of Object.values(programs))gl.deleteProgram(p.value);
      if(vao)gl.deleteVertexArray(vao);scene=null;resolved=null;programs=null;vao=null;frameActive=false;
    }
    return {begin,end,resize,dispose,stats,capabilities};
  };
})();
