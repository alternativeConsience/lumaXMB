'use strict';
// Music response presets. Choosing one sets the response sliders together;
// moving any of those sliders afterwards turns the preset to Custom, as the
// breathing-glow presets do. Every preset keeps the response in the wave
// itself: glow and light first, slow travelling swells second, the background
// at most a faint tide.
window.MUSIC_PRESETS={
 gentle:{label:'Gentle Glow',values:{audioSensitivity:1,audioSmoothing:.7,audioMotion:.35,audioWave:.3,audioGlow:.75,audioBackground:.05,audioColorShift:.25,audioClock:.3}},
 tide:{label:'Slow Tide',values:{audioSensitivity:.9,audioSmoothing:.9,audioMotion:.6,audioWave:.7,audioGlow:.45,audioBackground:.1,audioColorShift:.5,audioClock:.2}},
 expressive:{label:'Expressive',values:{audioSensitivity:1.3,audioSmoothing:.45,audioMotion:.8,audioWave:.65,audioGlow:1.05,audioBackground:.15,audioColorShift:.6,audioClock:.5}},
 shimmer:{label:'Treble Shimmer',values:{audioSensitivity:1.15,audioSmoothing:.5,audioMotion:.25,audioWave:.15,audioGlow:1,audioBackground:0,audioColorShift:.2,audioClock:.45}},
 drift:{label:'Colour Drift',values:{audioSensitivity:1,audioSmoothing:.85,audioMotion:.45,audioWave:.35,audioGlow:.5,audioBackground:.1,audioColorShift:1.2,audioClock:.2}},
 whisper:{label:'Whisper',values:{audioSensitivity:.8,audioSmoothing:.9,audioMotion:.2,audioWave:.15,audioGlow:.4,audioBackground:0,audioColorShift:.15,audioClock:.15}}
};
window.resolveMusicPresetChange=function(current,values){
 const params=Object.keys(window.MUSIC_PRESETS.gentle.values);
 const selected=window.MUSIC_PRESETS[values.audioPreset];
 if(selected&&!params.some(k=>k in values))return {...selected.values,...values};
 if(!('audioPreset' in values)&&params.some(k=>k in values&&values[k]!==current[k]))return {...values,audioPreset:'custom'};
 return values;
};
