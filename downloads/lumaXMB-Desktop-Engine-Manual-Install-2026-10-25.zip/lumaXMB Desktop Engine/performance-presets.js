'use strict';
// Profiles constrain rendering work without rewriting the user's visual
// controls. Returning to Custom restores those controls exactly.
(() => {
  window.PERFORMANCE_PRESETS={
    native120:{label:'Native 4K — 120 FPS',fps:120,resolution:1,glowLimit:1,blurLimit:4,particleScale:.5,description:'Native resolution with your current Balanced glow and particle treatment.'},
    native60:{label:'Native 4K — 60 FPS',fps:60,resolution:1,glowLimit:1,blurLimit:4,particleScale:.5,description:'Native resolution with your current Balanced glow and particle treatment.'},
    custom:{label:'Custom — manual controls',description:'Your frame rate, resolution, glow, blur and particle settings.'},
    detail120:{label:'Full detail — 120 FPS target',fps:120,resolution:1,glowLimit:3,blurLimit:12,particleScale:1,description:'100% resolution. Glow, blur and particles follow your settings.'},
    efficient120:{label:'Efficient — 120 FPS target',fps:120,resolution:.75,glowLimit:0,blurLimit:0,particleScale:0,description:'75% resolution. Glow, blur and particles bypassed; glass reflections remain.'},
    balanced60:{label:'Balanced — 60 FPS target',fps:60,resolution:.8,glowLimit:1,blurLimit:4,particleScale:.5,description:'80% resolution. Glow up to 1, blur up to 4 pixels and half particle density.'},
    eco30:{label:'Eco — 30 FPS target',fps:30,resolution:.6,glowLimit:0,blurLimit:0,particleScale:0,description:'60% resolution. Glow, blur and particles bypassed; all selected animation keeps moving.'}
  };
  window.resolvePerformanceSettings=function(config){
    const id=window.PERFORMANCE_PRESETS[config.performancePreset]?config.performancePreset:'custom';
    const profile=window.PERFORMANCE_PRESETS[id],custom=id==='custom';
    return {
      id,label:profile.label,description:profile.description,
      fps:custom?Number(config.fpsMode):profile.fps,
      resolution:custom?config.resolution:profile.resolution,
      glow:custom?config.glow:Math.min(config.glow,profile.glowLimit),
      blur:custom?config.blur:Math.min(config.blur,profile.blurLimit),
      particleScale:custom?1:profile.particleScale,
      effectsAllowed:custom||profile.glowLimit>0||profile.blurLimit>0,
      particlesAllowed:custom||profile.particleScale>0
    };
  };
})();
