'use strict';
// Particle layer renderer. Original shader/program scaffolding copyright (c) 2025 Mart,
// MIT license retained in LICENSE. Particle geometry, motion, and materials redesigned.
(function () {
  const MAX_PARTICLES = 800;
  function compile(gl, src, type) {
    const shader=gl.createShader(type);
    gl.shaderSource(shader,src);gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)) {
      const info=gl.getShaderInfoLog(shader)||'particle shader compile failed';
      gl.deleteShader(shader);throw new Error(info);
    }
    return shader;
  }
  function link(gl,vsSource,fsSource) {
    const program=gl.createProgram();
    const vs=compile(gl,vsSource,gl.VERTEX_SHADER),fs=compile(gl,fsSource,gl.FRAGMENT_SHADER);
    gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);
    gl.deleteShader(vs);gl.deleteShader(fs);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS)) {
      const info=gl.getProgramInfoLog(program)||'particle program link failed';
      gl.deleteProgram(program);throw new Error(info);
    }
    return program;
  }
  window.createParticlesLayer=function createParticlesLayer(gl,canvas) {
    const settings=window.PARTICLE_SETTINGS;
    if(!settings)throw new Error('Missing PARTICLE_SETTINGS');
    const program=link(gl,`#version 300 es
      precision highp float;
      precision highp int;
      in vec4 aSeed;
      uniform float uTime,uSpeed,uFlowSpeed,uSizeScale,uPixelScale;
      uniform vec2 uSizes,uClip;
      uniform int uFlow,uStyle;
      out float vAlpha,vSeed;
      const float TAU=6.28318530718;
      float edge(float v) {return smoothstep(0.,.045,v)*(1.-smoothstep(.955,1.,v));}
      void main() {
        float t=uTime*uSpeed,m=t*uFlowSpeed,phase=aSeed.w*TAU;
        vec2 p=aSeed.xy;
        float fade=1.;
        if(uFlow==0) {
          p.x=fract(aSeed.x+m*(.060+.045*aSeed.z));
          p.y=fract(aSeed.y+m*(.025+.025*aSeed.w));
          p+=vec2(sin(t*.038+phase)*.010,cos(t*.029+phase)*.009);
        } else if(uFlow==1) {
          float angle=aSeed.x*TAU+m*(.23+.10*aSeed.w);
          float radius=.20+.36*aSeed.z;
          p=vec2(.5+cos(angle)*radius,.51+sin(angle)*radius*.29);
          p.y+=sin(t*.06+phase)*.007;
        } else if(uFlow==2) {
          p.x=fract(aSeed.x+m*(.11+.10*aSeed.z));
          p.y=.46+(aSeed.y-.5)*(.08+.15*aSeed.z)+sin(t*.052+phase)*.008;
        } else if(uFlow==3) {
          float life=fract(aSeed.y+m*(.12+.10*aSeed.z));
          p=vec2(aSeed.x+sin(t*.17+phase)*(.010+.014*aSeed.z),.10+life*.81);
          fade=smoothstep(0.,.12,life)*(1.-smoothstep(.82,1.,life));
        } else if(uFlow==4) {
          p+=vec2(sin(t*.028+phase),cos(t*.022+phase))*.003;
        } else if(uFlow==5) {
          p.x=fract(aSeed.x+m*(.13+.12*aSeed.z));
          p.y=.06+aSeed.y*.88+sin(t*.065+phase)*.006;
        } else if(uFlow==6) {
          float life=fract(aSeed.y+m*(.07+.05*aSeed.z));
          p=vec2(aSeed.x+sin(t*.085+phase)*.016,1.06-life*1.12);
          fade=smoothstep(0.,.08,life)*(1.-smoothstep(.92,1.,life));
        } else if(uFlow==7) {
          p.x+=sin(t*.10+phase)*.022+cos(t*.071+aSeed.z*TAU)*.010;
          p.y=.1+aSeed.y*.8+cos(t*.083+phase)*.020;
          fade=.25+.75*pow(.5+.5*sin(t*.18+phase),2.);
        } else {
          p.x=fract(aSeed.x+m*(.05+.04*aSeed.z))+sin(t*.045+phase)*.009;
          p.y=fract(aSeed.y+m*.023)+cos(t*.032+phase)*.009;
        }
        float breathing=.68+.32*sin(t*(.065+.02*aSeed.z)+phase);
        vAlpha=fade*edge(p.x)*edge(p.y)*breathing*(.4+.6*aSeed.z);
        vSeed=aSeed.w;
        float spriteSize=(uSizes.x+uSizes.y*aSeed.z)*uSizeScale*uPixelScale;
        if(uStyle==4)spriteSize*=2.8;
        gl_PointSize=max(1.25,spriteSize);
        gl_Position=vec4(p.x*2.-1.,((p.y-uClip.x)/(uClip.y-uClip.x))*2.-1.,0.,1.);
      }`, `#version 300 es
      precision highp float;
      precision highp int;
      in float vAlpha,vSeed;
      uniform float uOpacity;
      uniform vec3 uColor;
      uniform int uStyle,uFlow;
      out vec4 oColor;
      float coverage(float distance) {
        float aa=max(fwidth(distance),.012);
        return 1.-smoothstep(-aa,aa,distance);
      }
      void main() {
        vec2 c=gl_PointCoord*2.-1.;
        float r=length(c),shape=0.;
        vec3 color=uColor;
        if(uStyle==0) {
          shape=coverage(r-.68)*(.68+.32*(1.-min(r,1.)));
        } else if(uStyle==1) {
          float diamond=abs(c.x)*.92+abs(c.y)-.80;
          shape=coverage(diamond);
          float diagonal=c.x+c.y*.70;
          float planeAA=max(fwidth(diagonal),.012);
          float plane=.53+.32*smoothstep(-planeAA,planeAA,diagonal);
          float ridge=coverage(abs(diagonal)-.055);
          color=mix(color,vec3(1.),.14+.27*ridge);
          shape*=plane+.15*ridge;
          if(uFlow==8)color*=mix(vec3(.86,.96,1.),vec3(1.,.90,.98),vSeed);
        } else if(uStyle==2) {
          float soft=pow(max(0.,1.-r/.9),2.2);
          float core=coverage(r-.18)*.26;
          shape=soft*.70+core;
          color=mix(color,vec3(1.),core*.45);
        } else if(uStyle==3) {
          float spoke=max(abs(c.x),abs(c.y))*.80+min(abs(c.x),abs(c.y))*3.4-.63;
          shape=coverage(spoke)*.50+coverage(r-.20)*.50;
          color=mix(color,vec3(1.),.25);
        } else if(uStyle==4) {
          vec2 q=vec2(c.x,c.y+c.x*.15);
          float segment=length(vec2(q.x-clamp(q.x,-.72,.48),q.y))-.10;
          shape=coverage(segment)*(.15+.70*smoothstep(-.85,.48,q.x));
        } else {
          float ring=abs(r-.60)-.055;
          shape=coverage(ring)*(.40+.35*clamp(c.x-c.y,0.,1.));
          color=mix(color,vec3(1.),.18);
        }
        float alpha=clamp(shape*vAlpha*uOpacity,0.,.95);
        if(alpha<.001)discard;
        // The wallpaper canvas is transparent. Match its premultiplied source-over
        // compositing so points add their own alpha without creating opaque squares.
        oColor=vec4(color*alpha,alpha);
      }`);
    const vao=gl.createVertexArray(),buffer=gl.createBuffer();
    const seeds=new Float32Array(MAX_PARTICLES*4);
    let state=0x53a93000;
    function random() {
      state=(Math.imul(state,1664525)+1013904223)>>>0;
      return state/4294967296;
    }
    for(let i=0;i<seeds.length;i++)seeds[i]=random();
    const seedLocation=gl.getAttribLocation(program,'aSeed');
    if(seedLocation<0)throw new Error('Missing particle seed attribute');
    gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
    gl.bufferData(gl.ARRAY_BUFFER,seeds,gl.STATIC_DRAW);
    gl.enableVertexAttribArray(seedLocation);gl.vertexAttribPointer(seedLocation,4,gl.FLOAT,false,0,0);
    gl.bindVertexArray(null);
    const uniforms={};
    for(const key of ['uTime','uSpeed','uFlowSpeed','uSizeScale','uPixelScale','uSizes','uClip','uFlow','uStyle','uOpacity','uColor'])uniforms[key]=gl.getUniformLocation(program,key);
    const cached=Object.create(null);
    cached.uSizes={a:NaN,b:NaN};cached.uClip={a:NaN,b:NaN};
    function one(name,value,integer) {
      if(cached[name]===value)return;
      cached[name]=value;
      if(integer)gl.uniform1i(uniforms[name],value);else gl.uniform1f(uniforms[name],value);
    }
    function two(name,a,b) {
      const pair=cached[name];
      if(pair.a===a&&pair.b===b)return;
      pair.a=a;pair.b=b;gl.uniform2f(uniforms[name],a,b);
    }
    function render(timeSec) {
      const count=Math.max(0,Math.min(MAX_PARTICLES,settings.count|0));
      if(count===0||settings.opacity<=0)return;
      const bounds=settings.clipBounds||(window.SPLINE_SETTINGS&&window.SPLINE_SETTINGS.clipBounds);
      const clipLow=bounds?bounds[0]:0,clipHigh=bounds?bounds[1]:1;
      gl.disable(gl.DEPTH_TEST);gl.enable(gl.BLEND);
      gl.blendFuncSeparate(gl.ONE,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      gl.useProgram(program);gl.uniform1f(uniforms.uTime,timeSec);
      one('uSpeed',settings.speed===undefined?1:settings.speed);
      one('uFlowSpeed',settings.flowSpeed===undefined?.04:settings.flowSpeed);
      one('uSizeScale',settings.sizeScale===undefined?1:settings.sizeScale);
      one('uPixelScale',canvas.height/(Math.max(1,window.innerHeight)*(clipHigh-clipLow)));
      one('uFlow',settings.flow|0,true);one('uStyle',settings.style|0,true);
      one('uOpacity',settings.opacity*(settings.opacityScale===undefined?1:settings.opacityScale));
      two('uSizes',settings.sizeBase===undefined?1:settings.sizeBase,settings.sizeVar===undefined?1.1:settings.sizeVar);
      two('uClip',clipLow,clipHigh);
      const color=settings.color;
      const red=color?color[0]:.72,green=color?color[1]:.84,blue=color?color[2]:1;
      if(cached.red!==red||cached.green!==green||cached.blue!==blue) {
        cached.red=red;cached.green=green;cached.blue=blue;gl.uniform3f(uniforms.uColor,red,green,blue);
      }
      gl.bindVertexArray(vao);gl.drawArrays(gl.POINTS,0,count);gl.bindVertexArray(null);
    }
    return {render,maxParticles:MAX_PARTICLES};
  };
})();
