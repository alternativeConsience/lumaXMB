// The original four surfaces keep their original geometry and crop bounds.
// Each additional surface evaluates a distinct analytic height field, rather
// than changing playback speed or recoloring the same shape.
window.WAVE_PRESETS={
  sony:{label:'Sony Default',shape:[1,1,1,.85],mode:0,bounds:[.32,.80]},
  silk:{label:'Silk',shape:[.55,.65,.7,.65],mode:0,bounds:[.39,.78]},
  ribbon:{label:'Ribbon',shape:[1.65,1.25,1.15,1],mode:0,bounds:[.24,.94]},
  tide:{label:'Tide',shape:[.8,1.65,.45,.55],mode:0,bounds:[.14,1]},
  satin:{label:'Satin Flow',shape:[0,1,0,.9],mode:1,bounds:[0,1]},
  crystal:{label:'Crystal Folds',shape:[0,1,0,.85],mode:2,bounds:[0,1]},
  horizon:{label:'Quiet Horizon',shape:[0,1,0,.8],mode:3,bounds:[0,1]},
  pleats:{label:'Glass Pleats',shape:[0,1,0,.95],mode:4,bounds:[0,1]},
  dunes:{label:'Soft Dunes',shape:[0,1,0,.8],mode:5,bounds:[0,1]},
  cascade:{label:'Diagonal Cascade',shape:[0,1,0,1],mode:6,bounds:[0,1]},
  helix:{label:'Helix Sheet',shape:[0,1,0,.8],mode:7,bounds:[0,1]},
  aurora:{label:'Aurora Veil',shape:[0,1,0,.85],mode:8,bounds:[0,1]},
  estuary:{label:'Crosscurrent',shape:[0,1,0,.9],mode:9,bounds:[0,1]},
  swell:{label:'Ocean Swell',shape:[0,1,0,.8],mode:10,bounds:[0,1]},
  lattice:{label:'Interference Glass',shape:[0,1,0,.95],mode:11,bounds:[0,1]},
  prism:{label:'Prism Ribbon',shape:[0,1,0,.9],mode:12,bounds:[0,1]}
};
// The four parameters are displacement, spatial frequency, temporal rate,
// and depth modulation. Classic adds no displacement to the original wave.
window.ANIMATION_PRESETS={
  classic:{label:'Classic Flow',params:[0,0,0,0],mode:0},
  drift:{label:'Slow Drift',params:[.026,2.4,.22,.18],mode:1},
  sway:{label:'Lateral Sway',params:[.035,3.2,.31,.22],mode:2},
  counterflow:{label:'Counterflow',params:[.022,9,.48,5.4],mode:3},
  breathe:{label:'Breathing Glass',params:[.14,0,.36,0],mode:4},
  rolling:{label:'Rolling Sheet',params:[.032,4.7,.42,2.7],mode:5},
  ripple:{label:'Traveling Ripples',params:[.010,22,.9,7.2],mode:6},
  undulate:{label:'Long Undulation',params:[.040,3.6,.28,1.9],mode:7},
  orbit:{label:'Orbital Current',params:[.032,6,.35,4.4],mode:8},
  pulse:{label:'Passing Pulse',params:[.052,6.8,.38,.28],mode:9},
  cascade:{label:'Cascading Folds',params:[.018,10,.62,9],mode:10},
  pendulum:{label:'Pendulum Twist',params:[.025,5.2,.29,0],mode:11}
};
window.SPLINE_SETTINGS={
  brightness:.98,gradientStart:[.001,.001,.009],gradientMiddle:[.004,.006,.028],
  gradientEnd:[.018,.019,.086],gradientAngle:90,mood:0,
  backgroundExposure:1,backgroundBlackPoint:0,blackFloor:false,
  waveMode:0,motionParams:[0,0,0,0],motionMode:0,
  waveAmplitude:1,waveFrequency:1,waveDetail:1,wavePosition:0,
  gloss:1,glassOpacity:1,highlightWidth:1,animationStrength:1,
  waveIridescence:.35,waveStrands:.6
};
