'use strict';
// Bound the shader's displaced sheet once when controls or the viewport change.
// Keeping the transparent area out of the framebuffer also reduces the size
// of the MSAA, glow and blur targets, without lowering spatial resolution.
(() => {
  const modernSwellRadius=[0,.113,.099,.057,.088,.117,.121,0,.127,.126,.140,.114,.114];
  const finite=(value,fallback)=>Number.isFinite(Number(value))?Number(value):fallback;
  window.waveRenderBounds=function(config,viewportHeight,dpr){
    const height=finite(viewportHeight,0),scale=finite(dpr,0);
    if(height<=0||scale<=0)return [0,1];
    if((window.PARTICLE_SETTINGS&&window.PARTICLE_SETTINGS.count>0)||
      (config.particlePreset&&config.particlePreset!=='off'))return [0,1];
    const wave=window.WAVE_PRESETS[config.wavePreset]||window.WAVE_PRESETS.sony;
    const motion=window.ANIMATION_PRESETS[config.animationPreset]||window.ANIMATION_PRESETS.classic;
    const detail=Math.abs(finite(config.waveDetail,1));
    const amplitude=Math.abs(finite(config.waveAmplitude,1));
    const position=finite(config.wavePosition,0);
    const sony=wave===window.WAVE_PRESETS.sony;
    const pivot=sony?.563:wave.mode>.5?.56:.585;
    let radius;
    if(sony){
      // The fullness envelope is .8+.2*sin(...), hence at most one.
      radius=.050+.023+.068*detail+.042+.026+.010;
    }else if(wave.mode>.5){
      // Each harmonic is bounded by its amplitude. Helix alone has a z-
      // scaled harmonic; Aurora's fullness envelope stays between .3 and 1.
      const harmonic=wave.mode===7?.072*detail+.047+.019:modernSwellRadius[wave.mode];
      if(!Number.isFinite(harmonic))return [0,1];
      radius=(.018*detail+harmonic)*Math.abs(wave.shape[1]);
    }else{
      const shape=wave.shape;
      const base=.068+.023+.038*detail+.054+.027+.012+.006+.015;
      // envelope=1+shape.z*(-.32+.32*sin(...)); include both endpoints
      // rather than assuming a particular authored pocket-strength range.
      const envelope=Math.max(1,Math.abs(1-.64*shape[2]));
      radius=(base*envelope+.020)*Math.abs(shape[1]);
    }
    let lower=-radius,upper=radius;
    if(motion.mode>.5){
      const a=Math.abs(motion.params[0]*Math.max(0,finite(config.animationStrength,1)));
      const depth=Math.abs(motion.params[3]);
      let displacement=0;
      switch(motion.mode){
        case 1:case 2:displacement=a*(1+depth*detail);break;
        case 3:displacement=a*1.7;break;
        case 4:lower*=1+a;upper*=1+a;break;
        // max |z*cos(p)+sin(p)| is sqrt(z*z+1), at every phase.
        case 5:displacement=a*Math.sqrt(detail*detail+1);break;
        case 6:displacement=a*1.35;break;
        case 7:displacement=a;break;
        case 8:displacement=a*1.45;break;
        // Passing Pulse has exp(-6*c*c)*(.85+.15*cos(...)) in [0,1].
        case 9:upper+=a;break;
        case 10:displacement=a*1.45;break;
        case 11:displacement=a*detail;break;
        default:return [0,1];
      }
      lower-=displacement;upper+=displacement;
    }
    const steadyGlow=finite(config.glow,0)>0?Math.max(0,finite(config.glowRadius,12)):0;
    const glow=Math.max(steadyGlow,config.breatheEnabled&&finite(config.breatheIntensity,0)>0?finite(config.breatheRadius,22):0);
    const blur=Math.max(0,finite(config.blur,0));
    // Spatial kernels have finite support. The extra pixels cover native MSAA
    // and the downsampling/bilinear footprint, also at low render scales.
    const guard=glow||blur?Math.max(4,7/scale):4;
    const padding=(Math.max(glow,blur)+guard)/height;
    let low=Math.max(0,pivot+position+lower*amplitude-padding);
    let high=Math.min(1,pivot+position+upper*amplitude+padding);
    if(!Number.isFinite(low)||!Number.isFinite(high)||high<=low)return [0,1];
    // Preserve the established crop for the four original, unmodified Classic
    // sheets when it also encloses every analytic peak and the edge padding.
    if(wave.mode===0&&motion.mode===0&&amplitude===1&&detail===1&&position===0&&
      finite(config.waveFrequency,1)===1&&wave.bounds[0]<=low&&wave.bounds[1]>=high){
      low=wave.bounds[0];high=wave.bounds[1];
    }
    // Pixel-aligned placement maps cropped samples onto the same full-frame
    // pixel grid. Use highRow-lowRow as the canvas's backing-buffer height.
    const rows=Math.max(1,Math.round(height*scale));
    return [Math.max(0,Math.floor(low*rows))/rows,Math.min(rows,Math.ceil(high*rows))/rows];
  };
})();
