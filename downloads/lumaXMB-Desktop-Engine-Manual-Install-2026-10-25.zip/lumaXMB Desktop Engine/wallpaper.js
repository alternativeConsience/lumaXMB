'use strict';
(() => {
  const canvas=document.getElementById('wave-canvas');
  const gl=canvas.getContext('webgl2',{antialias:false,alpha:true,depth:false,stencil:false,powerPreference:'high-performance'});
  const backgroundCanvas=document.getElementById('background-canvas');
  const backgroundGL=backgroundCanvas.getContext('webgl2',{antialias:false,alpha:false,depth:false,stencil:false,powerPreference:'high-performance'});
  const error=document.getElementById('error');
  function fail(message){error.hidden=false;error.textContent=message;window.waveStatus={error:message};}
  if(!gl||!backgroundGL){fail('This wallpaper requires WebGL 2.');return;}
  const config={
    antiAliasing:'4',panelTransparency:50,panelWidth:640,panelHeight:1200,edgeSoftness:1,highlightSoftness:1,highlightIntensity:1,meshQuality:"smooth",settingsPanel:false,diagnosticsEnabled:false,performancePreset:'custom',fpsMode:'60',wavePreset:'tide',animationPreset:'classic',backgroundMode:'shifting',backgroundPreset:'midnight',particlePreset:'off',
    shiftingPreset:'oledAurora',shiftingStyle:'flow',shiftingSpeed:1,shiftingStrength:1,shiftingPeriod:90,shiftingAngle:90,shiftingSoftness:0,shiftingVibrance:100,shiftingBrightness:100,
    shiftingColor1:'0.02 0.05 0.18',shiftingColor2:'0.13 0.03 0.28',shiftingColor3:'0.01 0.22 0.25',shiftingColor4:'0.03 0.08 0.32',
    gradientStart:'0.001 0.001 0.009',gradientMiddle:'0.004 0.006 0.028',gradientEnd:'0.018 0.019 0.086',gradientAngle:90,customBlend:'three',
    speed:1,brightness:.98,resolution:1,advancedControls:'closed',
    waveAmplitude:1,waveFrequency:1,waveDetail:1,wavePosition:0,gloss:1,glassOpacity:1,highlightWidth:1,
    waveIridescence:.35,waveStrands:.6,waveFinish:'original',waveTint:'silver',waveColor:'0.25 0.65 1',waveTintStrength:1,
    spanDisplays:'auto',spanGap:1.2,spanVerticalOffset:0,
    animationStrength:1,animationDirection:'forward',
    particleDensity:1,particleSize:1,particleSpeed:1,sparkle:.55,particleTint:'palette',particleColor:'0.72 0.84 1',
    backgroundExposure:1,backgroundRotation:0,backgroundBlackLevel:0,
    breatheEnabled:false,breathePreset:"silk",breatheMode:"full",breathePeriod:9,breatheIntensity:0.85,breatheMinimum:4,breatheWidth:60,breatheSoftness:0.9,breatheRadius:22,breatheThreshold:0.025,breatheTint:"wave",breatheColor:"0.3 0.65 1",
    glow:0,glowRadius:12,glowThreshold:.55,glowTint:'palette',glowColor:'0.7 0.85 1',blur:0,blurQuality:'balanced',
    clockEnabled:true,clockTheme:'ps3',clockStyle:'strip',clockDate:true,clockHours:'24',clockSize:100,clockGlow:12,clockBrightness:100,clockBreath:6,clockOpacity:100,clockTint:'white',clockTintStrength:35,
    clockTextSize:100,clockLetterSpacing:0,clockGap:100,clockPadding:100,clockShimmer:100,clockShimmerWidth:30,clockTextBrightness:100,clockGlowBrightness:100,
    movementPreset:'classic',waveRotation:0,waveSway:0,waveBob:0,waveSwayPeriod:30,
    displayStates:'',panelPosition:'',audioEnabled:false,audioPreset:'gentle',audioSource:'music',audioSensitivity:1,audioSmoothing:.5,audioMotion:.6,audioWave:.5,audioGlow:.6,audioBackground:.2,audioColorShift:.4,audioClock:.3
  };
  // Windows port: match project defaults before the first rendered frame.
  Object.assign(config,window.XMB_INITIAL_SETTINGS||{});
  const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
  const limits={breathePeriod:[2,60],breatheIntensity:[0,3],breatheMinimum:[0,100],breatheWidth:[5,150],breatheSoftness:[.1,1],breatheRadius:[2,60],breatheThreshold:[0,1],speed:[.1,3],brightness:[.2,1.5],resolution:[.5,1],waveAmplitude:[.3,1.6],waveFrequency:[.5,1.75],waveDetail:[.35,1.8],wavePosition:[-.15,.15],gloss:[.3,2],glassOpacity:[0,2],highlightWidth:[.5,2],waveIridescence:[0,1],waveStrands:[0,1],waveTintStrength:[0,1],spanGap:[0,10],spanVerticalOffset:[-60,60],animationStrength:[0,1.5],particleDensity:[.2,2],particleSize:[.5,2],particleSpeed:[.1,2],sparkle:[0,1],backgroundExposure:[.2,1.4],backgroundRotation:[-180,180],backgroundBlackLevel:[0,.3],gradientAngle:[0,360],shiftingSpeed:[0,3],shiftingStrength:[0,1],shiftingPeriod:[15,300],shiftingAngle:[0,360],shiftingSoftness:[0,24],shiftingVibrance:[0,200],shiftingBrightness:[20,200],glow:[0,3],glowRadius:[2,36],glowThreshold:[0,1],blur:[0,12],clockSize:[40,250],clockGlow:[0,30],clockBrightness:[10,250],clockBreath:[2,20],clockOpacity:[0,100],clockTintStrength:[0,100],clockTextSize:[50,200],clockLetterSpacing:[-5,40],clockGap:[0,300],clockPadding:[0,300],clockShimmer:[0,250],clockShimmerWidth:[10,80],clockTextBrightness:[10,200],clockGlowBrightness:[0,250],audioSensitivity:[.25,3],audioSmoothing:[0,1],audioMotion:[0,1.5],audioWave:[0,1.5],audioGlow:[0,1.5],audioBackground:[0,1.5],audioColorShift:[0,1.5],audioClock:[0,1.5],waveRotation:[-25,25],waveSway:[0,12],waveBob:[0,1],waveSwayPeriod:[6,120]};
  // While the music response is on, the render band keeps a little headroom so
  // the travelling swell and ripple (at most about 5% of the screen at the
  // highest setting) are never clipped.
  const AUDIO_WAVE_HEADROOM=.35;
  let performance=window.resolvePerformanceSettings(config);
  let background,animatedBackground,spline,particles,effects,renderedBackgroundMode="static",waveViewportHeight=1,waveViewportBottom=0;
  // Per-display state (see annotateViews).
  const monitorFreeze=new Map();let selfState='on',selfCleared=false,statesText=null,parsedStates={},annotatedSpan=null,annotatedStates=null,spanPivot=.5,spanRange=[0,1];
  let hostFps=120,paused=false,hidden=document.hidden,frameId=0,last=0,nextFrame=0,waveTime=0,particleTime=0,backgroundTime=0,effectTime=0,displayInterval=0;
  const waveAttributes=gl.getContextAttributes(),backgroundAttributes=backgroundGL.getContextAttributes();
  window.waveStatus={ready:false,frames:0,paused:false,depthBuffer:Boolean(waveAttributes.depth),stencilBuffer:Boolean(waveAttributes.stencil),backgroundDepthBuffer:Boolean(backgroundAttributes.depth),backgroundStencilBuffer:Boolean(backgroundAttributes.stencil)};
  const diagnostics=window.createWaveDiagnostics(window.waveStatus);
  function updateFrameRate(){
    const previous=window.waveStatus.targetFps;
    window.waveStatus.requestedFps=performance.fps;
    window.waveStatus.hostFps=hostFps;
    window.waveStatus.targetFps=Math.min(performance.fps,hostFps);
    if(previous!==window.waveStatus.targetFps){nextFrame=0;if(window.waveStatus.pacing)window.waveStatus.pacing.lastDrawVsync=-Infinity;}
  }
  function parseColor(value,fallback){
    const rgb=String(value).trim().split(/\s+/).map(Number);
    return rgb.length===3&&rgb.every(Number.isFinite)?rgb.map(v=>clamp(v,0,1)):fallback;
  }
  function updateSettings(){
    for(const [key,range] of Object.entries(limits))config[key]=clamp(config[key],range[0],range[1]);
    if(!['full','ltr','rtl','bounce','center','edges'].includes(config.breatheMode))config.breatheMode='full';
    if(!['wave','palette','silver','custom'].includes(config.breatheTint))config.breatheTint='wave';
    if(config.breathePreset!=='custom'&&!window.BREATHING_GLOW_PRESETS[config.breathePreset])config.breathePreset='custom';
    if(!['static','shifting'].includes(config.backgroundMode))config.backgroundMode='static';
    if(!['24','12'].includes(config.clockHours))config.clockHours='24';
    if(!['strip','glass','dark','fade','bare','psp'].includes(config.clockStyle))config.clockStyle='strip';
    if(!['white','palette','wave'].includes(config.clockTint))config.clockTint='white';
    if(config.clockTheme!=='custom'&&!(window.CLOCK_THEMES&&window.CLOCK_THEMES[config.clockTheme]))config.clockTheme='custom';
    if(config.shiftingPreset!=='custom'&&!window.ANIMATED_BACKGROUND_PRESETS[config.shiftingPreset])config.shiftingPreset='console';
    if(!window.BACKGROUND_MOTION_STYLES[config.shiftingStyle])config.shiftingStyle='flow';
    if(!['30','60','120'].includes(config.fpsMode))config.fpsMode='60';
    if(!['music','ambient'].includes(config.audioSource))config.audioSource='music';
    if(config.movementPreset!=='custom'&&!(window.MOVEMENT_PRESETS&&window.MOVEMENT_PRESETS[config.movementPreset]))config.movementPreset='custom';
    if(config.audioPreset!=='custom'&&!(window.MUSIC_PRESETS&&window.MUSIC_PRESETS[config.audioPreset]))config.audioPreset='custom';
    if(!['auto','off'].includes(config.spanDisplays))config.spanDisplays='auto';
    if(!window.PERFORMANCE_PRESETS[config.performancePreset])config.performancePreset='custom';
    if(!['closed','wave','motion','particles','background','effects','all'].includes(config.advancedControls))config.advancedControls='closed';
    performance=window.resolvePerformanceSettings(config);updateFrameRate();
    if(!['fast','balanced','high'].includes(config.blurQuality))config.blurQuality='balanced';
    if(!['palette','silver','warm','custom'].includes(config.glowTint))config.glowTint='palette';
    if(!['original','clear'].includes(config.waveFinish))config.waveFinish='original';
    if(!['silver','palette','custom','warm','ice','violet','rose'].includes(config.waveTint))config.waveTint='silver';
    if(!window.WAVE_PRESETS[config.wavePreset])config.wavePreset='sony';
    if(!window.ANIMATION_PRESETS[config.animationPreset])config.animationPreset='classic';
    if(config.backgroundPreset!=='custom'&&!window.BACKGROUND_PRESETS[config.backgroundPreset])config.backgroundPreset='midnight';
    if(config.particlePreset!=='off'&&!window.PARTICLE_PRESETS[config.particlePreset])config.particlePreset='off';
    if(!['forward','reverse'].includes(config.animationDirection))config.animationDirection='forward';
    if(!['palette','silver','warm','custom'].includes(config.particleTint))config.particleTint='palette';
    const s=window.SPLINE_SETTINGS,wave=window.WAVE_PRESETS[config.wavePreset],motion=window.ANIMATION_PRESETS[config.animationPreset];
    s.waveShape=wave.shape;s.waveMode=wave.mode;s.motionParams=motion.params;s.motionMode=motion.mode;
    for(const key of ['waveAmplitude','waveFrequency','waveDetail','wavePosition','gloss','glassOpacity','highlightWidth','edgeSoftness','highlightSoftness','highlightIntensity','meshQuality','waveIridescence','waveStrands','animationStrength','brightness','backgroundExposure'])s[key]=config[key];
    // Colours are gathered as a target and then handed to the transition
    // layer, which glides the live values towards them instead of snapping.
    const t={};
    if(config.backgroundPreset==='custom'){
      for(const key of ['gradientStart','gradientMiddle','gradientEnd'])t[key]=parseColor(config[key],s[key]||[0,0,0]);
      t.gradientAngle=config.gradientAngle+config.backgroundRotation;t.twoTone=config.customBlend==='two';t.blackFloor=false;t.blackPoint=config.backgroundBlackLevel;
      if(t.twoTone)t.gradientMiddle=t.gradientStart.map((v,i)=>(v+t.gradientEnd[i])/2);
    }else{
      const p=window.BACKGROUND_PRESETS[config.backgroundPreset];
      t.gradientStart=p.start;t.gradientMiddle=p.middle;t.gradientEnd=p.end;t.gradientAngle=p.angle+config.backgroundRotation;
      t.twoTone=p.twoTone;t.blackFloor=p.blackFloor;t.blackPoint=clamp((p.blackPoint||0)+config.backgroundBlackLevel,0,.85);
    }
    const a=window.BACKGROUND_MOTION_SETTINGS;
    let activeTint=t.gradientEnd,lighting=t.gradientMiddle;
    if(config.shiftingPreset==='custom'){
      t.colors=[1,2,3,4].map(i=>parseColor(config['shiftingColor'+i],[.03,.08,.25]));t.shiftAngle=config.shiftingAngle;t.shiftBlackFloor=false;t.shiftBlackPoint=config.backgroundBlackLevel;
    }else{
      const cycle=window.ANIMATED_BACKGROUND_PRESETS[config.shiftingPreset];
      t.colors=cycle.colors;t.shiftAngle=cycle.angle;t.shiftBlackFloor=cycle.blackFloor;t.shiftBlackPoint=clamp((cycle.blackPoint||0)+config.backgroundBlackLevel,0,.85);
    }
    // Vibrance pulls each cycle colour away from (or towards) its own grey;
    // brightness scales the cycle's exposure on top of the shared background one.
    const vibrance=clamp(config.shiftingVibrance/100,0,2);
    if(vibrance!==1)t.colors=t.colors.map(c=>{const grey=c[0]*.299+c[1]*.587+c[2]*.114;return c.map(v=>clamp(grey+(v-grey)*vibrance,0,1));});
    a.preset=config.shiftingPreset;a.style=config.shiftingStyle;a.speed=config.shiftingSpeed;a.strength=config.shiftingStrength;a.cycleLength=config.shiftingPeriod;
    a.rotation=config.backgroundRotation;a.exposure=config.backgroundExposure*clamp(config.shiftingBrightness/100,.2,2);a.blur=config.shiftingSoftness;
    if(config.backgroundMode==='shifting'){
      activeTint=t.colors[0].map((v,i)=>t.colors.reduce((sum,color)=>sum+color[i],0)/t.colors.length);lighting=activeTint;
    }
    t.mood=clamp(lighting.reduce((sum,v)=>sum+v,0)*2*config.backgroundExposure,0,1);
    // Color comes from the selected background, independently of its exposure.
    // Keep dark OLED palettes useful by normalizing hue instead of copying black.
    t.waveClear=config.waveFinish==='clear'?1:0;
    t.waveTintStrength=config.waveTint==='silver'?0:config.waveTintStrength;
    s.waveTintMode=config.waveTint;
    const waveColors={warm:[1,.68,.32],ice:[.27,.66,1],violet:[.64,.3,1],rose:[1,.3,.52]};
    const normalizeTint=color=>{const peak=Math.max(...color);return peak>.0001?color.map(v=>v/peak):[.72,.78,.85];};
    const backgroundTint=config.backgroundMode==='shifting'?activeTint:t.gradientStart.map((v,i)=>(v+t.gradientMiddle[i]+t.gradientEnd[i])/3);
    t.waveTintColor=config.waveTint==='palette'?normalizeTint(backgroundTint):config.waveTint==='custom'?parseColor(config.waveColor,[.25,.65,1]):waveColors[config.waveTint]||[1,1,1];
    s.wavePaletteAnimated=config.waveTint==='palette'&&config.backgroundMode==='shifting';
    window.waveStatus.waveAppearance={finish:config.waveFinish,tint:config.waveTint,strength:t.waveTintStrength,color:t.waveTintColor};
    const e=window.EFFECT_SETTINGS;
    for(const key of ['glowRadius','glowThreshold','blurQuality'])e[key]=config[key];
    for(const key of ['breatheEnabled','breatheMode','breathePeriod','breatheIntensity','breatheMinimum','breatheWidth','breatheSoftness','breatheRadius','breatheThreshold'])e[key]=config[key];
    e.breatheTintMode=config.breatheTint;
    t.breatheTint=config.breatheTint==='custom'?parseColor(config.breatheColor,[.3,.65,1]):config.breatheTint==='silver'?[.72,.84,1]:t.waveTintColor;
    const palettePeak=Math.max(...backgroundTint);
    t.breathePaletteColor=palettePeak>.0001?backgroundTint.map(v=>v/palettePeak):[.72,.78,.85];
    e.breathePaletteAnimated=config.backgroundMode==='shifting';
    window.waveStatus.breathingGlow={enabled:config.breatheEnabled,preset:config.breathePreset,mode:config.breatheMode,period:config.breathePeriod,intensity:config.breatheIntensity};
    e.glow=performance.glow;e.blur=performance.blur;e.antiAliasing=config.antiAliasing;
    if(config.glowTint==='custom')t.glowTint=parseColor(config.glowColor,[.7,.85,1]);
    else if(config.glowTint==='silver')t.glowTint=[.85,.91,1];
    else if(config.glowTint==='warm')t.glowTint=[1,.77,.5];
    else{const max=Math.max(...activeTint,.04);t.glowTint=activeTint.map(v=>.55+.45*v/max);}
    const p=window.PARTICLE_SETTINGS,profile=window.PARTICLE_PRESETS[config.particlePreset];
    if(profile)Object.assign(p,profile);
    p.count=profile?Math.min(800,Math.round(profile.count*config.particleDensity*performance.particleScale)):0;
    p.opacity=config.sparkle;p.sizeScale=config.particleSize;p.speed=config.particleSpeed;
    if(config.particleTint==='custom')t.particleColor=parseColor(config.particleColor,[.72,.84,1]);
    else if(config.particleTint==='silver')t.particleColor=[.85,.91,1];
    else if(config.particleTint==='warm')t.particleColor=[1,.77,.5];
    else{
      const tint=activeTint,max=Math.max(...tint,.04);
      t.particleColor=tint.map(v=>.55+.45*v/max);
    }
    Object.assign(window.waveStatus,{wavePreset:config.wavePreset,animationPreset:config.animationPreset,backgroundMode:config.backgroundMode,backgroundPreset:config.backgroundPreset,shiftingPreset:config.shiftingPreset,shiftingStyle:config.shiftingStyle,performancePreset:performance.id,performance:performance,resolution:performance.resolution,particlePreset:config.particlePreset,particleCount:p.count,advancedControls:config.advancedControls});
    scheduleColors(t);
  }
  // Colour transitions. The live colours of the background, wave tint, glow,
  // breathing and particles move from where they are to the new target with an
  // ease, so a change of preset drifts gently instead of cutting. Two-tone and
  // black-floor flags take their final value at the end; in between the
  // gradient is drawn through three stops and the black plateau grows or
  // shrinks with the interpolated black point.
  let appliedColors=null,colorAnim=null,colorTransitionMs=0;
  const reducedMotion=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function applyColorState(c){
    const s=window.SPLINE_SETTINGS,a=window.BACKGROUND_MOTION_SETTINGS,e=window.EFFECT_SETTINGS,p=window.PARTICLE_SETTINGS;
    s.gradientStart=c.gradientStart;s.gradientMiddle=c.gradientMiddle;s.gradientEnd=c.gradientEnd;s.gradientAngle=c.gradientAngle;s.twoTone=c.twoTone;s.blackFloor=c.blackFloor;s.backgroundBlackPoint=c.blackPoint;
    a.colors=c.colors;a.angle=c.shiftAngle;a.blackFloor=c.shiftBlackFloor;a.blackPoint=c.shiftBlackPoint;
    s.mood=c.mood;s.waveClear=c.waveClear;s.waveTintStrength=c.waveTintStrength;s.waveTintColor=c.waveTintColor;
    e.glowTint=c.glowTint;e.breatheTint=c.breatheTint;e.breathePaletteColor=c.breathePaletteColor;p.color=c.particleColor;
    window.waveStatus.gradient={start:c.gradientStart,middle:c.gradientMiddle,end:c.gradientEnd,angle:c.gradientAngle,twoTone:c.twoTone,blackFloor:c.blackFloor,blackPoint:c.blackPoint,exposure:s.backgroundExposure};
    if(animatedBackground)animatedBackground.invalidate();
    appliedColors=c;
  }
  const lerpN=(x,y,k)=>x+(y-x)*k,lerpV=(x,y,k)=>x.map((v,i)=>lerpN(v,y[i],k));
  const lerpAngle=(x,y,k)=>x+((((y-x)%360)+540)%360-180)*k;
  function mixColors(f,g,k){
    return {gradientStart:lerpV(f.gradientStart,g.gradientStart,k),gradientMiddle:lerpV(f.gradientMiddle,g.gradientMiddle,k),gradientEnd:lerpV(f.gradientEnd,g.gradientEnd,k),
      gradientAngle:lerpAngle(f.gradientAngle,g.gradientAngle,k),twoTone:false,blackFloor:Boolean(f.blackFloor||g.blackFloor),blackPoint:lerpN(f.blackPoint,g.blackPoint,k),
      colors:f.colors.map((c,i)=>lerpV(c,g.colors[i],k)),shiftAngle:lerpAngle(f.shiftAngle,g.shiftAngle,k),shiftBlackFloor:Boolean(f.shiftBlackFloor||g.shiftBlackFloor),shiftBlackPoint:lerpN(f.shiftBlackPoint,g.shiftBlackPoint,k),
      mood:lerpN(f.mood,g.mood,k),waveClear:lerpN(f.waveClear,g.waveClear,k),waveTintStrength:lerpN(f.waveTintStrength,g.waveTintStrength,k),waveTintColor:lerpV(f.waveTintColor,g.waveTintColor,k),
      glowTint:lerpV(f.glowTint,g.glowTint,k),breatheTint:lerpV(f.breatheTint,g.breatheTint,k),breathePaletteColor:lerpV(f.breathePaletteColor,g.breathePaletteColor,k),particleColor:lerpV(f.particleColor,g.particleColor,k)};
  }
  function scheduleColors(target){
    if(!appliedColors||colorTransitionMs<=0||reducedMotion()){applyColorState(target);colorAnim=null;return;}
    colorAnim={from:appliedColors,to:target,start:window.performance.now(),duration:colorTransitionMs};
    applyColorState(mixColors(colorAnim.from,target,0));
  }
  // Whether the background canvas was redrawn during the current frame, so the
  // menu glass knows when its copy of the background is current.
  let backgroundFresh=false;
  function stepColors(now){
    if(!colorAnim)return;
    // Ease-out: most of the change lands at once, the rest settles softly, so
    // stepping through a list feels immediate without a visible cut.
    const k=clamp((now-colorAnim.start)/colorAnim.duration,0,1),eased=1-Math.pow(1-k,3);
    if(k>=1){applyColorState(colorAnim.to);colorAnim=null;}else applyColorState(mixColors(colorAnim.from,colorAnim.to,eased));
    if(config.backgroundMode==='static'&&background&&background.render())backgroundFresh=true;
  }
  window.waveStatus.colorTransition={active:()=>Boolean(colorAnim)};
  // One wave across several displays. Only a Wallpaper Engine Stretch group
  // hands this page the whole combined desktop; a single display or a Clone
  // group has one monitor's shape and keeps the ordinary single-screen drawing.
  // World units are the main display's width and height, so the main display
  // looks exactly as before and neighbours continue the same surface at the
  // same physical size, whatever their resolution, density or orientation.
  function computeSpan(canvasW,canvasH){
    return window.XMBDisplays.resolve({width:canvasW,height:canvasH,cssWidth:innerWidth,cssHeight:innerHeight,layout:window.XMB_DISPLAY_LAYOUT,mode:config.spanDisplays,gap:config.spanGap,offset:config.spanVerticalOffset});
  }
  const displayTransition=window.createDisplayTransition();
  let displayKey='',previousViewport=null,displayResizeQueued=false;
  function currentDisplayKey(){return JSON.stringify([innerWidth,innerHeight,devicePixelRatio,performance.resolution,config.spanDisplays,config.spanGap,config.spanVerticalOffset,window.XMB_DISPLAY_LAYOUT?.monitors]);}
  function updateDisplay(reason){
    displayResizeQueued=false;
    const key=currentDisplayKey();if(key===displayKey)return;
    // Draw immediately before copying: WebGL canvases need not retain pixels
    // after presentation. Both canvas resizes and the replacement draw finish
    // in this one task, so the compositor never receives an empty framebuffer.
    if(spline&&background&&previousViewport){
      if(config.backgroundMode==='static'){background.invalidate();background.render();}
      draw();displayTransition.capture({width:previousViewport.width,height:previousViewport.height,background:backgroundCanvas,wave:canvas,backgroundBounds:previousViewport.backgroundBounds,waveBounds:previousViewport.waveBounds});
    }
    resize();if(spline){draw();displayTransition.reveal();}
    window.waveStatus.displayTransition={...displayTransition.stats(),reason};
    window.dispatchEvent(new CustomEvent('xmb-viewport'));
  }
  function queueDisplayResize(){
    if(displayResizeQueued)return;displayResizeQueued=true;
    requestAnimationFrame(()=>{displayResizeQueued=false;updateDisplay('viewport resize');});
  }
  // Work regions when one wave spans several displays. The canvas covers the
  // displays' bounding box, and part of that box is shown on no display at
  // all; within each display the wave occupies only a band of rows. Each
  // region is one display's rectangle narrowed to the rows the wave (and its
  // glow, breathing halo or blur) can reach there. Pixels outside every region
  // are never cleared, drawn, resolved or composited. A turned, swaying or
  // floating wave, or particles, keep each display's full height.
  function computeRegions(span,moving,headroom,canvasWidth){
    if(!span.active||!span.views)return null;
    const particlesOn=performance.particlesAllowed&&config.particlePreset!=='off';
    let band=[0,1];
    if(!moving&&!particlesOn){
      // The band in world units (main-display heights), before any glow.
      const primaryHeight=span.primaryCss?span.primaryCss.height:innerHeight;
      band=window.waveRenderBounds({...config,waveAmplitude:config.waveAmplitude*headroom,glow:0,blur:0,breatheEnabled:false,particlePreset:'off'},primaryHeight,1);
    }
    // Glow and blur reach this far past the wave, in canvas pixels, plus a guard
    // for multisampling and the quarter-size glow's filter footprint.
    const scale=canvasWidth/Math.max(1,innerWidth);
    const radius=Math.max(performance.glow>0?config.glowRadius:0,config.breatheEnabled?config.breatheRadius:0,performance.blur);
    const pad=Math.ceil((radius*1.25+10)*scale);
    const regions=[];
    for(const v of span.views){
      if(v.state==='off')continue;
      const [vx,vy,vw,vh]=v.viewport;
      let top=0,bottom=vh;
      if(band[0]>0||band[1]<1){top=Math.floor((band[0]-v.y0)/v.yh*vh)-pad;bottom=Math.ceil((band[1]-v.y0)/v.yh*vh)+pad;}
      top=Math.max(0,top);bottom=Math.min(vh,bottom);
      if(bottom>top)regions.push([vx,vy+vh-bottom,vw,bottom-top]);
    }
    window.waveStatus.regions={count:regions.length,pixels:regions.reduce((sum,r)=>sum+r[2]*r[3],0),canvas:canvasWidth*Math.round(innerHeight*(window.devicePixelRatio||1)*performance.resolution)};
    return regions;
  }
  function resize(){
    const dpr=(window.devicePixelRatio||1)*performance.resolution;
    const width=Math.max(1,Math.round(innerWidth*dpr)),fullHeight=Math.max(1,Math.round(innerHeight*dpr));
    const span=computeSpan(width,fullHeight);window.XMB_SPAN=span;annotateViews();window.waveStatus.span={active:span.active,mode:span.mode,reason:span.reason,displays:span.displays,views:span.views,singleView:span.singleView};
    // Conservative geometry/effect bounds exclude transparent pixels while
    // retaining the existing pixel density and all animation callbacks. A span
    // places the wave at a different height on each display, so it renders the full frame.
    const headroom=config.audioEnabled&&config.audioWave>0?1+AUDIO_WAVE_HEADROOM:1;
    // A turned, swaying or floating wave can reach anywhere: draw the full frame.
    const moving=config.waveRotation!==0||config.waveSway>0||config.waveBob>0;
    const bounds=span.active||moving?[0,1]:window.waveRenderBounds({...config,waveAmplitude:config.waveAmplitude*headroom,glow:performance.glow,blur:performance.blur,particlePreset:performance.particlesAllowed?config.particlePreset:'off'},innerHeight,dpr);
    window.SPLINE_SETTINGS.clipBounds=[0,1];
    window.SPLINE_SETTINGS.regions=computeRegions(span,moving,headroom,width);
    const height=Math.max(1,Math.round(fullHeight*(bounds[1]-bounds[0])));
    waveViewportHeight=fullHeight;waveViewportBottom=Math.round(fullHeight*(1-bounds[1]));
    const backgroundBounds=config.backgroundMode==='shifting'?window.backgroundRenderBounds(window.BACKGROUND_MOTION_SETTINGS,innerHeight,dpr):[0,1];
    const backgroundHeight=Math.max(1,Math.round(fullHeight*(backgroundBounds[1]-backgroundBounds[0])));
    window.BACKGROUND_MOTION_SETTINGS.clipBounds=backgroundBounds;window.BACKGROUND_MOTION_SETTINGS.fullHeight=fullHeight;
    backgroundCanvas.style.top=(innerHeight*backgroundBounds[0])+'px';backgroundCanvas.style.height=(innerHeight*(backgroundBounds[1]-backgroundBounds[0]))+'px';
    document.body.style.background=config.backgroundMode==='shifting'&&window.BACKGROUND_MOTION_SETTINGS.blackFloor?'#000':'#03060c';
    canvas.style.top=(innerHeight*bounds[0])+'px';canvas.style.height=(innerHeight*(bounds[1]-bounds[0]))+'px';
    const cleared=canvas.width!==width||canvas.height!==height||backgroundCanvas.width!==width||backgroundCanvas.height!==backgroundHeight;
    if(canvas.width!==width)canvas.width=width;if(canvas.height!==height)canvas.height=height;
    if(backgroundCanvas.width!==width)backgroundCanvas.width=width;if(backgroundCanvas.height!==backgroundHeight)backgroundCanvas.height=backgroundHeight;
    window.waveStatus.nativeSize=[Math.round(innerWidth*(window.devicePixelRatio||1)),Math.round(innerHeight*(window.devicePixelRatio||1))];window.waveStatus.fullRenderSize=[width,fullHeight];window.waveStatus.nativeResolution=performance.resolution===1;gl.viewport(0,0,width,height);window.waveStatus.renderSize=[width,height];window.waveStatus.renderBounds=bounds;window.waveStatus.backgroundRenderSize=[width,backgroundHeight];window.waveStatus.backgroundRenderBounds=backgroundBounds;
    displayKey=currentDisplayKey();previousViewport={width:innerWidth,height:innerHeight,backgroundBounds:[...backgroundBounds],waveBounds:[...bounds]};
    if(effects)effects.resize();
    if(config.backgroundMode==='shifting'){if(animatedBackground)animatedBackground.invalidate();}
    else if(background){if(renderedBackgroundMode!=="static")background.invalidate();background.render();renderedBackgroundMode="static";}
    return cleared;
  }
  updateSettings();
  try{resize();background=window.createBackgroundLayer(backgroundGL,backgroundCanvas);background.render();spline=window.createSplineLayer(gl,canvas);effects=window.createEffectsLayer(gl,canvas);window.waveStatus.effects=effects.stats;window.waveStatus.effectsCapabilities=effects.capabilities;}
  catch(e){fail(e.message);return;}
  // Per-display state, set from the Displays page: "on", "paused" (that
  // display's wave and colour cycle hold still where they are) or "off" (black,
  // and its wave is not drawn). Spanning keys each display by its Windows
  // device; a wallpaper on one display uses the key "self" for itself.
  // Stored as text, e.g. "DISPLAY2=paused;DISPLAY3=off".
  function displayStates(){
    if(config.displayStates!==statesText){
      statesText=config.displayStates;parsedStates={};
      for(const part of String(statesText||'').split(';')){const [k,v]=part.split('=').map(x=>(x||'').trim());if(k&&(v==='paused'||v==='off'))parsedStates[k]=v;}
    }
    return parsedStates;
  }
  // Re-annotated only when the span or the stored states change, not per frame
  // (annotatedSpan and friends are declared with the early state above).
  function annotateViews(){
    const span=window.XMB_SPAN;
    if(span===annotatedSpan&&config.displayStates===annotatedStates)return;
    annotatedSpan=span;annotatedStates=config.displayStates;
    const states=displayStates(),views=span&&span.active&&span.views?span.views:null;
    const single=span&&span.singleView||{x0:0,xw:1};
    spanRange=views?[Math.min(...views.map(v=>v.x0)),Math.max(...views.map(v=>v.x0+v.xw))]:[single.x0,single.x0+single.xw];
    spanPivot=views?(spanRange[0]+spanRange[1])/2:.5;
    for(const key of views?views.map(v=>v.key):['self']){
      if(states[key]==='paused'){if(!monitorFreeze.has(key))monitorFreeze.set(key,{wave:waveTime,background:backgroundTime});}
      else monitorFreeze.delete(key);
    }
    let primaryOff=false;
    if(views)for(const v of views){v.state=states[v.key]||'on';const f=monitorFreeze.get(v.key);v.frozenWave=f?f.wave:0;v.frozenBackground=f?f.background:0;if(v.primary&&v.state==='off')primaryOff=true;}
    selfState=views?'on':(states.self||'on');if(selfState==='off')primaryOff=true;
    window.XMBMonitorState={primaryOff,self:selfState,states:{...states}};
    window.waveStatus.displayStates=views?views.map(v=>v.key+':'+v.state).join(' '):'self:'+selfState;
  }
  function draw(){
    annotateViews();
    if(selfState==='off'){
      // The whole page is one display that has been switched off: clear once,
      // then draw nothing until it is switched back on.
      if(!selfCleared){
        backgroundGL.clearColor(0,0,0,1);backgroundGL.clear(backgroundGL.COLOR_BUFFER_BIT);
        gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
        background.invalidate();if(animatedBackground)animatedBackground.invalidate();selfCleared=true;backgroundFresh=true;
      }
      window.waveStatus.frames++;return;
    }
    if(selfCleared){selfCleared=false;if(config.backgroundMode==='static'&&background.render())backgroundFresh=true;}
    if(config.backgroundMode==='shifting'){
      if(!animatedBackground)animatedBackground=window.createAnimatedBackgroundLayer(backgroundGL,backgroundCanvas);
      if(animatedBackground.render(backgroundTime)){backgroundFresh=true;window.waveStatus.backgroundDraws=(window.waveStatus.backgroundDraws||0)+1;}
      renderedBackgroundMode='shifting';
    }
    window.EFFECT_SETTINGS.breatheBackgroundTime=backgroundTime;
    const target=effects.begin(effectTime);
    // Retain the full-frame vertex transform and pixel grid while rasterizing
    // only the visible band into the smaller attachment.
    if(waveViewportHeight!==canvas.height||waveViewportBottom)gl.viewport(0,-waveViewportBottom,canvas.width,waveViewportHeight);
    spline.render(waveTime,target,backgroundTime);
    if(window.PARTICLE_SETTINGS.count>0){
      if(!particles)particles=window.createParticlesLayer(gl,canvas);
      particles.render(particleTime+137);
    }
    effects.end();
    // Displays switched off: clear their part of the wave canvas after every
    // layer (particles and glow included), leaving the black background. With
    // work regions this is already so (off displays have none).
    const span=window.XMB_SPAN;
    if(!window.SPLINE_SETTINGS.regions&&span&&span.active&&span.views&&span.views.some(v=>v.state==='off')){
      gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.enable(gl.SCISSOR_TEST);gl.clearColor(0,0,0,0);
      for(const v of span.views)if(v.state==='off'){gl.scissor(v.viewport[0],v.viewport[1],v.viewport[2],v.viewport[3]);gl.clear(gl.COLOR_BUFFER_BIT);}
      gl.disable(gl.SCISSOR_TEST);
    }
    window.waveStatus.frames++;
  }
  // Turns the music's envelopes (audio-reactive.js) into this frame's look.
  // The wave carries the response: its light glows with the music, its
  // highlights catch the treble, a beat lands as a soft bloom of light, and
  // sections of the wave rise and settle in a slow travelling swell. The wave
  // never grows as a whole and nothing jumps. The background takes only a
  // faint, slow swell in its lit region (black stays black), never a flash.
  const restingMusic={light:1,shine:1,speed:1,flow:1},liveMusic={light:1,shine:1,speed:1,flow:1};
  let lastPulse=0,musicPhase=0,musicLastNow=0,musicResting=true,lastOnsets=-1,pulseFlip=false;
  // Two beat pulses that glide along the wave (world x), fading as they go.
  const beatPulses=[{x:0,s:0,dir:1,speed:1},{x:0,s:0,dir:1,speed:1}];
  function applyAudio(now){
    const a=window.BACKGROUND_MOTION_SETTINGS,sp=window.SPLINE_SETTINGS,e=window.EFFECT_SETTINGS,audio=window.XMBAudio;
    const dt=musicLastNow?clamp((now-musicLastNow)/1000,0,.1):0;musicLastNow=now;
    const st=audio&&audio.state;
    if(!audio||(!config.audioEnabled&&st.glow<.001&&st.swell<.001&&st.bloom<.001&&st.lowSwell<.001&&st.ripple<.001&&Math.abs(st.pan)<.001)){
      if(!musicResting){
        musicResting=true;sp.musicLift=0;sp.musicRipple=0;sp.musicSide=0;sp.musicPan=0;sp.musicPulseAS=0;sp.musicPulseBS=0;beatPulses[0].s=beatPulses[1].s=0;
        sp.waveIridescence=config.waveIridescence;sp.waveStrands=config.waveStrands;e.glow=performance.glow;e.breatheIntensity=config.breatheIntensity;
        if(lastPulse){a.pulse=0;sp.backgroundPulse=0;lastPulse=0;if(config.backgroundMode==='static'&&background&&background.render())backgroundFresh=true;}
      }
      if(audio)audio.clockLevel=0;window.waveStatus.audio=st||null;return restingMusic;
    }
    musicResting=false;
    const m=audio.sample(now,config),on=config.audioEnabled?1:0;
    const glow=m.glow*on,sparkle=m.sparkle*on,swell=m.swell*on,bloom=m.bloom*on,lowSwell=m.lowSwell*on,ripple=m.ripple*on,pan=m.pan*on;
    // Travelling swell: the bass sets how far long sections rise and settle,
    // the treble a fine shallow ripple. The phase drifts along the wave, a
    // little faster when the music is fuller and towards the louder channel.
    musicPhase=(musicPhase+dt*(.25+.7*swell*config.audioMotion)*(1+.5*pan))%(Math.PI*200);
    // Quality first: everything the music moves is broad and low in spatial
    // frequency. Fine detail (quick ripples, extra strands, steep highlights)
    // flickers on thin ribbons and reads as harsh, so the response keeps away
    // from it. Slow swells from the bass (up to about 2% of the screen height
    // on the default setting) and a shallow, long treble ripple.
    sp.musicLift=.02*config.audioWave*clamp(lowSwell*.8+bloom*.2,0,1.2);sp.musicPhase=musicPhase;
    sp.musicRipple=.0025*config.audioWave*clamp(ripple,0,1);
    // Stereo: the wave's glow leans towards the louder side, more so as the music fills.
    sp.musicPan=pan;sp.musicSide=.4*config.audioGlow*clamp(glow*1.4,0,1);
    // A trace of colour shimmer with the treble; strands stay as configured.
    sp.waveIridescence=clamp(config.waveIridescence+.1*config.audioGlow*sparkle,0,1);
    sp.waveStrands=config.waveStrands;
    // Beat pulses: each beat sends a soft band of light along the wave from the
    // louder side (alternating when the mix is centred), fading as it travels.
    if(lastOnsets<0)lastOnsets=m.onsets;
    if(m.onsets!==lastOnsets){
      lastOnsets=m.onsets;
      if(on&&config.audioGlow>0){
        const slot=beatPulses[beatPulses[0].s<=beatPulses[1].s?0:1],lo=spanRange[0],hi=spanRange[1];
        slot.dir=pan>.15?-1:pan<-.15?1:((pulseFlip=!pulseFlip)?1:-1);
        slot.x=slot.dir>0?lo-.2:hi+.2;slot.speed=(hi-lo+.4)/2.2;slot.s=.32*config.audioGlow*clamp(.55+.5*m.bass,0,1.1);
      }
    }
    for(const p of beatPulses)if(p.s>.001){p.x+=p.dir*p.speed*dt;p.s*=Math.exp(-dt/1.5);if(p.x<spanRange[0]-.3||p.x>spanRange[1]+.3)p.s=0;}else p.s=0;
    // A wide, soft band: broad enough never to read as a bright edge.
    sp.musicPulseAX=beatPulses[0].x;sp.musicPulseAS=beatPulses[0].s;sp.musicPulseBX=beatPulses[1].x;sp.musicPulseBS=beatPulses[1].s;sp.musicPulseW=.17;
    // Glow and breathing passes, when the user has them on, glow with the music too.
    e.glow=performance.glow>0?performance.glow*(1+.35*config.audioGlow*(glow+.5*bloom)):performance.glow;
    e.breatheIntensity=config.breatheEnabled?config.breatheIntensity*(1+.35*config.audioGlow*(glow+.5*bloom)):config.breatheIntensity;
    const pulse=Math.round(clamp(config.audioBackground*.22*swell,0,.35)*1000)/1000;
    if(pulse!==lastPulse){
      a.pulse=pulse;sp.backgroundPulse=pulse;lastPulse=pulse;
      // The static gradient draws only on change; the shifting one every frame.
      if(config.backgroundMode==='static'&&background&&background.render())backgroundFresh=true;
    }
    audio.clockLevel=clamp(config.audioClock*(.7*glow+.3*bloom),0,1);
    m.pulse=pulse;m.lift=sp.musicLift;window.waveStatus.audio=m;
    // One reused object: no allocation per frame.
    const r=liveMusic;
    // Light carries the response; highlights rise only a little and are
    // capped, so they never clip into a harsh edge.
    r.light=Math.min(1.32,1+config.audioGlow*(.26*glow+.16*bloom));
    r.shine=Math.min(1.25,1+config.audioGlow*(.14*sparkle+.1*glow+.1*bloom));
    r.speed=1+.6*config.audioMotion*swell;
    r.flow=1+1.8*config.audioColorShift*swell;
    return r;
  }
  // Movement: a fixed turn plus a slow sway and float on one cycle. Sway is a
  // sine, float a cosine of the same cycle, so the wave traces a soft ellipse
  // rather than nodding. It runs on the effect clock, which stops when paused.
  // The pivot is the centre of everything the wave covers (the whole span when
  // spanning), and the mesh reaches past each edge only while turned.
  function applyMovement(){
    const s=window.SPLINE_SETTINGS,rot=config.waveRotation,sway=config.waveSway,bob=config.waveBob;
    if(rot===0&&sway===0&&bob===0){s.waveRotation=0;s.waveBob=0;s.meshMargin=0;return;}
    const phase=effectTime/Math.max(6,config.waveSwayPeriod)*Math.PI*2;
    s.waveRotation=(rot+sway*Math.sin(phase))*Math.PI/180;
    s.waveBob=.028*bob*Math.cos(phase*.5+1.3);
    s.rotationPivot=spanPivot;
    s.meshMargin=rot!==0||sway>0?.22:0;
  }
  const frameStats={count:0,intervalSum:0,intervalMax:0,cpuSum:0,cpuMax:0};let lastPresented=0;
  window.waveStatus.frameStats=frameStats;
  // Frame pacing. Frames lock to the display's refresh: the wallpaper draws on
  // every n-th refresh, n being the whole number that best fits the selected
  // frame rate (60 fps on 120 Hz: every 2nd refresh; 60 on 144 Hz: every 2nd,
  // 72 fps, because alternating 2- and 3-refresh gaps would judder). Motion
  // advances by whole refresh periods, so each drawn frame moves exactly as far
  // as the one before, whatever jitter the timer has. Refreshes between drawn
  // frames do no work at all.
  // gaps counts refresh gaps between callbacks (1, 2, 3, 4 or more refreshes);
  // slowStarts counts drawn frames whose callback began more than 4 ms after
  // the refresh it belongs to (the page's main thread was busy).
  const pacing={period:0,vsync:0,lastDrawVsync:-Infinity,divisor:1,refreshHz:0,lockedFps:0,dropped:0,resync:0,gaps:[0,0,0,0],slowStarts:0,startDelayMax:0,draws:0};
  window.waveStatus.pacing=pacing;
  // Everything else on the page that changes pixels (the clock, the menu's
  // meters and tint) updates from these hooks, which run right after a drawn
  // frame. A refresh then carries either a complete new frame or nothing, and
  // no extra frame is ever presented between two of the wave's frames.
  const frameHooks=window.XMBFrameHooks=window.XMBFrameHooks||[];
  // And these run just before a drawn frame: the menu applies a drag's latest
  // position or size here, so the menu and its glass move in the same frame.
  const beforeFrameHooks=window.XMBBeforeFrameHooks=window.XMBBeforeFrameHooks||[];
  let pendingSeconds=0;
  function frame(now){
    frameId=0;if(paused||hidden)return;
    const startDelay=window.performance.now()-now;
    if(!last){last=now;pacing.lastDrawVsync=-Infinity;pendingSeconds=0;}
    const raw=now-last;last=now;
    let seconds=0;
    if(raw>0&&raw<250){
      // The refresh period: first guess from one gap, corrected down if a gap
      // proves shorter, then followed slowly from single-refresh gaps only.
      if(!pacing.period||raw<pacing.period*.6)pacing.period=raw;
      const steps=Math.max(1,Math.round(raw/pacing.period)),quantized=steps*pacing.period;
      if(steps===1&&Math.abs(raw-pacing.period)<pacing.period*.25)pacing.period+=(raw-pacing.period)*.04;
      pacing.vsync+=steps;pacing.gaps[Math.min(steps,4)-1]++;
      // Whole refreshes for motion; a gap that does not fit the grid (a
      // stall, a timer change) is taken as measured and counted.
      if(Math.abs(raw-quantized)<pacing.period*.45)seconds=quantized/1000;else{seconds=raw/1000;pacing.resync++;}
    }else if(raw>=250){pacing.lastDrawVsync=-Infinity;}   // resumed after a pause: draw now, no jump
    pendingSeconds+=seconds;
    const target=window.waveStatus.targetFps,refresh=pacing.period?1000/pacing.period:target;
    const n=Math.max(1,Math.round(refresh/target)),behind=pacing.vsync-pacing.lastDrawVsync;
    pacing.divisor=n;pacing.refreshHz=refresh;pacing.lockedFps=refresh/n;
    if(behind>=n){
      // Keep the phase when on time; after a missed refresh, re-phase from here.
      if(behind===n)pacing.lastDrawVsync+=n;else{if(Number.isFinite(pacing.lastDrawVsync))pacing.dropped+=Math.floor(behind/n)-1;pacing.lastDrawVsync=pacing.vsync;}
      const step=pendingSeconds;pendingSeconds=0;
      pacing.draws++;if(startDelay>4)pacing.slowStarts++;if(startDelay>pacing.startDelayMax)pacing.startDelayMax=startDelay;
      for(let i=0;i<beforeFrameHooks.length;i++)try{beforeFrameHooks[i](now);}catch(e){}
      backgroundFresh=false;
      stepColors(now);
      const response=window.desktopXmbResponse.sample(now,step);
      window.waveStatus.desktopXmb=response;
      // Music response: every term is zero at rest, so with the option off (or
      // silence) the wallpaper is exactly as configured.
      const music=applyAudio(now);
      const s=window.SPLINE_SETTINGS;
      s.brightness=config.brightness*response.light*music.light;
      s.highlightIntensity=config.highlightIntensity*response.light*music.shine;
      applyMovement();
      // A wallpaper on one display that is paused keeps every clock still.
      if(selfState!=='paused'){waveTime+=step*response.speed*music.speed*config.speed*(config.animationDirection==='reverse'?-1:1);particleTime+=step;backgroundTime+=step*config.shiftingSpeed*music.flow;effectTime+=step;}
      const started=window.performance.now();
      try{
        if(config.diagnosticsEnabled){
          diagnostics.beginFrame(now,window.waveStatus.targetFps);
          draw();
          diagnostics.recordFrame(now,window.performance.now()-started);
        }else draw();
      }catch(e){fail(e.message);return;}
      // Both canvases hold this frame until the task ends; the glass copies now.
      if(window.XMBGlass)try{window.XMBGlass.afterDraw(now,backgroundFresh);}catch(e){window.XMBGlass.stats.error=String(e);}
      for(let i=0;i<frameHooks.length;i++)try{frameHooks[i](now);}catch(e){}
      // Running sums for the menu's performance overview, which reads and clears
      // them: the interval between presented frames and this frame's CPU time.
      const f=frameStats,cpu=window.performance.now()-started;
      if(lastPresented){const gap=now-lastPresented;f.count++;f.intervalSum+=gap;if(gap>f.intervalMax)f.intervalMax=gap;f.cpuSum+=cpu;if(cpu>f.cpuMax)f.cpuMax=cpu;}
      lastPresented=now;
    }
    frameId=requestAnimationFrame(frame);
  }
  function schedule(){
    if(frameId)cancelAnimationFrame(frameId);frameId=0;last=0;nextFrame=0;displayInterval=0;lastPresented=0;pacing.lastDrawVsync=-Infinity;pendingSeconds=0;
    window.waveStatus.paused=paused||hidden;diagnostics.reset();if(!paused&&!hidden)frameId=requestAnimationFrame(frame);
  }
  window.wallpaperPropertyListener={
    applyUserProperties(props,source="host"){
      const modeBefore=config.backgroundMode;
      const toProps=values=>Object.fromEntries(Object.entries(values).map(([key,value])=>[key,{value}]));
      const incoming=Object.fromEntries(Object.entries(props).map(([key,p])=>[key,p.value]));
      const breathing=window.resolveBreathingChange(config,incoming);
      const clockThemed=window.resolveClockThemeChange?window.resolveClockThemeChange(config,breathing):breathing;
      const musicThemed=window.resolveMusicPresetChange?window.resolveMusicPresetChange(config,clockThemed):clockThemed;
      const themed=window.resolveMovementPresetChange?window.resolveMovementPresetChange(config,musicThemed):musicThemed;
      if(themed!==incoming)props=toProps(themed);
      // Manual edits in either settings surface leave a limiting preset while
      // carrying its visible effect values forward without a jump in look.
      if(source==='host'&&!props.performancePreset&&performance.id!=='custom'&&
        ['fpsMode','resolution','glow','blur'].some(key=>props[key]&&props[key].value!==config[key])){
        const manual={performancePreset:'custom',fpsMode:String(performance.fps),resolution:performance.resolution,
          glow:performance.glow,blur:performance.blur,particleDensity:Math.max(.2,config.particleDensity*performance.particleScale)};
        props={...Object.fromEntries(Object.entries(manual).map(([key,value])=>[key,{value}])),...props};
      }
      let changed=false,renderChanged=false;
      for(const key of Object.keys(config))if(props[key]){
        const value=props[key].value;let next=config[key];
        if(typeof next==='number'){const n=Number(value);if(Number.isFinite(n))next=n;}
        else if(typeof next==='boolean'){if(typeof value==='boolean')next=value;}
        else if(typeof value==='string')next=value;
        if(key==='advancedControls'&&!['closed','wave','motion','particles','background','effects','all'].includes(next))next='closed';
        if(next!==config[key]){config[key]=next;changed=true;if(!['diagnosticsEnabled','advancedControls','settingsPanel','panelTransparency','panelWidth','panelHeight','panelPosition','audioPreset','audioSource','clockEnabled','clockTheme','clockStyle','clockDate','clockHours','clockSize','clockGlow','clockBrightness','clockBreath','clockOpacity','clockTint','clockTintStrength','clockTextSize','clockLetterSpacing','clockGap','clockPadding','clockShimmer','clockShimmerWidth','clockTextBrightness','clockGlowBrightness'].includes(key))renderChanged=true;}
      }
      // Older copies exposed a raw particle-count slider. Retain enabled legacy
      // choices as subtle dust until a new preset is explicitly selected.
      if(props.particles&&!props.particlePreset){
        changed=true;renderChanged=true;
        const count=Number(props.particles.value);config.particlePreset=count>0?'dust':'off';
        if(count>0)config.particleDensity=clamp(count/window.PARTICLE_PRESETS.dust.count,.2,2);
      }
      window.dispatchEvent(new CustomEvent("xmb-settings",{detail:{props,source,config:{...config}}}));
      if(!changed)return;
      diagnostics.setEnabled(config.diagnosticsEnabled);
      if(renderChanged){
        // A change of background mode swaps renderers, so the old frame is
        // retained and faded over the new one. Everything else glides: preset
        // and tint choices over 0.65 s, slider nudges over a short 0.16 s.
        const modeSwitch=modeBefore!==config.backgroundMode&&spline&&background&&previousViewport&&!reducedMotion();
        if(modeSwitch){
          const modeAfter=config.backgroundMode;config.backgroundMode=modeBefore;
          if(modeBefore==='static'){background.invalidate();background.render();}
          draw();displayTransition.capture({width:previousViewport.width,height:previousViewport.height,background:backgroundCanvas,wave:canvas,backgroundBounds:previousViewport.backgroundBounds,waveBounds:previousViewport.waveBounds,duration:650});
          config.backgroundMode=modeAfter;
        }
        const gentle=['backgroundPreset','shiftingPreset','waveTint','waveFinish','glowTint','particleTint','breatheTint','breathePreset','customBlend','backgroundMode','waveColor','glowColor','particleColor','breatheColor'];
        colorTransitionMs=Object.keys(props).some(key=>gentle.includes(key))?650:160;
        try{updateSettings();}finally{colorTransitionMs=0;}
        // While the frame loop runs, the change shows in its next frame (at
        // most one frame away); drawing here as well would present an extra
        // frame between two of the loop's, once per slider step while dragging.
        // A canvas whose size changed has been cleared by the browser, so it is
        // redrawn at once.
        if(['spanDisplays','spanGap','spanVerticalOffset'].some(key=>key in props))updateDisplay('display settings');else{const cleared=resize();if(cleared||paused||hidden||!frameId)draw();}
        if(modeSwitch)displayTransition.reveal();
      }
      else window.waveStatus.advancedControls=config.advancedControls;
    },
    applyGeneralProperties(props){if(Number.isFinite(Number(props.fps))){hostFps=clamp(Number(props.fps),1,120);updateFrameRate();}},
    setPaused(value){const next=Boolean(value);if(next===paused)return;paused=next;schedule();}
  };
  document.addEventListener('visibilitychange',()=>{hidden=document.hidden;if(!hidden)updateDisplay('visible');schedule();});
  window.addEventListener('resize',queueDisplayResize);
  window.addEventListener('xmb-display-layout',()=>updateDisplay('live display topology'));
  window.addEventListener('pagehide',()=>displayTransition.dispose());
  // Read access for the menu glass: the two canvases, a way to redraw the
  // background on demand, and the colour shown where neither canvas draws.
  window.XMBRender={background:backgroundCanvas,wave:canvas,
    forceBackground(){if(config.backgroundMode==='shifting'){if(animatedBackground){animatedBackground.invalidate();animatedBackground.render(backgroundTime);}}else if(background){background.invalidate();background.render();}},
    baseColor:()=>document.body.style.background||'#03060c'};
  window.XMBDisplayRuntime={update:()=>updateDisplay('requested'),stats:()=>({...displayTransition.stats(),clocks:{waveTime,backgroundTime,effectTime},mapping:window.waveStatus.span})};
  for(const target of [canvas,backgroundCanvas]){
    target.addEventListener('webglcontextlost',e=>{e.preventDefault();paused=true;schedule();fail('Graphics context lost. Reapply the wallpaper.');});
    target.addEventListener('webglcontextrestored',()=>location.reload());
  }
  window.XMBSettings={get:()=>({...config}),set:(values,source="panel")=>window.wallpaperPropertyListener.applyUserProperties(Object.fromEntries(Object.entries(values).map(([k,value])=>[k,{value}])),source)};
  diagnostics.setEnabled(config.diagnosticsEnabled);draw();window.waveStatus.ready=true;schedule();
})();
