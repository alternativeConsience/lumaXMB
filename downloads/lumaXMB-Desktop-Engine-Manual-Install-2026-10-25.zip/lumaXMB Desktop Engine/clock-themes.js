'use strict';
// Clock themes: a clock design with its tuning. Choosing one changes the clock
// only; the background, wave and everything else stay as they are. Editing any
// clock control afterwards marks the theme Custom, as breathing presets do.
window.CLOCK_THEMES={
 ps3:{label:'Classic PS3',
  clock:{clockStyle:'strip',clockSize:100,clockBrightness:100,clockGlow:12,clockBreath:6,clockDate:true,clockOpacity:100,clockTint:'white',clockTintStrength:35}},
 glass:{label:'Glassmorphic',
  clock:{clockStyle:'glass',clockSize:105,clockBrightness:110,clockGlow:16,clockBreath:8,clockDate:true,clockOpacity:100,clockTint:'palette',clockTintStrength:30}},
 tinted:{label:'Tinted Glass',
  clock:{clockStyle:'glass',clockSize:100,clockBrightness:105,clockGlow:14,clockBreath:9,clockDate:true,clockOpacity:85,clockTint:'palette',clockTintStrength:60}},
 fade:{label:'Minimal Fade',
  clock:{clockStyle:'fade',clockSize:95,clockBrightness:85,clockGlow:8,clockBreath:10,clockDate:false,clockOpacity:70,clockTint:'white',clockTintStrength:35}},
 oled:{label:'Dark Glass',
  clock:{clockStyle:'dark',clockSize:95,clockBrightness:90,clockGlow:18,clockBreath:7,clockDate:true,clockOpacity:100,clockTint:'palette',clockTintStrength:45}},
 amber:{label:'Tinted Strip',
  clock:{clockStyle:'strip',clockSize:100,clockBrightness:95,clockGlow:14,clockBreath:6,clockDate:true,clockOpacity:100,clockTint:'palette',clockTintStrength:40}},
 psp:{label:'PSP Unboxed',
  clock:{clockStyle:'psp',clockSize:100,clockBrightness:100,clockGlow:6,clockBreath:6,clockDate:true,clockOpacity:100,clockTint:'white',clockTintStrength:35}},
 bare:{label:'Quiet Type',
  clock:{clockStyle:'bare',clockSize:90,clockBrightness:80,clockGlow:10,clockBreath:9,clockDate:true,clockOpacity:100,clockTint:'wave',clockTintStrength:25}}
};
window.CLOCK_THEME_PARAMS=['clockStyle','clockSize','clockBrightness','clockGlow','clockBreath','clockDate','clockOpacity','clockTint','clockTintStrength'];
window.resolveClockThemeChange=function(current,values){
 const params=window.CLOCK_THEME_PARAMS,theme=window.CLOCK_THEMES[values.clockTheme];
 if(theme&&!params.some(k=>k in values))return {...theme.clock,clockEnabled:true,...values};
 if(!('clockTheme' in values)&&params.some(k=>k in values&&values[k]!==current[k]))return {...values,clockTheme:'custom'};
 return values;
};
