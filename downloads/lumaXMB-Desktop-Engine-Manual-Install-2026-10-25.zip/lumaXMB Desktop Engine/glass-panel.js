'use strict';
// Refractive glass for the settings menu, drawn by the GPU beneath the menu's
// content. On each fresh wallpaper frame, and only while the menu is open, the
// region behind the menu is copied at full resolution and shaded in three
// passes: a separable blur (horizontal, then vertical) makes a smooth frost,
// and a final pass turns it into a slab of glass:
//  - the face is frosted, very slightly magnified, lifted and tinted;
//  - a narrow waterfall bevel curves the slab away at its edge, pulling the
//    scene in a little and sharpening it as it bends, with a faint colour
//    fringe only where the bend is steepest;
//  - a soft light sits on the rim where the bevel faces up, and a soft shade
//    where it turns down. No bright band, no outline, no outer glow.
// Depth comes from a soft CSS shadow beneath. Without WebGL the menu keeps its
// CSS surface.
(() => {
 const panel=document.getElementById('xmb-panel'),render=window.XMBRender;
 if(!panel||!render)return;
 const canvas=document.createElement('canvas');canvas.className='glass-surface';canvas.setAttribute('aria-hidden','true');
 panel.insertBefore(canvas,panel.firstChild);
 const gl=canvas.getContext('webgl2',{alpha:true,premultipliedAlpha:true,antialias:false,depth:false,stencil:false,powerPreference:'high-performance'});
 if(!gl){canvas.remove();return;}

 // Tunable at run time (window.XMBGlass.tune) for measurement.
 const tune={maxSource:2.4e6,   // source pixels; larger menus copy at reduced scale
  cadence:15.5};                 // ms between copies; the wave keeps its own rate
 const MARGIN=48,        // source extends this far past the menu, for the bend and blur
  BEVEL=26,             // width of the waterfall bevel, CSS px (capped at the corner radius)
  BLEND=56,             // width over which frost gives way to the sharp scene, CSS px
  REFRACT=.55,          // how far the rim pulls the scene in, in bevel widths
  FROST=9,              // fine frost sigma, CSS px (full resolution pass)
  FROST_WIDE=22,        // wide frost sigma, CSS px (half resolution passes)
  LENS=.03;             // face curvature: magnification grows towards the edges
 const source=document.createElement('canvas'),sctx=source.getContext('2d',{alpha:false});
 const cache=document.createElement('canvas'),cctx=cache.getContext('2d',{alpha:false});
 for(const c of [sctx,cctx]){c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';}

 function shader(type,text){const s=gl.createShader(type);gl.shaderSource(s,text);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
 const VERT=`#version 300 es
  out vec2 vUv;
  void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));vUv=p;gl_Position=vec4(p*2.-1.,0.,1.);}`;
 function program(fragment,names){
  const p=gl.createProgram();gl.attachShader(p,shader(gl.VERTEX_SHADER,VERT));gl.attachShader(p,shader(gl.FRAGMENT_SHADER,fragment));gl.linkProgram(p);
  if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));
  const u={};for(const n of names)u[n]=gl.getUniformLocation(p,n);return {p,u};
 }
 let blur,glass;
 try{
  // Gaussian blur along one axis: 9 bilinear taps covering 17 texels, sigma 3
  // texels, weights normalised to exactly one so repeated passes neither
  // brighten nor darken (a kernel that sums above one compounds into bands).
  blur=program(`#version 300 es
   precision highp float;in vec2 vUv;uniform sampler2D uSrc;uniform vec2 uStep;out vec4 frag;
   void main(){
    const float o[5]=float[](0.,1.4584,3.404,5.3518,7.3029);
    const float w[5]=float[](.13357,.23331,.13593,.05138,.01259);
    vec3 c=texture(uSrc,vUv).rgb*w[0];
    for(int i=1;i<5;i++){c+=texture(uSrc,vUv+uStep*o[i]).rgb*w[i];c+=texture(uSrc,vUv-uStep*o[i]).rgb*w[i];}
    frag=vec4(c,1.);
   }`,['uSrc','uStep']);
  glass=program(`#version 300 es
   precision highp float;
   uniform sampler2D uSharp,uFine,uWide;
   uniform vec2 uRes,uSize;
   uniform float uDpr,uMargin,uRadius,uBevel,uBlend,uRefract,uLens,uOpacity;
   uniform vec3 uTintA,uTintB,uTintC;
   out vec4 frag;
   vec2 toUv(vec2 p){return (p+uMargin)/(uSize+2.*uMargin);}
   void main(){
    vec2 p=vec2(gl_FragCoord.x,uRes.y-gl_FragCoord.y)/uDpr;
    vec2 c=uSize*.5,pc=p-c,q=abs(pc)-(c-uRadius);
    float d=length(max(q,0.))+min(max(q.x,q.y),0.)-uRadius;          // < 0 inside the slab
    vec2 n=(q.x>0.||q.y>0.)?sign(pc)*normalize(max(q,vec2(1e-4))):(q.x>q.y?vec2(sign(pc.x),0.):vec2(0.,sign(pc.y)));
    float x=clamp(1.+d/uBevel,0.,1.);                                  // 0 on the face, 1 at the edge
    float fall=x*x*(3.-2.*x);
    // The face is a shallow lens: the scene is drawn in a little, more so
    // towards the edges, so the whole slab reads as rounded glass.
    vec2 r2=pc/c;float lens=uLens*dot(r2,r2);
    // Waterfall: the lip is a circular arc, flat where it leaves the face and
    // curving ever faster towards the rim, stopped just short of vertical so
    // the pull stays finite. The bevel never exceeds the corner radius, so the
    // arc turns the corners without a crease.
    const float K=.94,ARC=.75505;                                       // ARC = 1 - sqrt(1 - K)
    float root=sqrt(1.-K*x*x),sag=(1.-root)/ARC;
    float bend=uRefract*uBevel*sag;
    // How much the scene is squeezed across the lip: source pixels per screen pixel.
    float squeeze=1.+uRefract*K*x/(root*ARC);
    vec2 sp=c+pc*(1.-lens)-n*bend,uv=toUv(sp);
    // Frost gives way to the clearer rim over a band twice as wide as the bend,
    // in two gentle steps: the wide blur hands over to the fine blur first,
    // then the fine blur to the sharp scene, each with an eased ramp. The
    // clearest point stays short of fully sharp, so no seam ever shows.
    float s=clamp(1.+d/uBlend,0.,1.);
    float toFine=smoothstep(0.,.7,s),toSharp=smoothstep(.35,1.,s);
    vec3 frost=mix(texture(uWide,uv).rgb,texture(uFine,uv).rgb,.42+.58*toFine);
    // Where the lip squeezes the scene, one screen pixel covers several source
    // pixels; three taps across that footprint keep the rim from shimmering as
    // the wave moves beneath it.
    vec3 sharpC=texture(uSharp,uv).rgb;
    if(squeeze>1.05){
     vec2 o=n*(squeeze-1.)*.38/uDpr;
     sharpC=(sharpC*2.+texture(uSharp,toUv(sp-o)).rgb+texture(uSharp,toUv(sp+o)).rgb)*.25;
    }
    vec3 scene=mix(frost,sharpC,.5*toSharp*toSharp);
    // Dispersion only where the lip is steepest, drawn from the same frost-to-
    // clear blend so the fringe is as soft as the glass around it.
    float steep=pow(x,3.);
    if(steep>.001){
     vec2 ca=n*bend*.06,ua=toUv(sp-ca),ub=toUv(sp+ca);
     float k=.5*toSharp*toSharp;
     float red=mix(texture(uFine,ua).r,texture(uSharp,ua).r,k),blue=mix(texture(uFine,ub).b,texture(uSharp,ub).b,k);
     scene=mix(scene,vec3(red,scene.g,blue),.4*steep);
    }
    // Clear glass: the scene comes through almost as it is, deepened slightly
    // towards the tint so type stays readable; no milk, no white cast.
    vec3 col=scene*.96;
    float g=clamp(dot(p/uSize-.5,vec2(.34,.94))+.5,0.,1.);
    vec3 tint=g<.45?mix(uTintA,uTintB,g/.45):mix(uTintB,uTintC,(g-.45)/.55);
    col=mix(col,tint*.9,uOpacity*.55);
    // A thin contact shade where the lip leaves the face gives the slab its
    // thickness; it follows the arc's own curvature, so it is softest at the face.
    float inner=sag*(1.-sag)*4.;
    col*=1.-.045*inner;
    // Rim: a trace of light where the lip faces the light, a trace of shade
    // opposite, both riding the steepest part of the arc. Barely there; the
    // refraction does the talking.
    float up=max(dot(n,normalize(vec2(-.35,-1.))),0.),down=max(dot(n,normalize(vec2(.25,1.))),0.);
    float rim=pow(fall,3.)*smoothstep(1.,3.,squeeze);
    col+=.022*rim*up;
    col*=1.-.09*rim*down;
    // Dither against 8-bit banding in the smooth frost: fixed to the pixel
    // grid, one step of 1/255, never temporal.
    float dn=fract(52.9829189*fract(dot(gl_FragCoord.xy,vec2(.06711056,.00583715))));
    col+=(dn-.5)/255.;
    float alpha=clamp(.5-d*uDpr,0.,1.);                               // one-pixel anti-aliased edge
    frag=vec4(clamp(col,0.,1.)*alpha,alpha);
   }`,['uSharp','uFine','uWide','uRes','uSize','uDpr','uMargin','uRadius','uBevel','uBlend','uRefract','uLens','uOpacity','uTintA','uTintB','uTintC']);
 }catch(e){canvas.remove();window.XMBGlass={afterDraw(){},stats:{active:false,error:String(e)}};return;}

 const vao=gl.createVertexArray();
 function makeTexture(){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);for(const [k,v] of [[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,k,v);return t;}
 // Render targets: two full-size (fine blur ping/pong) and two half-size (the
 // wide blur, run twice at half size for a large, smooth radius at low cost).
 const sharp=makeTexture();
 const targets={fineA:[makeTexture(),gl.createFramebuffer()],fineB:[makeTexture(),gl.createFramebuffer()],wideA:[makeTexture(),gl.createFramebuffer()],wideB:[makeTexture(),gl.createFramebuffer()]};
 // The blur chain runs in 16-bit float where the GPU can render to it, so dark
 // gradients keep their smoothness through four passes; 8-bit otherwise.
 let floatTargets=Boolean(gl.getExtension('EXT_color_buffer_float')),fboSize='';
 function ensureTargets(w,h){
  const key=w+'x'+h+(floatTargets?'f':'b');if(key===fboSize)return;fboSize=key;
  for(const [name,[t,f]] of Object.entries(targets)){
   const tw=name.startsWith('wide')?Math.max(1,Math.round(w/2)):w,th=name.startsWith('wide')?Math.max(1,Math.round(h/2)):h;
   gl.bindTexture(gl.TEXTURE_2D,t);
   if(floatTargets)gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,tw,th,0,gl.RGBA,gl.HALF_FLOAT,null);
   else gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,tw,th,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
   gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,t,0);
   if(floatTargets&&gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE){floatTargets=false;gl.bindFramebuffer(gl.FRAMEBUFFER,null);fboSize='';return ensureTargets(w,h);}
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
 }
 function blurPass(fromTex,[toTex,toFbo],w,h,stepX,stepY){
  gl.bindTexture(gl.TEXTURE_2D,fromTex);gl.bindFramebuffer(gl.FRAMEBUFFER,toFbo);gl.viewport(0,0,w,h);
  gl.uniform2f(blur.u.uStep,stepX,stepY);gl.drawArrays(gl.TRIANGLES,0,3);return toTex;
 }

 const stats={active:false,frames:0,captureMs:0,renderMs:0,error:null,size:null,scale:1};
 let backgroundValid=false,cachedRegion='',lastCapture=0,lost=false;
 const average=(old,value)=>old?old*.9+value*.1:value;
 const rgb=(name,fallback)=>{const v=(panel.style.getPropertyValue(name)||fallback).split(',').map(Number);return v.length===3&&v.every(Number.isFinite)?v.map(c=>c/255):fallback.split(',').map(c=>Number(c)/255);};
 function blit(ctx,element,region,scale){
  const r=element.getBoundingClientRect();if(!r.width||!r.height)return;
  const kx=element.width/r.width,ky=element.height/r.height;
  const x0=Math.max(region.x,r.left),y0=Math.max(region.y,r.top),x1=Math.min(region.x+region.w,r.right),y1=Math.min(region.y+region.h,r.bottom);
  if(x1<=x0||y1<=y0)return;
  ctx.drawImage(element,(x0-r.left)*kx,(y0-r.top)*ky,(x1-x0)*kx,(y1-y0)*ky,(x0-region.x)*scale,(y0-region.y)*scale,(x1-x0)*scale,(y1-y0)*scale);
 }
 function shade(rect,scale){
  const dpr=window.devicePixelRatio||1,w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round(rect.height*dpr));
  if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
  const sw=source.width,sh=source.height;ensureTargets(sw,sh);
  gl.bindVertexArray(vao);gl.disable(gl.BLEND);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,sharp);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);
  // Frost. Fine: one horizontal + vertical pass at full size. Wide: two
  // horizontal + vertical passes at half size, read back with bilinear
  // filtering, which is both smoother and cheaper than one huge kernel.
  gl.useProgram(blur.p);gl.uniform1i(blur.u.uSrc,0);
  // Kernel sigma is 3 texels; the step scales it to the wanted radius. The
  // wide chain runs twice, so each pass carries the radius divided by root 2.
  const fine=FROST*scale/3,hw=Math.max(1,Math.round(sw/2)),hh=Math.max(1,Math.round(sh/2)),wide=FROST_WIDE*scale/2/3/Math.SQRT2;
  let t=blurPass(sharp,targets.fineA,sw,sh,fine/sw,0);t=blurPass(t,targets.fineB,sw,sh,0,fine/sh);
  const fineTex=t;
  t=blurPass(sharp,targets.wideA,hw,hh,wide/hw,0);t=blurPass(t,targets.wideB,hw,hh,0,wide/hh);
  t=blurPass(t,targets.wideA,hw,hh,wide/hw,0);t=blurPass(t,targets.wideB,hw,hh,0,wide/hh);
  const wideTex=t;
  // Glass.
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,w,h);gl.useProgram(glass.p);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,sharp);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,fineTex);gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,wideTex);
  const settings=window.XMBSettings?window.XMBSettings.get():{},u=glass.u;
  gl.uniform1i(u.uSharp,0);gl.uniform1i(u.uFine,1);gl.uniform1i(u.uWide,2);gl.uniform2f(u.uRes,w,h);gl.uniform2f(u.uSize,rect.width,rect.height);gl.uniform1f(u.uDpr,dpr);
  // A bevel wider than the corner radius would crease along the corner
  // diagonals; keep it inside the radius.
  const radius=parseFloat(getComputedStyle(panel).borderTopLeftRadius)||26;
  gl.uniform1f(u.uMargin,MARGIN);gl.uniform1f(u.uRadius,radius);
  gl.uniform1f(u.uBevel,Math.min(BEVEL,radius));gl.uniform1f(u.uBlend,BLEND);gl.uniform1f(u.uRefract,REFRACT);gl.uniform1f(u.uLens,LENS);
  gl.uniform1f(u.uOpacity,Math.min(1,Math.max(0,1-(Number(settings.panelTransparency)||50)/100)));
  gl.uniform3fv(u.uTintA,rgb('--tint-a','24,66,132'));gl.uniform3fv(u.uTintB,rgb('--tint-b','12,42,96'));gl.uniform3fv(u.uTintC,rgb('--tint-c','6,22,58'));
  gl.drawArrays(gl.TRIANGLES,0,3);
  gl.activeTexture(gl.TEXTURE0);
 }
 function afterDraw(now,backgroundFresh){
  if(lost||!panel.classList.contains('open')){stats.active=false;return;}
  if(now-lastCapture<tune.cadence-.5)return;lastCapture=now;
  const started=performance.now(),rect=panel.getBoundingClientRect();
  if(rect.width<2||rect.height<2)return;
  const region={x:rect.left-MARGIN,y:rect.top-MARGIN,w:rect.width+2*MARGIN,h:rect.height+2*MARGIN};
  // Full resolution up to a budget; a very large menu copies a little smaller.
  const dpr=window.devicePixelRatio||1,scale=Math.min(dpr,Math.sqrt(tune.maxSource/(region.w*region.h*dpr*dpr))*dpr);
  const sw=Math.max(1,Math.ceil(region.w*scale)),sh=Math.max(1,Math.ceil(region.h*scale));
  if(source.width!==sw||source.height!==sh){source.width=cache.width=sw;source.height=cache.height=sh;backgroundValid=false;for(const c of [sctx,cctx]){c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';}}
  const key=Math.round(region.x)+','+Math.round(region.y)+','+sw+','+sh;
  if(key!==cachedRegion){cachedRegion=key;backgroundValid=false;}
  if(!backgroundValid||backgroundFresh){
   if(!backgroundFresh)render.forceBackground();
   cctx.fillStyle=render.baseColor();cctx.fillRect(0,0,sw,sh);blit(cctx,render.background,region,scale);backgroundValid=true;
  }
  sctx.drawImage(cache,0,0);blit(sctx,render.wave,region,scale);
  const copied=performance.now();
  shade(rect,scale);
  if(!panel.classList.contains('glass-gl'))panel.classList.add('glass-gl');
  stats.active=true;stats.frames++;stats.size=[canvas.width,canvas.height,sw,sh];stats.scale=Number(scale.toFixed(3));stats.floatTargets=floatTargets;
  stats.captureMs=average(stats.captureMs,copied-started);stats.renderMs=average(stats.renderMs,performance.now()-copied);
 }
 const invalidate=()=>{backgroundValid=false;};
 window.addEventListener('xmb-settings',invalidate);window.addEventListener('xmb-viewport',invalidate);window.addEventListener('resize',invalidate);
 canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;panel.classList.remove('glass-gl');stats.active=false;stats.error='context lost';});
 window.XMBGlass={afterDraw,stats,tune(values){Object.assign(tune,values||{});backgroundValid=false;return {...tune};}};
})();
