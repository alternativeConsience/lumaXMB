'use strict';
(() => {
  const CAPACITY=512,WINDOW_MS=4000,UI_INTERVAL_MS=250;
  const finiteNumber=value=>Number.isFinite(Number(value))?Number(value):0;

  // Timing stays on the CPU. Neither this overlay nor its chart waits for the
  // GPU, reads rendered pixels, or starts another animation loop.
  window.createWaveDiagnostics=function createWaveDiagnostics(status){
    let enabled=false,disposed=false,targetFps=60,lastDraw=0,nextUI=0;
    let intervals,timestamps,submissions,sortedIntervals,sortedSubmissions;
    let cursor=0,count=0,panel,chart,context,fields,latest;

    function allocateHistory(){
      if(intervals)return;
      intervals=new Float32Array(CAPACITY);
      timestamps=new Float64Array(CAPACITY);
      submissions=new Float32Array(CAPACITY);
      sortedIntervals=new Float32Array(CAPACITY);
      sortedSubmissions=new Float32Array(CAPACITY);
    }
    function makeText(parent,text,css){
      const element=document.createElement('div');
      element.textContent=text;
      if(css)element.style.cssText=css;
      parent.appendChild(element);return element;
    }
    function mount(){
      if(panel)return;
      panel=document.createElement('aside');
      panel.id='wave-performance-diagnostics';
      panel.setAttribute('aria-label','Wallpaper rendering diagnostics');
      panel.style.cssText='position:fixed;right:20px;top:20px;width:340px;max-width:calc(100vw - 40px);box-sizing:border-box;padding:12px 14px;z-index:2147483646;pointer-events:none;color:#edf4ff;background:rgba(3,6,12,.90);border:1px solid rgba(177,202,238,.22);border-radius:10px;font:11px/1.5 -apple-system,BlinkMacSystemFont,sans-serif;font-variant-numeric:tabular-nums;';
      makeText(panel,'Performance diagnostics','font-weight:600;font-size:12px;color:#fff;margin-bottom:4px;');
      fields={
        cadence:makeText(panel,'Collecting draw intervals…'),
        interval:makeText(panel,''),
        submission:makeText(panel,''),
        resolution:makeText(panel,'','color:#b8c8dd;margin-top:3px;')
      };
      chart=document.createElement('canvas');
      const scale=Math.min(window.devicePixelRatio||1,2);
      chart.width=Math.round(312*scale);chart.height=Math.round(76*scale);
      chart.style.cssText='position:static;display:block;width:100%;height:76px;margin-top:7px;';
      chart.setAttribute('aria-label','Rolling four second draw interval chart');
      panel.appendChild(chart);context=chart.getContext('2d',{alpha:true});
      makeText(panel,'Draw intervals • green: budget • red: 1.5× budget','font-size:10px;color:#b8c8dd;');
      makeText(panel,'CPU submission timing; GPU and physical presentation unmeasured.','font-size:10px;color:#93a4ba;margin-top:5px;');
      document.body.appendChild(panel);
    }
    function clearHistory(){
      cursor=0;count=0;lastDraw=0;nextUI=0;
      latest={enabled,targetFps,sampleCount:0,intervalCount:0,windowMs:WINDOW_MS,drawFps:0,meanIntervalMs:0,p95IntervalMs:0,maxIntervalMs:0,hitchCount:0,hitchThresholdMs:1500/targetFps,meanSubmissionMs:0,p95SubmissionMs:0,physicalPresentationMeasured:false,gpuTimingMeasured:false};
      status.diagnostics=latest;
    }
    function sampleStats(now){
      let intervalCount=0,submissionCount=0,sum=0,submissionSum=0,hitches=0;
      const cutoff=now-WINDOW_MS,threshold=1500/targetFps;
      for(let i=0;i<count;i++){
        const index=(cursor-count+i+CAPACITY)%CAPACITY;
        if(timestamps[index]<cutoff)continue;
        const interval=intervals[index],submission=submissions[index];
        if(interval>0){
          sortedIntervals[intervalCount++]=interval;sum+=interval;
          if(interval>threshold)hitches++;
        }
        sortedSubmissions[submissionCount++]=submission;submissionSum+=submission;
      }
      const orderedIntervals=sortedIntervals.subarray(0,intervalCount);
      const orderedSubmissions=sortedSubmissions.subarray(0,submissionCount);
      orderedIntervals.sort();orderedSubmissions.sort();
      const percentile=(values,n)=>n?values[Math.max(0,Math.ceil(n*.95)-1)]:0;
      return {enabled,targetFps,sampleCount:submissionCount,intervalCount,windowMs:WINDOW_MS,
        drawFps:sum>0?intervalCount*1000/sum:0,meanIntervalMs:intervalCount?sum/intervalCount:0,
        p95IntervalMs:percentile(orderedIntervals,intervalCount),maxIntervalMs:intervalCount?orderedIntervals[intervalCount-1]:0,hitchCount:hitches,hitchThresholdMs:threshold,
        meanSubmissionMs:submissionCount?submissionSum/submissionCount:0,
        p95SubmissionMs:percentile(orderedSubmissions,submissionCount),
        physicalPresentationMeasured:false,gpuTimingMeasured:false};
    }
    function paintChart(now,stats){
      if(!context)return;
      const width=312,height=76,scale=chart.width/width;
      context.setTransform(scale,0,0,scale,0,0);context.clearRect(0,0,width,height);
      const left=0,right=width,top=14,bottom=height-7,budget=1000/targetFps;
      const ceiling=Math.max(budget*3,stats.p95IntervalMs*1.2);
      const y=ms=>bottom-Math.min(1,Math.max(0,ms)/ceiling)*(bottom-top);
      context.lineWidth=1;context.strokeStyle='rgba(150,175,208,.16)';
      context.beginPath();context.moveTo(left,bottom);context.lineTo(right,bottom);context.stroke();
      for(const [level,color] of [[budget,'rgba(115,227,194,.48)'],[budget*1.5,'rgba(255,127,133,.48)']]){
        context.strokeStyle=color;context.setLineDash([3,3]);context.beginPath();
        context.moveTo(left,y(level));context.lineTo(right,y(level));context.stroke();
      }
      context.setLineDash([]);context.strokeStyle='#b9d8ff';context.lineWidth=1.25;
      context.beginPath();let started=false;
      const cutoff=now-WINDOW_MS;
      for(let i=0;i<count;i++){
        const index=(cursor-count+i+CAPACITY)%CAPACITY,stamp=timestamps[index],interval=intervals[index];
        if(stamp<cutoff||interval<=0)continue;
        const x=Math.max(left,Math.min(right,(stamp-cutoff)/WINDOW_MS*width));
        if(!started){context.moveTo(x,y(interval));started=true;}else context.lineTo(x,y(interval));
      }
      context.stroke();
      context.fillStyle='#93a4ba';context.font='9px -apple-system,BlinkMacSystemFont,sans-serif';
      context.textBaseline='top';context.fillText('Interval ms · 4 s',0,0);
      context.textAlign='right';context.fillText(ceiling.toFixed(0)+' ms',width,0);context.textAlign='left';
    }
    function paint(now){
      if(!enabled||!panel)return;
      latest=sampleStats(now);status.diagnostics=latest;
      const paused=Boolean(status.paused);
      const requested=finiteNumber(status.requestedFps),host=finiteNumber(status.hostFps);
      const targetLabel=targetFps+' fps'+(requested>targetFps?' ('+requested+' requested · host cap '+host+')':'');
      fields.cadence.textContent=paused?'Paused — timing resets on resume':latest.intervalCount?
        'Draw cadence '+latest.drawFps.toFixed(1)+' fps / target '+targetLabel:'Collecting draw intervals · target '+targetLabel;
      fields.interval.textContent='Interval p95 '+latest.p95IntervalMs.toFixed(2)+' ms · max '+latest.maxIntervalMs.toFixed(1)+' ms · hitches '+latest.hitchCount;
      fields.submission.textContent='JS submission '+latest.meanSubmissionMs.toFixed(2)+' ms avg · '+latest.p95SubmissionMs.toFixed(2)+' ms p95';
      const size=Array.isArray(status.renderSize)?status.renderSize.join(' × '):'—';
      const bg=Array.isArray(status.backgroundRenderSize)?status.backgroundRenderSize.join(' × '):'—';
      const effect=status.effects||{};
      const extras=[];
      if(effect.active)extras.push((effect.sceneSamples||1)+'× scene');
      if(status.particleCount>0)extras.push(status.particleCount+' particles');
      fields.resolution.textContent='Wave '+size+' px · background '+bg+' px'+(extras.length?' · '+extras.join(' · '):'');
      paintChart(now,latest);nextUI=now+UI_INTERVAL_MS;
    }
    function setEnabled(value){
      if(disposed)return;
      const next=Boolean(value);if(next===enabled)return;
      enabled=next;
      if(enabled){targetFps=Math.max(1,Math.min(240,finiteNumber(status.targetFps)||60));allocateHistory();mount();clearHistory();paint(0);}
      else{
        if(panel)panel.remove();panel=null;chart=null;context=null;fields=null;
        clearHistory();
      }
    }
    function beginFrame(now,fps){
      if(!enabled||disposed)return;
      const next=Math.max(1,Math.min(240,finiteNumber(fps)||finiteNumber(status.targetFps)||60));
      if(next!==targetFps){targetFps=next;clearHistory();}
    }
    function recordFrame(now,drawDuration){
      if(!enabled||disposed)return;
      now=Number(now);if(!Number.isFinite(now)||now<0)return;
      // A backwards clock is a new observation period; repeated timestamps do
      // not count as frames or inflate FPS.
      if(count&&now<lastDraw)clearHistory();
      if(count&&now===lastDraw)return;
      intervals[cursor]=count?now-lastDraw:0;
      timestamps[cursor]=now;
      submissions[cursor]=Math.max(0,finiteNumber(drawDuration));
      lastDraw=now;cursor=(cursor+1)%CAPACITY;count=Math.min(CAPACITY,count+1);
      if(now>=nextUI)paint(now);
    }
    function reset(){
      if(disposed)return;
      clearHistory();if(enabled)paint(0);
    }
    function getStats(){
      return enabled&&count?sampleStats(lastDraw):{...latest,enabled};
    }
    function dispose(){
      if(disposed)return;
      setEnabled(false);disposed=true;
      intervals=timestamps=submissions=sortedIntervals=sortedSubmissions=null;
    }
    clearHistory();
    return {setEnabled,beginFrame,recordFrame,reset,getStats,dispose};
  };
})();
