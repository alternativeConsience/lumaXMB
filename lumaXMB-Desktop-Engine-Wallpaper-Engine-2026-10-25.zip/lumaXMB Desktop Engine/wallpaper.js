'use strict';
(() => {
  const canvas=document.getElementById('wave-canvas');
  const gl=canvas.getContext('webgl2',{antialias:false,alpha:true,depth:false,stencil:false,powerPreference:'high-performance'});
  const backgroundCanvas=document.getElementById('background-canvas');
  const backgroundGL=backgroundCanvas.getContext('webgl2',{antialias:false,alpha:false,depth:false,stencil:false,powerPreference:'high-performance'});
  const error=document.getElementById('error');
  function fail(message){error.hidden=false;error.textContent=message;window.waveStatus={error:message};}
  if(!gl||!backgroundGL){fail('This wallpaper requires WebGL 2.');return;}
  const config={
    antiAliasing:'4',panelTransparency:50,panelWidth:640,panelHeight:1200,edgeSoftness:1,highlightSoftness:1,highlightIntensity:1,meshQuality:"smooth",settingsPanel:false,diagnosticsEnabled:false,performancePreset:'custom',fpsMode:'60',wavePreset:'sony',animationPreset:'classic',backgroundMode:'static',backgroundPreset:'midnight',particlePreset:'off',
    shiftingPreset:'console',shiftingStyle:'flow',shiftingSpeed:1,shiftingStrength:1,shiftingPeriod:90,shiftingAngle:90,shiftingSoftness:0,
    shiftingColor1:'0.02 0.05 0.18',shiftingColor2:'0.13 0.03 0.28',shiftingColor3:'0.01 0.22 0.25',shiftingColor4:'0.03 0.08 0.32',
    gradientStart:'0.001 0.001 0.009',gradientMiddle:'0.004 0.006 0.028',gradientEnd:'0.018 0.019 0.086',gradientAngle:90,customBlend:'three',
    speed:1,brightness:.98,resolution:1,advancedControls:'closed',
    waveAmplitude:1,waveFrequency:1,waveDetail:1,wavePosition:0,gloss:1,glassOpacity:1,highlightWidth:1,
    waveIridescence:.35,waveStrands:.6,waveFinish:'original',waveTint:'silver',waveColor:'0.25 0.65 1',waveTintStrength:1,
    spanDisplays:'auto',spanGap:1.2,spanVerticalOffset:0,
    animationStrength:1,animationDirection:'forward',
    particleDensity:1,particleSize:1,particleSpeed:1,sparkle:.55,particleTint:'palette',particleColor:'0.72 0.84 1',
    backgroundExposure:1,backgroundRotation:0,backgroundBlackLevel:0,
    breatheEnabled:false,breathePreset:"silk",breatheMode:"full",breathePeriod:9,breatheIntensity:0.85,breatheMinimum:4,breatheWidth:60,breatheSoftness:0.9,breatheRadius:22,breatheThreshold:0.025,breatheTint:"wave",breatheColor:"0.3 0.65 1",
    glow:0,glowRadius:12,glowThreshold:.55,glowTint:'palette',glowColor:'0.7 0.85 1',blur:0,blurQuality:'balanced'
  };
  // Windows port: match project defaults before the first rendered frame.
  Object.assign(config,window.XMB_INITIAL_SETTINGS||{});
  const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
  const limits={breathePeriod:[2,60],breatheIntensity:[0,3],breatheMinimum:[0,100],breatheWidth:[5,150],breatheSoftness:[.1,1],breatheRadius:[2,60],breatheThreshold:[0,1],speed:[.1,3],brightness:[.2,1.5],resolution:[.5,1],waveAmplitude:[.3,1.6],waveFrequency:[.5,1.75],waveDetail:[.35,1.8],wavePosition:[-.15,.15],gloss:[.3,2],glassOpacity:[0,2],highlightWidth:[.5,2],waveIridescence:[0,1],waveStrands:[0,1],waveTintStrength:[0,1],spanGap:[0,10],spanVerticalOffset:[-60,60],animationStrength:[0,1.5],particleDensity:[.2,2],particleSize:[.5,2],particleSpeed:[.1,2],sparkle:[0,1],backgroundExposure:[.2,1.4],backgroundRotation:[-180,180],backgroundBlackLevel:[0,.3],gradientAngle:[0,360],shiftingSpeed:[0,3],shiftingStrength:[0,1],shiftingPeriod:[15,300],shiftingAngle:[0,360],shiftingSoftness:[0,24],glow:[0,3],glowRadius:[2,36],glowThreshold:[0,1],blur:[0,12]};
  let performance=window.resolvePerformanceSettings(config);
  let background,animatedBackground,spline,particles,effects,renderedBackgroundMode="static",waveViewportHeight=1,waveViewportBottom=0;
  let hostFps=120,paused=false,hidden=document.hidden,frameId=0,last=0,nextFrame=0,waveTime=0,particleTime=0,backgroundTime=0,effectTime=0,displayInterval=0;
  const waveAttributes=gl.getContextAttributes(),backgroundAttributes=backgroundGL.getContextAttributes();
  window.waveStatus={ready:false,frames:0,paused:false,depthBuffer:Boolean(waveAttributes.depth),stencilBuffer:Boolean(waveAttributes.stencil),backgroundDepthBuffer:Boolean(backgroundAttributes.depth),backgroundStencilBuffer:Boolean(backgroundAttributes.stencil)};
  const diagnostics=window.createWaveDiagnostics(window.waveStatus);
  function updateFrameRate(){
    const previous=window.waveStatus.targetFps;
    window.waveStatus.requestedFps=performance.fps;
    window.waveStatus.hostFps=hostFps;
    window.waveStatus.targetFps=Math.min(performance.fps,hostFps);
    if(previous!==window.waveStatus.targetFps)nextFrame=0;
  }
  function parseColor(value,fallback){
    const rgb=String(value).trim().split(/\s+/).map(Number);
    return rgb.length===3&&rgb.every(Number.isFinite)?rgb.map(v=>clamp(v,0,1)):fallback;
  }
  function updateSettings(){
    for(const [key,range] of Object.entries(limits))config[key]=clamp(config[key],range[0],range[1]);
    if(!['full','ltr','rtl','bounce','center','edges'].includes(config.breatheMode))config.breatheMode='full';
    if(!['wave','palette','silver','custom'].includes(config.breatheTint))config.breatheTint='wave';
    if(config.breathePreset!=='custom'&&!window.BREATHING_GLOW_PRESETS[config.breathePreset])config.breathePreset='custom';
    if(!['static','shifting'].includes(config.backgroundMode))config.backgroundMode='static';
    if(config.shiftingPreset!=='custom'&&!window.ANIMATED_BACKGROUND_PRESETS[config.shiftingPreset])config.shiftingPreset='console';
    if(!window.BACKGROUND_MOTION_STYLES[config.shiftingStyle])config.shiftingStyle='flow';
    if(!['30','60','120'].includes(config.fpsMode))config.fpsMode='60';
    if(!['auto','off'].includes(config.spanDisplays))config.spanDisplays='auto';
    if(!window.PERFORMANCE_PRESETS[config.performancePreset])config.performancePreset='custom';
    if(!['closed','wave','motion','particles','background','effects','all'].includes(config.advancedControls))config.advancedControls='closed';
    performance=window.resolvePerformanceSettings(config);updateFrameRate();
    if(!['fast','balanced','high'].includes(config.blurQuality))config.blurQuality='balanced';
    if(!['palette','silver','warm','custom'].includes(config.glowTint))config.glowTint='palette';
    if(!['original','clear'].includes(config.waveFinish))config.waveFinish='original';
    if(!['silver','palette','custom','warm','ice','violet','rose'].includes(config.waveTint))config.waveTint='silver';
    if(!window.WAVE_PRESETS[config.wavePreset])config.wavePreset='sony';
    if(!window.ANIMATION_PRESETS[config.animationPreset])config.animationPreset='classic';
    if(config.backgroundPreset!=='custom'&&!window.BACKGROUND_PRESETS[config.backgroundPreset])config.backgroundPreset='midnight';
    if(config.particlePreset!=='off'&&!window.PARTICLE_PRESETS[config.particlePreset])config.particlePreset='off';
    if(!['forward','reverse'].includes(config.animationDirection))config.animationDirection='forward';
    if(!['palette','silver','warm','custom'].includes(config.particleTint))config.particleTint='palette';
    const s=window.SPLINE_SETTINGS,wave=window.WAVE_PRESETS[config.wavePreset],motion=window.ANIMATION_PRESETS[config.animationPreset];
    s.waveShape=wave.shape;s.waveMode=wave.mode;s.motionParams=motion.params;s.motionMode=motion.mode;
    for(const key of ['waveAmplitude','waveFrequency','waveDetail','wavePosition','gloss','glassOpacity','highlightWidth','edgeSoftness','highlightSoftness','highlightIntensity','meshQuality','waveIridescence','waveStrands','animationStrength','brightness','backgroundExposure'])s[key]=config[key];
    if(config.backgroundPreset==='custom'){
      for(const key of ['gradientStart','gradientMiddle','gradientEnd'])s[key]=parseColor(config[key],s[key]);
      s.gradientAngle=config.gradientAngle+config.backgroundRotation;s.twoTone=config.customBlend==='two';s.blackFloor=false;s.backgroundBlackPoint=config.backgroundBlackLevel;
      if(s.twoTone)s.gradientMiddle=s.gradientStart.map((v,i)=>(v+s.gradientEnd[i])/2);
    }else{
      const p=window.BACKGROUND_PRESETS[config.backgroundPreset];
      s.gradientStart=p.start;s.gradientMiddle=p.middle;s.gradientEnd=p.end;s.gradientAngle=p.angle+config.backgroundRotation;
      s.twoTone=p.twoTone;s.blackFloor=p.blackFloor;s.backgroundBlackPoint=clamp((p.blackPoint||0)+config.backgroundBlackLevel,0,.85);
    }
    const a=window.BACKGROUND_MOTION_SETTINGS;
    let activeTint=s.gradientEnd,lighting=s.gradientMiddle;
    if(config.shiftingPreset==='custom'){
      a.colors=[1,2,3,4].map(i=>parseColor(config['shiftingColor'+i],[.03,.08,.25]));a.angle=config.shiftingAngle;a.blackFloor=false;a.blackPoint=config.backgroundBlackLevel;
    }else{
      const cycle=window.ANIMATED_BACKGROUND_PRESETS[config.shiftingPreset];
      a.colors=cycle.colors;a.angle=cycle.angle;a.blackFloor=cycle.blackFloor;a.blackPoint=clamp((cycle.blackPoint||0)+config.backgroundBlackLevel,0,.85);
    }
    a.preset=config.shiftingPreset;a.style=config.shiftingStyle;a.speed=config.shiftingSpeed;a.strength=config.shiftingStrength;a.cycleLength=config.shiftingPeriod;
    a.rotation=config.backgroundRotation;a.exposure=config.backgroundExposure;a.blur=config.shiftingSoftness;
    if(config.backgroundMode==='shifting'){
      activeTint=a.colors[0].map((v,i)=>a.colors.reduce((sum,color)=>sum+color[i],0)/a.colors.length);lighting=activeTint;
    }
    s.mood=clamp(lighting.reduce((sum,v)=>sum+v,0)*2*config.backgroundExposure,0,1);
    // Color comes from the selected background, independently of its exposure.
    // Keep dark OLED palettes useful by normalizing hue instead of copying black.
    s.waveClear=config.waveFinish==='clear'?1:0;
    s.waveTintStrength=config.waveTint==='silver'?0:config.waveTintStrength;
    s.waveTintMode=config.waveTint;
    const waveColors={warm:[1,.68,.32],ice:[.27,.66,1],violet:[.64,.3,1],rose:[1,.3,.52]};
    const normalizeTint=color=>{const peak=Math.max(...color);return peak>.0001?color.map(v=>v/peak):[.72,.78,.85];};
    const backgroundTint=config.backgroundMode==='shifting'?activeTint:s.gradientStart.map((v,i)=>(v+s.gradientMiddle[i]+s.gradientEnd[i])/3);
    s.waveTintColor=config.waveTint==='palette'?normalizeTint(backgroundTint):config.waveTint==='custom'?parseColor(config.waveColor,[.25,.65,1]):waveColors[config.waveTint]||[1,1,1];
    s.wavePaletteAnimated=config.waveTint==='palette'&&config.backgroundMode==='shifting';
    window.waveStatus.waveAppearance={finish:config.waveFinish,tint:config.waveTint,strength:s.waveTintStrength,color:s.waveTintColor};
    const e=window.EFFECT_SETTINGS;
    for(const key of ['glowRadius','glowThreshold','blurQuality'])e[key]=config[key];
    for(const key of ['breatheEnabled','breatheMode','breathePeriod','breatheIntensity','breatheMinimum','breatheWidth','breatheSoftness','breatheRadius','breatheThreshold'])e[key]=config[key];
    e.breatheTintMode=config.breatheTint;
    e.breatheTint=config.breatheTint==='custom'?parseColor(config.breatheColor,[.3,.65,1]):config.breatheTint==='silver'?[.72,.84,1]:s.waveTintColor;
    const palettePeak=Math.max(...backgroundTint);
    e.breathePaletteColor=palettePeak>.0001?backgroundTint.map(v=>v/palettePeak):[.72,.78,.85];
    e.breathePaletteAnimated=config.backgroundMode==='shifting';
    window.waveStatus.breathingGlow={enabled:config.breatheEnabled,preset:config.breathePreset,mode:config.breatheMode,period:config.breathePeriod,intensity:config.breatheIntensity};
    e.glow=performance.glow;e.blur=performance.blur;e.antiAliasing=config.antiAliasing;
    if(config.glowTint==='custom')e.glowTint=parseColor(config.glowColor,[.7,.85,1]);
    else if(config.glowTint==='silver')e.glowTint=[.85,.91,1];
    else if(config.glowTint==='warm')e.glowTint=[1,.77,.5];
    else{const max=Math.max(...activeTint,.04);e.glowTint=activeTint.map(v=>.55+.45*v/max);}
    if(animatedBackground)animatedBackground.invalidate();
    const p=window.PARTICLE_SETTINGS,profile=window.PARTICLE_PRESETS[config.particlePreset];
    if(profile)Object.assign(p,profile);
    p.count=profile?Math.min(800,Math.round(profile.count*config.particleDensity*performance.particleScale)):0;
    p.opacity=config.sparkle;p.sizeScale=config.particleSize;p.speed=config.particleSpeed;
    if(config.particleTint==='custom')p.color=parseColor(config.particleColor,[.72,.84,1]);
    else if(config.particleTint==='silver')p.color=[.85,.91,1];
    else if(config.particleTint==='warm')p.color=[1,.77,.5];
    else{
      const tint=activeTint,max=Math.max(...tint,.04);
      p.color=tint.map(v=>.55+.45*v/max);
    }
    Object.assign(window.waveStatus,{wavePreset:config.wavePreset,animationPreset:config.animationPreset,backgroundMode:config.backgroundMode,backgroundPreset:config.backgroundPreset,shiftingPreset:config.shiftingPreset,shiftingStyle:config.shiftingStyle,performancePreset:performance.id,performance:performance,resolution:performance.resolution,particlePreset:config.particlePreset,particleCount:p.count,advancedControls:config.advancedControls});
    window.waveStatus.gradient={start:s.gradientStart,middle:s.gradientMiddle,end:s.gradientEnd,angle:s.gradientAngle,twoTone:s.twoTone,blackFloor:s.blackFloor,blackPoint:s.backgroundBlackPoint,exposure:s.backgroundExposure};
  }
  // One wave across several displays. Only a Wallpaper Engine Stretch group
  // hands this page the whole combined desktop; a single display or a Clone
  // group has one monitor's shape and keeps the ordinary single-screen drawing.
  // World units are the main display's width and height, so the main display
  // looks exactly as before and neighbours continue the same surface at the
  // same physical size, whatever their resolution, density or orientation.
  function computeSpan(canvasW,canvasH){
    return window.XMBDisplays.resolve({width:canvasW,height:canvasH,cssWidth:innerWidth,cssHeight:innerHeight,layout:window.XMB_DISPLAY_LAYOUT,mode:config.spanDisplays,gap:config.spanGap,offset:config.spanVerticalOffset});
  }
  const displayTransition=window.createDisplayTransition();
  let displayKey='',previousViewport=null,displayResizeQueued=false;
  function currentDisplayKey(){return JSON.stringify([innerWidth,innerHeight,devicePixelRatio,performance.resolution,config.spanDisplays,config.spanGap,config.spanVerticalOffset,window.XMB_DISPLAY_LAYOUT?.monitors]);}
  function updateDisplay(reason){
    displayResizeQueued=false;
    const key=currentDisplayKey();if(key===displayKey)return;
    // Draw immediately before copying: WebGL canvases need not retain pixels
    // after presentation. Both canvas resizes and the replacement draw finish
    // in this one task, so the compositor never receives an empty framebuffer.
    if(spline&&background&&previousViewport){
      if(config.backgroundMode==='static'){background.invalidate();background.render();}
      draw();displayTransition.capture({width:previousViewport.width,height:previousViewport.height,background:backgroundCanvas,wave:canvas,backgroundBounds:previousViewport.backgroundBounds,waveBounds:previousViewport.waveBounds});
    }
    resize();if(spline){draw();displayTransition.reveal();}
    window.waveStatus.displayTransition={...displayTransition.stats(),reason};
    window.dispatchEvent(new CustomEvent('xmb-viewport'));
  }
  function queueDisplayResize(){
    if(displayResizeQueued)return;displayResizeQueued=true;
    requestAnimationFrame(()=>{displayResizeQueued=false;updateDisplay('viewport resize');});
  }
  function resize(){
    const dpr=(window.devicePixelRatio||1)*performance.resolution;
    const width=Math.max(1,Math.round(innerWidth*dpr)),fullHeight=Math.max(1,Math.round(innerHeight*dpr));
    const span=computeSpan(width,fullHeight);window.XMB_SPAN=span;window.waveStatus.span={active:span.active,mode:span.mode,reason:span.reason,displays:span.displays,views:span.views,singleView:span.singleView};
    // Conservative geometry/effect bounds exclude transparent pixels while
    // retaining the existing pixel density and all animation callbacks. A span
    // places the wave at a different height on each display, so it renders the full frame.
    const bounds=span.active?[0,1]:window.waveRenderBounds({...config,glow:performance.glow,blur:performance.blur,particlePreset:performance.particlesAllowed?config.particlePreset:'off'},innerHeight,dpr);
    window.SPLINE_SETTINGS.clipBounds=[0,1];
    const height=Math.max(1,Math.round(fullHeight*(bounds[1]-bounds[0])));
    waveViewportHeight=fullHeight;waveViewportBottom=Math.round(fullHeight*(1-bounds[1]));
    const backgroundBounds=config.backgroundMode==='shifting'?window.backgroundRenderBounds(window.BACKGROUND_MOTION_SETTINGS,innerHeight,dpr):[0,1];
    const backgroundHeight=Math.max(1,Math.round(fullHeight*(backgroundBounds[1]-backgroundBounds[0])));
    window.BACKGROUND_MOTION_SETTINGS.clipBounds=backgroundBounds;window.BACKGROUND_MOTION_SETTINGS.fullHeight=fullHeight;
    backgroundCanvas.style.top=(innerHeight*backgroundBounds[0])+'px';backgroundCanvas.style.height=(innerHeight*(backgroundBounds[1]-backgroundBounds[0]))+'px';
    document.body.style.background=config.backgroundMode==='shifting'&&window.BACKGROUND_MOTION_SETTINGS.blackFloor?'#000':'#03060c';
    canvas.style.top=(innerHeight*bounds[0])+'px';canvas.style.height=(innerHeight*(bounds[1]-bounds[0]))+'px';
    if(canvas.width!==width)canvas.width=width;if(canvas.height!==height)canvas.height=height;
    if(backgroundCanvas.width!==width)backgroundCanvas.width=width;if(backgroundCanvas.height!==backgroundHeight)backgroundCanvas.height=backgroundHeight;
    window.waveStatus.nativeSize=[Math.round(innerWidth*(window.devicePixelRatio||1)),Math.round(innerHeight*(window.devicePixelRatio||1))];window.waveStatus.fullRenderSize=[width,fullHeight];window.waveStatus.nativeResolution=performance.resolution===1;gl.viewport(0,0,width,height);window.waveStatus.renderSize=[width,height];window.waveStatus.renderBounds=bounds;window.waveStatus.backgroundRenderSize=[width,backgroundHeight];window.waveStatus.backgroundRenderBounds=backgroundBounds;
    displayKey=currentDisplayKey();previousViewport={width:innerWidth,height:innerHeight,backgroundBounds:[...backgroundBounds],waveBounds:[...bounds]};
    if(effects)effects.resize();
    if(config.backgroundMode==='shifting'){if(animatedBackground)animatedBackground.invalidate();}
    else if(background){if(renderedBackgroundMode!=="static")background.invalidate();background.render();renderedBackgroundMode="static";}
  }
  updateSettings();
  try{resize();background=window.createBackgroundLayer(backgroundGL,backgroundCanvas);background.render();spline=window.createSplineLayer(gl,canvas);effects=window.createEffectsLayer(gl,canvas);window.waveStatus.effects=effects.stats;window.waveStatus.effectsCapabilities=effects.capabilities;}
  catch(e){fail(e.message);return;}
  function draw(){
    if(config.backgroundMode==='shifting'){
      if(!animatedBackground)animatedBackground=window.createAnimatedBackgroundLayer(backgroundGL,backgroundCanvas);
      animatedBackground.render(backgroundTime);renderedBackgroundMode='shifting';
    }
    window.EFFECT_SETTINGS.breatheBackgroundTime=backgroundTime;
    const target=effects.begin(effectTime);
    // Retain the full-frame vertex transform and pixel grid while rasterizing
    // only the visible band into the smaller attachment.
    if(waveViewportHeight!==canvas.height||waveViewportBottom)gl.viewport(0,-waveViewportBottom,canvas.width,waveViewportHeight);
    spline.render(waveTime,target,backgroundTime);
    if(window.PARTICLE_SETTINGS.count>0){
      if(!particles)particles=window.createParticlesLayer(gl,canvas);
      particles.render(particleTime+137);
    }
    effects.end();window.waveStatus.frames++;
  }
  function frame(now){
    frameId=0;if(paused||hidden)return;if(!last)last=now;
    const rawElapsed=now-last;
    const elapsed=rawElapsed>250?0:(displayInterval?Math.min(rawElapsed,displayInterval*2):rawElapsed);
    last=now;
    // Motion phase is independent of presentation cadence. Slow waves still
    // receive every available callback, including in 120 FPS mode.
    const seconds=elapsed/1000;
    const response=window.desktopXmbResponse.sample(now,seconds);
    window.waveStatus.desktopXmb=response;
    window.SPLINE_SETTINGS.brightness=config.brightness*response.light;
    window.SPLINE_SETTINGS.highlightIntensity=config.highlightIntensity*response.light;
    waveTime+=seconds*response.speed*config.speed*(config.animationDirection==='reverse'?-1:1);particleTime+=seconds;backgroundTime+=seconds*config.shiftingSpeed;effectTime+=seconds;
    const interval=1000/window.waveStatus.targetFps;
    if(elapsed>0&&(!displayInterval||rawElapsed<displayInterval*1.8))displayInterval=displayInterval?displayInterval*.9+rawElapsed*.1:rawElapsed;
    const displayLimited=displayInterval>=interval*.85;
    if(displayLimited||!nextFrame||now>=nextFrame-Math.min(2,interval*.2)){
      if(displayLimited||!nextFrame)nextFrame=now;nextFrame+=interval;
      if(nextFrame<now-interval)nextFrame=now+interval;
      try{
        if(config.diagnosticsEnabled){
          diagnostics.beginFrame(now,window.waveStatus.targetFps);
          const started=window.performance.now();draw();
          diagnostics.recordFrame(now,window.performance.now()-started);
        }else draw();
      }catch(e){fail(e.message);return;}
    }
    frameId=requestAnimationFrame(frame);
  }
  function schedule(){
    if(frameId)cancelAnimationFrame(frameId);frameId=0;last=0;nextFrame=0;displayInterval=0;
    window.waveStatus.paused=paused||hidden;diagnostics.reset();if(!paused&&!hidden)frameId=requestAnimationFrame(frame);
  }
  window.wallpaperPropertyListener={
    applyUserProperties(props,source="host"){
      const incoming=Object.fromEntries(Object.entries(props).map(([key,p])=>[key,p.value]));
      const breathing=window.resolveBreathingChange(config,incoming);
      if(breathing!==incoming)props=Object.fromEntries(Object.entries(breathing).map(([key,value])=>[key,{value}]));
      // Manual edits in either settings surface leave a limiting preset while
      // carrying its visible effect values forward without a jump in look.
      if(source==='host'&&!props.performancePreset&&performance.id!=='custom'&&
        ['fpsMode','resolution','glow','blur'].some(key=>props[key]&&props[key].value!==config[key])){
        const manual={performancePreset:'custom',fpsMode:String(performance.fps),resolution:performance.resolution,
          glow:performance.glow,blur:performance.blur,particleDensity:Math.max(.2,config.particleDensity*performance.particleScale)};
        props={...Object.fromEntries(Object.entries(manual).map(([key,value])=>[key,{value}])),...props};
      }
      let changed=false,renderChanged=false;
      for(const key of Object.keys(config))if(props[key]){
        const value=props[key].value;let next=config[key];
        if(typeof next==='number'){const n=Number(value);if(Number.isFinite(n))next=n;}
        else if(typeof next==='boolean'){if(typeof value==='boolean')next=value;}
        else if(typeof value==='string')next=value;
        if(key==='advancedControls'&&!['closed','wave','motion','particles','background','effects','all'].includes(next))next='closed';
        if(next!==config[key]){config[key]=next;changed=true;if(!['diagnosticsEnabled','advancedControls','settingsPanel','panelTransparency','panelWidth','panelHeight'].includes(key))renderChanged=true;}
      }
      // Older copies exposed a raw particle-count slider. Retain enabled legacy
      // choices as subtle dust until a new preset is explicitly selected.
      if(props.particles&&!props.particlePreset){
        changed=true;renderChanged=true;
        const count=Number(props.particles.value);config.particlePreset=count>0?'dust':'off';
        if(count>0)config.particleDensity=clamp(count/window.PARTICLE_PRESETS.dust.count,.2,2);
      }
      window.dispatchEvent(new CustomEvent("xmb-settings",{detail:{props,source,config:{...config}}}));
      if(!changed)return;
      diagnostics.setEnabled(config.diagnosticsEnabled);
      if(renderChanged){updateSettings();if(['spanDisplays','spanGap','spanVerticalOffset'].some(key=>key in props))updateDisplay('display settings');else{resize();draw();}}
      else window.waveStatus.advancedControls=config.advancedControls;
    },
    applyGeneralProperties(props){if(Number.isFinite(Number(props.fps))){hostFps=clamp(Number(props.fps),1,120);updateFrameRate();}},
    setPaused(value){const next=Boolean(value);if(next===paused)return;paused=next;schedule();}
  };
  document.addEventListener('visibilitychange',()=>{hidden=document.hidden;if(!hidden)updateDisplay('visible');schedule();});
  window.addEventListener('resize',queueDisplayResize);
  window.addEventListener('xmb-display-layout',()=>updateDisplay('live display topology'));
  window.addEventListener('pagehide',()=>displayTransition.dispose());
  window.XMBDisplayRuntime={update:()=>updateDisplay('requested'),stats:()=>({...displayTransition.stats(),clocks:{waveTime,backgroundTime,effectTime},mapping:window.waveStatus.span})};
  for(const target of [canvas,backgroundCanvas]){
    target.addEventListener('webglcontextlost',e=>{e.preventDefault();paused=true;schedule();fail('Graphics context lost. Reapply the wallpaper.');});
    target.addEventListener('webglcontextrestored',()=>location.reload());
  }
  window.XMBSettings={get:()=>({...config}),set:(values,source="panel")=>window.wallpaperPropertyListener.applyUserProperties(Object.fromEntries(Object.entries(values).map(([k,value])=>[k,{value}])),source)};
  diagnostics.setEnabled(config.diagnosticsEnabled);draw();window.waveStatus.ready=true;schedule();
})();
