'use strict';
// Pure viewport mapping: monitor topology and wave composition are independent.
// The authored wave uses a 16:9 camera. Narrow displays crop that camera instead
// of squeezing its full horizontal extent into a portrait viewport.
(function(root){
 function singleView(width,height){const xw=width/height/(16/9);return {x0:(1-xw)/2,xw};}
 function resolve({width,height,cssWidth=width,cssHeight=height,layout,mode='auto',gap=0,offset=0}){
  const state={active:false,mode:'single',views:null,primaryCss:null,displays:[],singleView:singleView(width,height),reason:''};
  const list=(Array.isArray(layout?.monitors)?layout.monitors:[]).filter(m=>Array.isArray(m.rect)&&m.rect.length===4&&m.rect.every(Number.isFinite)&&m.rect[2]>0&&m.rect[3]>0).map(m=>({...m,mm:Array.isArray(m.mm)&&m.mm.every(v=>Number.isFinite(v)&&v>0)?m.mm:[m.rect[2]*.25,m.rect[3]*.25]}));
  state.displays=list.map(m=>m.name+' '+m.rect[2]+'×'+m.rect[3]);
  if(list.length<2){state.reason=list.length?'Single display detected. Wave proportions are preserved; portrait screens crop the view.':'Waiting for display layout. Wave proportions are preserved for this viewport.';return state;}
  const left=Math.min(...list.map(m=>m.rect[0])),top=Math.min(...list.map(m=>m.rect[1]));
  const bw=Math.max(...list.map(m=>m.rect[0]+m.rect[2]))-left,bh=Math.max(...list.map(m=>m.rect[1]+m.rect[3]))-top;
  if(Math.abs(width/height-bw/bh)>.02*(bw/bh)){
   state.reason='This wallpaper is on one display. Its wave uses an aspect-correct view instead of the entire desktop wave.';return state;
  }
  const primary=list.find(m=>m.primary)||list[0],pr=primary.rect;
  // A portrait primary still uses the authored landscape camera as reference.
  const H0=primary.mm[1],W0=H0*(16/9),bezel=gap*10,verticalOffset=offset*10;
  const place=new Map([[primary,{x:(W0-primary.mm[0])/2,y:0}]]),origin=place.get(primary).x;
  const vertical=m=>(m.rect[1]-pr[1])*m.mm[1]/m.rect[3]+verticalOffset;
  let edge=origin+primary.mm[0];
  for(const m of list.filter(m=>m!==primary&&m.rect[0]>=pr[0]+pr[2]).sort((a,b)=>a.rect[0]-b.rect[0])){place.set(m,{x:edge+bezel,y:vertical(m)});edge+=bezel+m.mm[0];}
  edge=origin;
  for(const m of list.filter(m=>m!==primary&&m.rect[0]+m.rect[2]<=pr[0]).sort((a,b)=>b.rect[0]-a.rect[0])){edge-=bezel+m.mm[0];place.set(m,{x:edge,y:vertical(m)});}
  for(const m of list)if(!place.has(m)){const below=m.rect[1]>=pr[1]+pr[3];place.set(m,{x:origin+(m.rect[0]-pr[0])*m.mm[0]/m.rect[2],y:below?H0+bezel:-(m.mm[1]+bezel)});}
  const sx=width/bw,sy=height/bh,independent=mode==='off';
  state.views=list.map(m=>{const p=place.get(m),vx=Math.round((m.rect[0]-left)*sx),vy=Math.round((m.rect[1]-top)*sy),vw=Math.round(m.rect[2]*sx),vh=Math.round(m.rect[3]*sy),camera=singleView(m.rect[2],m.rect[3]);return {name:m.name,viewport:[vx,height-vy-vh,vw,vh],x0:independent?camera.x0:p.x/W0,xw:independent?camera.xw:m.mm[0]/W0,y0:independent?0:p.y/H0,yh:independent?1:m.mm[1]/H0};});
  state.primaryCss={left:(pr[0]-left)*cssWidth/bw,top:(pr[1]-top)*cssHeight/bh,width:pr[2]*cssWidth/bw,height:pr[3]*cssHeight/bh};
  state.active=true;state.mode=independent?'independent':'span';
  state.reason=independent?'Each display has its own aspect-correct wave.':'One continuous wave spans '+list.length+' displays: '+list.map(m=>m.name).join(' + ')+'.';return state;
 }
 if(typeof module==='object'&&module.exports){module.exports={resolve,singleView};return;}
 let signature='';
 root.XMBDisplays={resolve,singleView,accept(layout){
  if(!layout||!Array.isArray(layout.monitors)||!layout.monitors.length||layout.monitors.length>16)return false;
  if(layout.monitors.some(m=>!Array.isArray(m.rect)||m.rect.length!==4||!m.rect.every(Number.isFinite)||m.rect[2]<=0||m.rect[3]<=0))return false;
  const next=JSON.stringify(layout.monitors);if(next===signature)return false;
  signature=next;root.XMB_DISPLAY_LAYOUT=layout;root.dispatchEvent(new CustomEvent('xmb-display-layout'));return true;
 }};
})(typeof window==='object'?window:globalThis);
