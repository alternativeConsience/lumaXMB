/* DesktopXMB's temporary response layer. Saved wallpaper controls stay intact. */
(function(root){
 'use strict';
 function createResponse(){
  let state=null,received=-Infinity,speed=1,light=1;
  return {
   accept(value,now){
    if(!value||value.version!==1||!['Full','Orbital','ActiveOrbital','Application','Hidden','SystemUi'].includes(value.mode)||!Number.isFinite(value.activation))return false;
    state=value;received=now;return true;
   },
   sample(now,dt){
    const connected=!!state&&now-received<2000&&state.enabled===true;
    const reactive=connected&&!state.reducedMotion;
    let targetSpeed=1,targetLight=1;
    if(reactive){
     const a=Math.max(0,Math.min(1,state.activation));
     if(state.mode==='Orbital'||state.mode==='ActiveOrbital'){targetSpeed=.65+.95*a;targetLight=.96+.18*a;}
     else if(state.mode==='Full'){targetSpeed=1.12;targetLight=1.08;}
    }
    // Integrate phase in wallpaper.js; changing speed never jumps the wave.
    const k=1-Math.exp(-Math.max(0,Math.min(.1,dt))*4.5);
    speed+=(targetSpeed-speed)*k;light+=(targetLight-light)*k;
    return {connected,mode:connected?state.mode:'Disconnected',speed,light};
   }
  };
 }
 if(typeof module==='object'&&module.exports){module.exports={createResponse};return;}
 const response=createResponse();root.desktopXmbResponse=response;
 let stopped=false;
 async function poll(){
  if(stopped)return;
  let ok=false;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),700);
  try{const r=await fetch('http://127.0.0.1:18765/state',{cache:'no-store',signal:controller.signal});if(r.ok)ok=response.accept(await r.json(),root.performance.now());}catch(_){}
  finally{clearTimeout(timer);if(!stopped)setTimeout(poll,ok?100:1000);}
 }
 root.addEventListener('pagehide',()=>{stopped=true;});poll();
})(typeof window==='object'?window:globalThis);
