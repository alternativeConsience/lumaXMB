'use strict';
// Continuous folded surface with analytic normals, native framebuffer MSAA,
// and dithered gradients. The default path retains direct native MSAA output;
// optional post effects may supply a framebuffer without changing the mesh.
(() => {
  function shader(gl,type,source) {
    const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);
    if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s));
    return s;
  }
  window.createBackgroundLayer=function(gl,canvas) {
    const program=gl.createProgram();
    const vertex=shader(gl,gl.VERTEX_SHADER,`#version 300 es
      in vec2 position; out vec2 uv;
      void main(){uv=position*.5+.5;gl_Position=vec4(position,0.,1.);}`);
    const fragment=shader(gl,gl.FRAGMENT_SHADER,`#version 300 es
      precision highp float;
      in vec2 uv; out vec4 frag;
      uniform vec3 gradientStart, gradientMiddle, gradientEnd;
      uniform float gradientAngle, twoTone, backgroundExposure, backgroundBlackPoint, blackFloor;
      // This viewport's window into the shared world (origin.xy, size.zw), in
      // main-display units. A single display is the default (0,0,1,1).
      uniform vec4 worldView;
      void main(){
        vec2 p=worldView.xy+vec2(uv.x,1.-uv.y)*worldView.zw;
        vec2 direction=vec2(cos(gradientAngle),sin(gradientAngle));
        float extent=abs(direction.x)+abs(direction.y);
        float g=clamp(dot(p-.5,direction)/extent+.5,0.,1.);
        if(backgroundBlackPoint>0.)g=max(0.,(g-backgroundBlackPoint)/(1.-backgroundBlackPoint));
        // Smooth joins at all three stops, with subpixel dithering below.
        vec3 color=twoTone>.5 ? mix(gradientStart,gradientEnd,smoothstep(0.,1.,g)) : g<.5 ? mix(gradientStart,gradientMiddle,smoothstep(0.,.5,g))
          : mix(gradientMiddle,gradientEnd,smoothstep(.5,1.,g));
        float dither=fract(52.9829189*fract(dot(gl_FragCoord.xy,vec2(.06711056,.00583715))));
        color*=backgroundExposure;
        // A true-black plateau stays exactly black: dithering must never
        // introduce lit pixels into the OLED preset's unlit region.
        float noise=(blackFloor>.5 && max(color.r,max(color.g,color.b))<=0.) ? 0. : (dither-.5)/255.;
        frag=vec4(clamp(color+noise,0.,1.),1.);
      }`);
    gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
    gl.deleteShader(vertex);gl.deleteShader(fragment);
    const vao=gl.createVertexArray();gl.bindVertexArray(vao);
    const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
    const pos=gl.getAttribLocation(program,'position');gl.enableVertexAttribArray(pos);gl.vertexAttribPointer(pos,2,gl.FLOAT,false,0,0);
    const u={};for(const name of ['gradientStart','gradientMiddle','gradientEnd','gradientAngle','twoTone','backgroundExposure','backgroundBlackPoint','blackFloor','worldView'])u[name]=gl.getUniformLocation(program,name);

    let previous='';
    return {render(){
      const s=window.SPLINE_SETTINGS,span=window.XMB_SPAN&&window.XMB_SPAN.active?window.XMB_SPAN:null;
      const key=JSON.stringify([canvas.width,canvas.height,s.gradientStart,s.gradientMiddle,s.gradientEnd,s.gradientAngle,s.twoTone,s.backgroundExposure,s.backgroundBlackPoint,s.blackFloor,span&&span.views]);
      if(key===previous) return;
      previous=key;
      gl.viewport(0,0,canvas.width,canvas.height);
      // Areas of a stretched canvas that no display shows stay black.
      if(span){gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT);}
      gl.useProgram(program);gl.bindVertexArray(vao);
      gl.uniform3fv(u.gradientStart,s.gradientStart);
      gl.uniform3fv(u.gradientMiddle,s.gradientMiddle);
      gl.uniform3fv(u.gradientEnd,s.gradientEnd);
      gl.uniform1f(u.twoTone,s.twoTone?1:0);
      gl.uniform1f(u.gradientAngle,s.gradientAngle*Math.PI/180);
      gl.uniform1f(u.backgroundExposure,s.backgroundExposure??1);
      gl.uniform1f(u.backgroundBlackPoint,s.backgroundBlackPoint??0);
      gl.uniform1f(u.blackFloor,s.blackFloor?1:0);
      // One draw per display when spanning: each viewport shows its own slice
      // of the same world gradient, so the colour continues across screens.
      for(const v of span?span.views:[null]){
        if(v){gl.viewport(v.viewport[0],v.viewport[1],v.viewport[2],v.viewport[3]);if(span.mode==='independent')gl.uniform4f(u.worldView,0,0,1,1);else gl.uniform4f(u.worldView,v.x0,v.y0,v.xw,v.yh);}
        else gl.uniform4f(u.worldView,0,0,1,1);
        gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
      }
      gl.viewport(0,0,canvas.width,canvas.height);
    },invalidate(){previous='';}};
  };
  window.createSplineLayer=function(gl,canvas) {
    const waveProgram=gl.createProgram();
    const waveVS=shader(gl,gl.VERTEX_SHADER,`#version 300 es
      precision highp float;
      in vec2 grid;
      uniform float time;
      uniform vec4 waveShape;
      // This viewport's window into the shared world, in main-display units:
      // worldX = (left, width), worldY = (top, height). One display: (0,1) and the clip band.
      uniform vec2 worldX, worldY;
      uniform float sony;
      uniform float waveMode, motionMode, waveAmplitude, waveFrequency, waveDetail, wavePosition, animationStrength;
      uniform vec4 motionParams;
      out vec3 normal;
      out vec2 sheet;
      // Height and its two spatial derivatives travel together. Normals are
      // always derived from the actual displacement, including animation.
      vec3 swell(float x,float z,float amplitude,float kx,float kz,float phase){
        float a=kx*x+kz*z+phase;
        return vec3(amplitude*sin(a),amplitude*kx*cos(a),amplitude*kz*cos(a));
      }
      void main(){
        // The mesh spans this viewport; the wave is evaluated at the matching
        // world position, so neighbouring displays continue one surface.
        float rawX=worldX.x+grid.x*worldX.y,z=grid.y,t=time*waveShape.w;
        float spanX=rawX;
        if(waveFrequency!=1.)rawX=(rawX-.5)*waveFrequency+.5;
        if(waveDetail!=1.)z*=waveDetail;
        float x=rawX,y,dx,dz;
        if(waveMode>.5){
          vec3 h=vec3(.018*z,0.,.018);
          if(waveMode<1.5){
            // Satin: one generous swell with two long, shallow seams.
            h+=swell(x,z,.073,3.8,1.4,-t*.24)+swell(x,z,.030,7.6,4.1,t*.19)+swell(x,z,.010,14.8,7.2,-t*.31);
          }else if(waveMode<2.5){
            // Crystal: compressed diagonal catches between broad facets.
            h+=swell(x,z,.052,6.2,5.3,-t*.33)+swell(x,z,.021,18.6,15.9,-t*.99)+swell(x,z,.026,-3.6,3.1,t*.24);
          }else if(waveMode<3.5){
            // Horizon: wide, almost parallel glass shelves.
            h+=swell(x,z,.031,2.6,.8,-t*.18)+swell(x,z,.020,5.1,3.5,t*.21)+swell(x,z,.006,9.8,7.0,-t*.27);
          }else if(waveMode<4.5){
            // Pleats: regular fine folds interrupted by a slow broad bow.
            h+=swell(x,z,.025,2.1,12.8,-t*.30)+swell(x,z,.011,-3.2,25.6,t*.22)+swell(x,z,.052,3.8,1.1,-t*.15);
          }else if(waveMode<5.5){
            // Dunes: the envelope changes broad mounds without sharp seams.
            vec3 base=swell(x,z,.080,5.2,2.0,-t*.20);
            float e=.72+.28*cos(x*3.3+t*.13);
            h+=vec3(base.x*e,base.y*e-base.x*.924*sin(x*3.3+t*.13),base.z*e);
            h+=swell(x,z,.028,-7.1,4.6,t*.16)+swell(x,z,.009,12.4,6.8,-t*.28);
          }else if(waveMode<6.5){
            // Cascade: fast diagonal creases slant consistently across x.
            h+=swell(x,z,.056,8.3,5.8,-t*.42)+swell(x,z,.026,13.7,9.1,-t*.29)+swell(x,z,.039,2.8,.5,t*.12);
          }else if(waveMode<7.5){
            // Helix: the front and back of the sheet twist in opposite ways.
            float a=x*7.3-t*.25;
            h+=vec3(.072*z*sin(a),.5256*z*cos(a),.072*sin(a));
            h+=swell(x,z,.047,3.7,1.0,t*.15)+swell(x,z,.019,-6.4,6.5,-t*.31);
          }else if(waveMode<8.5){
            // Aurora: a slowly curved veil with a depth-dependent fullness.
            float a=x*3.2-t*.18,b=z*2.6+t*.14;
            h+=vec3(.085*sin(a)*(.65+.35*cos(b)),.272*cos(a)*(.65+.35*cos(b)),-.07735*sin(a)*sin(b));
            h+=swell(x,z,.030,4.1,8.2,-t*.27)+swell(x,z,.012,-9.2,14.3,t*.21);
          }else if(waveMode<9.5){
            // Crosscurrent: two diagonal directions interleave independently.
            h+=swell(x,z,.059,7.2,4.6,-t*.29)+swell(x,z,.049,-6.0,5.7,t*.34)+swell(x,z,.018,2.4,10.5,-t*.17);
          }else if(waveMode<10.5){
            // Swell: deep rolling crests with sparse bright ridges.
            h+=swell(x,z,.092,4.9,2.7,-t*.23)+swell(x,z,.031,9.8,5.4,-t*.46)+swell(x,z,.017,-3.1,8.9,t*.19);
          }else if(waveMode<11.5){
            // Interference: crossed standing folds, never a tiled image.
            float a=x*8.2-t*.24,b=z*7.6+t*.19;
            h+=vec3(.056*sin(a)*sin(b),.4592*cos(a)*sin(b),.4256*sin(a)*cos(b));
            h+=swell(x,z,.043,3.2,1.1,-t*.16)+swell(x,z,.015,15.3,12.1,t*.28);
          }else{
            // Prism: a rounded three-harmonic facet profile with a long bow.
            h+=swell(x,z,.066,5.7,4.3,-t*.25)+swell(x,z,-.013,17.1,12.9,-t*.75)+swell(x,z,.004,28.5,21.5,-t*1.25);
            h+=swell(x,z,.031,2.5,.8,t*.11);
          }
          y=.56+h.x*waveShape.y;dx=h.y*waveShape.y;dz=h.z*waveShape.y;
        }else if(sony>.5){
          // A broad, gently tilted sheet. Long diagonal creases pass through it;
          // no horizontal coordinate warp or repeating closed ribbon loops.
          x=rawX; t=time*.85;
          float q=x*4.2-t*.29;
          float r=x*2.7+t*.22;
          float a=z*3.1+x*3.8-t*.53;
          float b=z*8.1-x*4.5+t*.37;
          float c=z*11.7+x*2.6-t*.28;
          float fullness=.80+.20*sin(x*3.5+t*.19);
          float fullnessDx=.70*cos(x*3.5+t*.19);
          float body=.068*z+.042*sin(a)+.026*sin(b)+.010*sin(c);
          float bodyDx=.1596*cos(a)-.117*cos(b)+.026*cos(c);
          float bodyDz=.068+.1302*cos(a)+.2106*cos(b)+.117*cos(c);
          y=.563+.050*sin(q)+.023*sin(r)+body*fullness;
          dx=.21*cos(q)+.0621*cos(r)+bodyDx*fullness+body*fullnessDx;
          dz=bodyDz*fullness;
        } else {
        // Nonuniform horizontal spacing makes the creases bunch and stretch.
        x=rawX+waveShape.x*(.065*sin(rawX*7.3-t*.21)+.024*sin(rawX*15.7+t*.16));
        float warpDx=1.+waveShape.x*(.4745*cos(rawX*7.3-t*.21)+.3768*cos(rawX*15.7+t*.16));
        float a=z*4.7+x*2.9-t*.24;
        float b=z*8.3-x*4.1+t*.28;
        float c=z*11.1+x*5.0-t*.17;
        float d=z*13.4+x*7.8-t*.45;
        float e=x*2.2+t*.12;
        float bend=x*9.5+z*2.-t*.37;
        float amp=.5+.5*sin(e);
        y=.585+.068*sin(x*4.5-t*.32+.7)+.023*sin(x*2.3+t*.18)
          + .038*z+.054*sin(a)+.027*sin(b)+.012*cos(c)+.006*sin(d)*amp+.015*sin(bend);
        dx=.306*cos(x*4.5-t*.32+.7)+.0529*cos(x*2.3+t*.18)
          +.1566*cos(a)-.1107*cos(b)-.060*sin(c)
          +.006*(7.8*cos(d)*amp+1.1*sin(d)*cos(e))+.1425*cos(bend);
        dz=.038+.2538*cos(a)+.2241*cos(b)-.1332*sin(c)
          +.0804*cos(d)*amp+.030*cos(bend);
        // Travelling pockets change the thickness and twist independently of the swell.
        float phase=x*12.3-t*.31;
        float envelope=1.+waveShape.z*(-.32+.32*sin(phase));
        float envelopeDx=waveShape.z*3.936*cos(phase);
        float fold=z*6.4+x*8.1+t*.19;
        float detail=.020*sin(fold)*sin(x*5.3-t*.13);
        float detailDx=.162*cos(fold)*sin(x*5.3-t*.13)+.106*sin(fold)*cos(x*5.3-t*.13);
        float detailDz=.128*cos(fold)*sin(x*5.3-t*.13);
        dx=(dx*envelope+(y-.585)*envelopeDx+detailDx)*warpDx;
        dz=dz*envelope+detailDz;
        y=.585+((y-.585)*envelope+detail)*waveShape.y;
        dx*=waveShape.y; dz*=waveShape.y;
        }
        if(motionMode>.5 && animationStrength>0.){
          float motionX=rawX;
          float a=motionParams.x*animationStrength,k=motionParams.y,r=time*motionParams.z,d=motionParams.w;
          vec3 m=vec3(0.);
          if(motionMode<1.5){
            m=vec3(a*(sin(r)+d*z*cos(r)),0.,a*d*cos(r));
          }else if(motionMode<2.5){
            m=vec3(a*sin(k*motionX)*sin(r)+a*d*z*cos(r),a*k*cos(k*motionX)*sin(r),a*d*cos(r));
          }else if(motionMode<3.5){
            m=swell(motionX,z,a,k,d,-r)+swell(motionX,z,a*.7,-k*.83,d*.61,r*1.17);
          }else if(motionMode<4.5){
            float scale=1.+a*sin(r);
            float pivot=sony>.5?.563:waveMode>.5?.56:.585;
            y=pivot+(y-pivot)*scale;dx*=scale;dz*=scale;
          }else if(motionMode<5.5){
            float p=k*motionX+d*z-r;
            m=vec3(a*(z*cos(p)+sin(p)),a*k*(-z*sin(p)+cos(p)),a*(cos(p)+d*(-z*sin(p)+cos(p))));
          }else if(motionMode<6.5){
            m=swell(motionX,z,a,k,d,-r)+swell(motionX,z,a*.35,-k*.57,d*1.4,r*.71);
          }else if(motionMode<7.5){
            float p=k*motionX-r,q=d*z+r*.37;
            m=vec3(a*sin(p)*cos(q),a*k*cos(p)*cos(q),-a*d*sin(p)*sin(q));
          }else if(motionMode<8.5){
            float kx=k*cos(r),kz=d*sin(r);
            m=swell(motionX,z,a,kx,kz,-r*.6)+swell(motionX,z,a*.45,-kz,kx,r*.4);
          }else if(motionMode<9.5){
            float p=k*motionX-r,c=1.-cos(p),e=exp(-6.*c*c),q=.85+.15*cos(z*3.14159265);
            m=vec3(a*e*q,-12.*a*k*c*sin(p)*e*q,-.47123890*a*e*sin(z*3.14159265));
          }else if(motionMode<10.5){
            m=swell(motionX,z,a,k,d,-r)+swell(motionX,z,a*.45,k*1.8,d*1.5,-r*1.4);
          }else{
            m=vec3(a*z*sin(k*motionX)*sin(r),a*z*k*cos(k*motionX)*sin(r),a*sin(k*motionX)*sin(r));
          }
          y+=m.x;dx+=m.y;dz+=m.z;
        }
        if(waveAmplitude!=1.){
          float pivot=sony>.5?.563:waveMode>.5?.56:.585;
          y=pivot+(y-pivot)*waveAmplitude;dx*=waveAmplitude;dz*=waveAmplitude;
        }
        if(waveFrequency!=1.)dx*=waveFrequency;
        if(waveDetail!=1.)dz*=waveDetail;
        if(wavePosition!=0.)y+=wavePosition;
        normal=normalize(vec3(-dx*.5,1.,-dz*1.1));
        // World x keeps the highlight drift continuous across displays.
        sheet=vec2(spanX,grid.y);
        gl_Position=vec4(grid.x*2.-1.,1.-2.*(y-worldY.x)/worldY.y,0.,1.);
      }`);
    const waveFS=shader(gl,gl.FRAGMENT_SHADER,`#version 300 es
      precision highp float;
      in vec3 normal;
      in vec2 sheet;
      out vec4 frag;
      uniform float edgeSoftness,highlightSoftness,highlightIntensity;
      uniform float time, brightness, mood, sony, gloss, glassOpacity, highlightWidth;
      uniform float waveIridescence, waveStrands, waveClear, waveTintStrength;
      uniform vec3 waveTintColor;
      // Signed highlight distances must be squared explicitly: GLSL pow is
      // undefined for a negative base, even with an integer exponent.
      float square(float value){return value*value;}
      void main(){
        vec3 n=normalize(normal);
        float facing=clamp(abs(n.z),0.,1.);
        float fresnel=.04+.96*pow(1.-facing,5.);
        vec3 reflection=reflect(vec3(0.,0.,-1.),n);
        // Reflected soft light sources: narrow catches over a transparent body.
        // The highlights move as the actual surface normal changes.
        float axis=reflection.y-.24*reflection.x;
        float pixelWidth=fwidth(axis)*edgeSoftness;
        float width=sqrt(square(max(.036,fwidth(axis)*1.25))+square(pixelWidth));
        width*=1.+highlightSoftness*.18;
        if(highlightWidth!=1.)width*=highlightWidth;
        float strip=exp(-square((axis-.24)/width));
        // A slight per-channel offset of the catch axis splits the brightest
        // reflections into a subtle prismatic fringe, like real curved glass.
        // Zero fringe reproduces the previous scalar highlight exactly.
        float fringe=.014*waveIridescence;
        vec3 stripRGB=waveIridescence>0.
          ? vec3(exp(-square((axis-.24+fringe)/width)),strip,exp(-square((axis-.24-fringe)/width)))
          : vec3(strip);
        float softbox=exp(-square((reflection.y+.49+.18*reflection.x)/.17));
        float secondaryWidth=sqrt(square(max(.055,fwidth(axis)*1.25))+square(pixelWidth))*(1.+highlightSoftness*.18);
        if(highlightWidth!=1.)secondaryWidth*=highlightWidth;
        float secondary=exp(-square((axis+.80)/secondaryWidth));
        float lengthFade=.55+.45*square(.5+.5*sin(sheet.x*3.8+sheet.y*.65));
        float edgeFade=1.-smoothstep(sony>.5?.72:.87,1.,abs(sheet.y));
        // Thin bright lines where the sheet folds back on itself: the normal
        // grazes the view there, so the strand follows real silhouettes.
        float strand=exp(-square((facing-.06)/.055))*waveStrands;
        vec3 cool=mix(vec3(.45,.47,.65),vec3(.65,.71,.88),mood);
        vec3 silver=mix(vec3(.82,.84,.97),vec3(.93,.96,1.),mood);
        // Tint both the body and every reflection, keeping colored highlights
        // from washing back to white. Strength zero is the original shader.
        cool=mix(cool,waveTintColor*.60,waveTintStrength);
        silver=mix(silver,waveTintColor,waveTintStrength);
        vec3 bodyCool=cool*mix(1.,.22,waveClear);
        silver*=mix(1.,.55,waveClear);
        vec3 reflected=bodyCool*(.016+.045*fresnel+.065*softbox)
          +silver*highlightIntensity*(.38*stripRGB+vec3(.12*secondary))*(.30+.70*fresnel)*lengthFade
          +silver*highlightIntensity*(.20*strand)*lengthFade;
        if(sony>.5){
          // Two reflected light panels produce a bright core and a softer
          // shoulder. Dark gaps between them keep the sheet optically clear.
          float broad=exp(-square((axis-.12)/.18));
          float catchWidth=sqrt(square(max(.026,fwidth(axis)*1.4))+square(pixelWidth))*(1.+highlightSoftness*.18);
          if(highlightWidth!=1.)catchWidth*=highlightWidth;
          float catchLight=exp(-square((axis-.27)/catchWidth));
          vec3 catchRGB=waveIridescence>0.
            ? vec3(exp(-square((axis-.27+fringe)/catchWidth)),catchLight,exp(-square((axis-.27-fringe)/catchWidth)))
            : vec3(catchLight);
          float shoulder=exp(-square((axis-.27)/.12));
          float backWidth=sqrt(square(max(.042,fwidth(axis)*1.4))+square(pixelWidth))*(1.+highlightSoftness*.18);
          if(highlightWidth!=1.)backWidth*=highlightWidth;
          float backLight=exp(-square((axis+.48)/backWidth));
          float drift=.65+.35*square(.5+.5*sin(sheet.x*3.1+sheet.y*.8+1.2));
          float grazing=.40+.60*fresnel;
          reflected=bodyCool*(.009+.065*broad+.018*fresnel)
            +silver*highlightIntensity*(.46*catchRGB+vec3(.22*shoulder+.14*backLight))*grazing*drift
            +silver*highlightIntensity*(.24*strand)*drift;

        }
        float weight=edgeFade*brightness;
        if(gloss!=1.)weight*=gloss;
        // Low absorption leaves the interior clear; reflections carry the form.
        float opacity=(sony>.5 ? .008+.012*(1.-fresnel) : .018+.035*(1.-fresnel))*edgeFade;
        if(glassOpacity!=1.)opacity*=glassOpacity;
        opacity*=mix(1.,.35,waveClear);
        // The same subpixel dither the background uses: smooth highlight
        // falloff over near-black would otherwise band on 8-bit panels.
        float dither=fract(52.9829189*fract(dot(gl_FragCoord.xy,vec2(.06711056,.00583715))))-.5;
        frag=vec4(max(reflected*weight+vec3(dither/255.),0.),opacity);

      }`);
    gl.attachShader(waveProgram,waveVS);gl.attachShader(waveProgram,waveFS);gl.linkProgram(waveProgram);
    if(!gl.getProgramParameter(waveProgram,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(waveProgram));
    gl.deleteShader(waveVS);gl.deleteShader(waveFS);
    const waveVAO=gl.createVertexArray();gl.bindVertexArray(waveVAO);
    const vb=gl.createBuffer(),ib=gl.createBuffer();let meshQuality='',indexCount=0,indexType=gl.UNSIGNED_SHORT;
    const at=gl.getAttribLocation(waveProgram,'grid');gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.enableVertexAttribArray(at);gl.vertexAttribPointer(at,2,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);
    function updateMesh(quality){if(quality===meshQuality)return;meshQuality=quality;
      const scale=quality==='ultra'?2:quality==='smooth'?1.5:1,nx=Math.round(192*scale),nz=Math.round(128*scale),count=(nx+1)*(nz+1),verts=new Float32Array(count*2);let i=0;
      for(let z=0;z<=nz;z++)for(let x=0;x<=nx;x++){verts[i++]=x/nx;verts[i++]=z/nz*2-1;}
      const inds=count>65535?new Uint32Array(nx*nz*6):new Uint16Array(nx*nz*6);i=0;
      for(let z=0;z<nz;z++)for(let x=0;x<nx;x++){const a=z*(nx+1)+x,b=a+1,c=a+nx+1,d=c+1;inds[i++]=a;inds[i++]=b;inds[i++]=c;inds[i++]=b;inds[i++]=d;inds[i++]=c;}
      gl.bindVertexArray(waveVAO);gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,verts,gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,inds,gl.STATIC_DRAW);indexCount=inds.length;indexType=count>65535?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT;window.waveStatus.meshVertices=count;
    }
    const scalarUniforms=['brightness','mood','waveMode','motionMode','waveAmplitude','waveFrequency','waveDetail','wavePosition','gloss','glassOpacity','highlightWidth','edgeSoftness','highlightSoftness','highlightIntensity','animationStrength','waveIridescence','waveStrands','waveClear','waveTintStrength'];
    const defaults={brightness:.98,mood:0,waveMode:0,motionMode:0,waveAmplitude:1,waveFrequency:1,waveDetail:1,wavePosition:0,gloss:1,glassOpacity:1,highlightWidth:1,edgeSoftness:1,highlightSoftness:1,highlightIntensity:1,animationStrength:1,waveIridescence:.35,waveStrands:.6,waveClear:0,waveTintStrength:0};
    const wu={};for(const name of ['waveTintColor','time','waveShape','motionParams','sony','worldX','worldY',...scalarUniforms])wu[name]=gl.getUniformLocation(waveProgram,name);
    const previousClip=[NaN,NaN,NaN,NaN],previousShape=[NaN,NaN,NaN,NaN],previousMotion=[NaN,NaN,NaN,NaN];
    const previousScalars={},previousTint=[NaN,NaN,NaN];
    let previousSony=NaN;
    function changed(values,previous) {
      let dirty=false;
      for(let i=0;i<previous.length;i++) if(previous[i]!==values[i]) {
        previous[i]=values[i];dirty=true;
      }
      return dirty;
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);
    window.waveStatus.antialiasSamples=gl.getParameter(gl.SAMPLES);
    updateMesh(window.SPLINE_SETTINGS.meshQuality||"smooth");
    window.waveStatus.colorBuffer='native MSAA';
    // Follow the same palette phase as the color-shifting background.
    function animatedTint(time){
      const a=window.BACKGROUND_MOTION_SETTINGS,colors=a.colors;
      const phase=((time%a.cycleLength)+a.cycleLength)%a.cycleLength/a.cycleLength;
      function palette(p){const slot=((p%1)+1)%1*4,i=Math.floor(slot),f=slot-i,t=f*f*(3-2*f);return colors[i].map((v,c)=>v+(colors[(i+1)%4][c]-v)*t);}
      const low=palette(.12),high=palette(phase+.12),color=low.map((v,c)=>v+(high[c]-v)*a.strength),peak=Math.max(...color);
      return peak>.0001?color.map(v=>v/peak):[.72,.78,.85];
    }
    return {render(time,target=null,backgroundTime=0){
      gl.bindFramebuffer(gl.FRAMEBUFFER,target);
      const s=window.SPLINE_SETTINGS;updateMesh(s.meshQuality||"smooth");
      gl.disable(gl.DEPTH_TEST);
      gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
      gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      gl.useProgram(waveProgram);gl.bindVertexArray(waveVAO);
      // Uniforms belong to this program even when particles use another one.
      // Only the motion clock changes on an ordinary animation frame.
      const sony=window.waveStatus.wavePreset==='sony'?1:0;
      if(sony!==previousSony) { gl.uniform1f(wu.sony,sony);previousSony=sony; }
      if(changed(s.waveShape,previousShape)) gl.uniform4fv(wu.waveShape,s.waveShape);
      if(changed(s.motionParams,previousMotion))gl.uniform4fv(wu.motionParams,s.motionParams);
      gl.uniform1f(wu.time,time);
      const tint=s.wavePaletteAnimated?animatedTint(backgroundTime):(s.waveTintColor||[1,1,1]);
      if(changed(tint,previousTint))gl.uniform3fv(wu.waveTintColor,tint);
      window.waveStatus.waveTintColor=tint;
      for(let i=0;i<scalarUniforms.length;i++){
        const name=scalarUniforms[i],value=s[name]??defaults[name];
        if(value!==previousScalars[name]){gl.uniform1f(wu[name],value);previousScalars[name]=value;}
      }
      const span=window.XMB_SPAN&&window.XMB_SPAN.active?window.XMB_SPAN:null;
      if(!span){
        // Single display: the caller's viewport and the cropped render band.
        if(changed([s.clipBounds[0],s.clipBounds[1],window.XMB_SPAN?.singleView?.x0??0,window.XMB_SPAN?.singleView?.xw??1],previousClip)){const view=window.XMB_SPAN?.singleView||{x0:0,xw:1};gl.uniform2f(wu.worldX,view.x0,view.xw);gl.uniform2f(wu.worldY,s.clipBounds[0],s.clipBounds[1]-s.clipBounds[0]);}
        gl.drawElements(gl.TRIANGLES,indexCount,indexType,0);
      }else{
        // Spanning: the same clock and settings draw one slice per display.
        previousClip.fill(NaN);
        for(const v of span.views){
          gl.viewport(v.viewport[0],v.viewport[1],v.viewport[2],v.viewport[3]);
          gl.uniform2f(wu.worldX,v.x0,v.xw);gl.uniform2f(wu.worldY,v.y0,v.yh);
          gl.drawElements(gl.TRIANGLES,indexCount,indexType,0);
        }
        gl.viewport(0,0,canvas.width,canvas.height);
      }
      gl.disable(gl.BLEND);gl.bindVertexArray(null);
    }};
  };
})();
