'use strict';
(() => {
 const api=window.XMBSettings,schema=window.XMB_SETTINGS_SCHEMA,bridge=window.XMB_BRIDGE;
 if(!api||!schema)return;
 // Category order for the PC layout: the look first, system settings last.
 const groups={
  'Wave & glass':['wavePreset','waveFinish','waveTint','waveColor','waveTintStrength','waveAmplitude','waveFrequency','waveDetail','wavePosition','brightness','gloss','glassOpacity','waveIridescence','waveStrands'],
  'Breathing glow':['breatheEnabled','breathePreset','breatheMode','breathePeriod','breatheIntensity','breatheMinimum','breatheWidth','breatheSoftness','breatheRadius','breatheThreshold','breatheTint','breatheColor'],
  'Displays':['spanDisplays','spanGap','spanVerticalOffset'],
  'Motion':['animationPreset','speed','animationStrength','animationDirection'],
  'Background':['backgroundMode','backgroundPreset','customBlend','gradientStart','gradientMiddle','gradientEnd','gradientAngle','backgroundExposure','backgroundRotation','backgroundBlackLevel'],
  'Color shifting':['shiftingPreset','shiftingStyle','shiftingSpeed','shiftingStrength','shiftingPeriod','shiftingAngle','shiftingSoftness','shiftingColor1','shiftingColor2','shiftingColor3','shiftingColor4'],
  'Particles':['particlePreset','particleDensity','particleSize','particleSpeed','sparkle','particleTint','particleColor'],
  'Glow & blur':['glow','glowRadius','glowThreshold','glowTint','glowColor','blur','blurQuality'],
  'Line smoothing':['antiAliasing','edgeSoftness','highlightSoftness','highlightIntensity','meshQuality','highlightWidth'],
  'Performance':['performancePreset','fpsMode','resolution','diagnosticsEnabled','advancedControls'],
  'Menu':['panelTransparency','panelWidth','panelHeight']
 };
 const panel=document.createElement('aside');panel.id='xmb-panel';panel.setAttribute('aria-label','Live XMB settings');panel.setAttribute('aria-hidden','true');
 // Two-pane PC layout: a category sidebar beside one page of settings, rather
 // than every section stacked in a single long scroll list.
 panel.innerHTML='<header><div class="eyebrow">lumaXMB Desktop Engine</div><h1>Settings</h1><p class="intro">Changes take effect immediately.</p><button class="close" aria-label="Close settings">×</button></header><div class="metrics"><div class="metric"><span>Render grid</span><strong id="xmb-size">—</strong></div><div class="metric"><span>Draw cadence</span><strong id="xmb-cadence">—</strong></div><div class="metric"><span>Anti-aliasing</span><strong id="xmb-aa">—</strong></div></div><div class="layout"><nav class="categories" role="tablist" aria-label="Settings categories"></nav><div class="pane"><input class="search" type="search" placeholder="Find a setting…" aria-label="Find a setting"><div class="scroll-shell"><div class="sections"></div><div class="scroll-track"><button class="scroll-thumb" aria-label="Drag to scroll"></button></div></div></div></div><footer><span class="sync">Connecting to sidebar…</span><span class="scroll-buttons"><button class="scroll-up" aria-label="Scroll up">↑</button><button class="scroll-down" aria-label="Scroll down">↓</button></span><button class="resize-handle" aria-label="Drag to resize menu" title="Drag to resize">⤢</button></footer>';
 document.body.appendChild(panel);
 const launch=document.createElement('button');launch.id='xmb-launch';launch.textContent='⚙';launch.title='Live XMB settings (S)';launch.setAttribute('aria-label','Open live XMB settings');launch.setAttribute('aria-expanded','false');launch.setAttribute('aria-controls','xmb-panel');document.body.appendChild(launch);
 const sync=panel.querySelector('.sync'),rows=new Map(),controls=new Map(),sections=panel.querySelector('.sections');
 let config=api.get(),pending={},sending=false,sendTimer=0,revision=-1,observed={},observeTimer=0,connected=false;
 const text=(tag,value,parent)=>{const e=document.createElement(tag);e.textContent=value;parent.appendChild(e);return e};
 const number=v=>String(Number(Number(v).toFixed(3)));
 const toHex=v=>'#'+String(v).split(/\s+/).map(n=>Math.round(Math.max(0,Math.min(1,Number(n)))*255).toString(16).padStart(2,'0')).join('');
 const toRGB=v=>[1,3,5].map(i=>parseInt(v.slice(i,i+2),16)/255).join(' ');
 const names={advancedControls:'Sidebar detail group',resolution:'Render scale',fpsMode:'Frame rate target'};
 const nav=panel.querySelector('.categories'),pages=new Map();
 // The last chosen category survives reloads; storage can be unavailable.
 let activePage=(()=>{try{const v=localStorage.getItem('xmb-panel-page');return v&&groups[v]?v:Object.keys(groups)[0];}catch(e){return Object.keys(groups)[0];}})();
 function selectPage(title,focusTab=false){
  activePage=title;try{localStorage.setItem('xmb-panel-page',title);}catch(e){}
  const search=panel.querySelector('.search');if(search.value){search.value='';}
  sections.scrollTop=0;filter();requestAnimationFrame(updateScrollThumb);
  if(focusTab)nav.querySelector('[data-title="'+CSS.escape(title)+'"]')?.focus();
 }
 for(const [title,keys] of Object.entries(groups)){
  const page=document.createElement('section');page.className='page';page.dataset.title=title;text('h2',title,page);sections.appendChild(page);pages.set(title,page);
  const tab=document.createElement('button');tab.type='button';tab.className='category';tab.dataset.title=title;tab.setAttribute('role','tab');tab.textContent=title;
  tab.addEventListener('click',()=>selectPage(title));
  tab.addEventListener('keydown',e=>{if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;const all=Object.keys(groups),i=all.indexOf(title),next=e.key==='Home'?0:e.key==='End'?all.length-1:Math.max(0,Math.min(all.length-1,i+(e.key==='ArrowDown'?1:-1)));selectPage(all[next],true);e.preventDefault();});
  nav.appendChild(tab);
  for(const key of keys){
   const spec=schema[key];if(!spec)continue;
   // Each row is label | control, aligned on a shared column like a PC settings page.
   const row=document.createElement('div');row.className='control';row.dataset.key=key;row.dataset.label=(names[key]||spec.text).toLowerCase();page.appendChild(row);rows.set(key,row);
   const label=document.createElement('label');label.htmlFor='xmb-'+key;label.textContent=names[key]||spec.text;row.appendChild(label);
   const field=document.createElement('div');field.className='field';row.appendChild(field);
   let input,extra;
   if(spec.type==='combo'){
    // CEF's native select widget can terminate the wallpaper renderer. Keep
    // the full picker in the document, with keyboard and screen reader support.
    input=document.createElement('button');input.type='button';input.className='picker';input.setAttribute('role','combobox');input.setAttribute('aria-expanded','false');input.setAttribute('aria-haspopup','listbox');input.setAttribute('aria-label',names[key]||spec.text);field.appendChild(input);
    const menu=document.createElement('div');menu.className='picker-menu';menu.hidden=true;menu.setAttribute('role','listbox');menu.id='xmb-options-'+key;input.setAttribute('aria-controls',menu.id);field.appendChild(menu);
    const choose=value=>{input.value=value;menu.hidden=true;input.setAttribute('aria-expanded','false');input.dispatchEvent(new Event('change'));input.focus();};
    for(const o of spec.options){const option=document.createElement('button');option.type='button';option.textContent=o.label;option.dataset.value=o.value;option.setAttribute('role','option');option.addEventListener('click',()=>choose(o.value));menu.appendChild(option);}
    input.addEventListener('click',()=>{const open=menu.hidden;for(const m of panel.querySelectorAll('.picker-menu'))m.hidden=true;for(const b of panel.querySelectorAll('.picker'))b.setAttribute('aria-expanded','false');menu.hidden=!open;input.setAttribute('aria-expanded',String(open));});
    input.addEventListener('keydown',e=>{if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){const i=spec.options.findIndex(o=>o.value===input.value),next=e.key==='Home'?0:e.key==='End'?spec.options.length-1:Math.max(0,Math.min(spec.options.length-1,i+(e.key==='ArrowDown'?1:-1)));choose(spec.options[next].value);e.preventDefault();}else if(e.key==='Escape'&&!menu.hidden){menu.hidden=true;input.setAttribute('aria-expanded','false');e.stopPropagation();}});
   }
   else if(spec.type==='slider'){field.classList.add('slider-field');input=document.createElement('input');input.type='range';input.min=spec.min;input.max=spec.max;input.step=spec.step;field.appendChild(input);extra=text('output','',field);}
   else if(spec.type==='bool'){row.classList.add('toggle');input=document.createElement('input');input.type='checkbox';field.appendChild(input);}
   else if(spec.type==='color'){const wrap=document.createElement('div');wrap.className='color-controls';field.appendChild(wrap);input=document.createElement('input');input.type='color';wrap.appendChild(input);extra=document.createElement('input');extra.type='text';extra.setAttribute('aria-label',(spec.text||key)+' hex or RGB values');extra.placeholder='#RRGGBB';extra.title='Enter #RRGGBB or three RGB values from 0 to 1';wrap.appendChild(extra);extra.addEventListener('change',()=>{const raw=extra.value.trim();const hex=/^#?[0-9a-f]{6}$/i.test(raw);const rgb=hex?toRGB('#'+raw.replace(/^#/,'')):raw;const values=rgb.split(/\s+/).map(Number);if(values.length===3&&values.every(v=>Number.isFinite(v)&&v>=0&&v<=1)){extra.removeAttribute('aria-invalid');change({[key]:rgb});}else extra.setAttribute('aria-invalid','true');});}
   input.id='xmb-'+key;input.dataset.key=key;controls.set(key,{input,extra});
   input.addEventListener(spec.type==='combo'?'change':'input',()=>{const value=spec.type==='slider'?Number(input.value):spec.type==='bool'?input.checked:spec.type==='color'?toRGB(input.value):input.value;change({[key]:value});});
  }
  if(title==='Performance')text('p','',page).className='profile-note';
  if(title==='Displays')text('p','',page).className='span-note';
 }
 function visible(key){
  if(key==='breatheEnabled'||key==='breathePreset')return true;
  if(key.startsWith('breathe'))return config.breatheEnabled&&(key!=='breatheColor'||config.breatheTint==='custom')&&(!['breatheWidth','breatheSoftness'].includes(key)||config.breatheMode!=='full');
  if(['customBlend','gradientStart','gradientMiddle','gradientEnd','gradientAngle'].includes(key))return config.backgroundMode==='static'&&config.backgroundPreset==='custom'&&(key!=='gradientMiddle'||config.customBlend!=='two');
  if(key==='backgroundPreset')return config.backgroundMode==='static';
  if(key.startsWith('shifting'))return config.backgroundMode==='shifting'&&(!/^shifting(Color|Angle)/.test(key)||config.shiftingPreset==='custom');
  if(key==='waveColor')return config.waveTint==='custom';
  if(key==='waveTintStrength')return config.waveTint!=='silver';
  if(key==='particleColor')return config.particleTint==='custom';if(key==='glowColor')return config.glowTint==='custom';return true;
 }
 let controlsSignature='',refreshQueued=false;
 function setOpen(open){panel.classList.toggle('open',open);document.body.classList.toggle('xmb-panel-open',open);panel.setAttribute('aria-hidden',String(!open));panel.inert=!open;launch.setAttribute('aria-expanded',String(open));}
 function scheduleRefresh(){if(refreshQueued)return;refreshQueued=true;queueMicrotask(()=>{refreshQueued=false;refresh();});}
 function refresh(){
  config=api.get();setOpen(Boolean(config.settingsPanel));
  // When one wave spans several displays the page covers all of them; keep the
  // menu and its launcher on the main display instead of the combined edge.
  const span=window.XMB_SPAN&&window.XMB_SPAN.active?window.XMB_SPAN.primaryCss:null;
  const area=span||{left:0,top:0,width:innerWidth,height:innerHeight};
  panel.style.right=(innerWidth-(area.left+area.width)+32)+'px';panel.style.top=(area.top+32)+'px';
  launch.style.right=(innerWidth-(area.left+area.width)+28)+'px';launch.style.bottom=(innerHeight-(area.top+area.height)+28)+'px';
  panel.style.setProperty("--surface-opacity",String(1-config.panelTransparency/100));panel.style.width=Math.min(config.panelWidth,area.width-48)+"px";panel.style.height=Math.min(config.panelHeight,area.height-48)+"px";
  // Narrow menus fold the sidebar into a wrapping tab strip above the page.
  panel.classList.toggle('compact',Math.min(config.panelWidth,area.width-48)<640);updateScrollThumb();
  const spanNote=panel.querySelector('.span-note');if(spanNote&&window.XMB_SPAN)spanNote.textContent=window.XMB_SPAN.reason+(window.XMB_SPAN.displays&&window.XMB_SPAN.displays.length?' Detected: '+window.XMB_SPAN.displays.join(', ')+'.':'');
  const {settingsPanel,...controlValues}=config,signature=JSON.stringify(controlValues);
  if(signature===controlsSignature)return;controlsSignature=signature;
  const effective=window.resolvePerformanceSettings(config);
  for(const [key,{input,extra}] of controls){const value=key==='glow'?effective.glow:key==='blur'?effective.blur:key==='resolution'?effective.resolution:key==='fpsMode'?String(effective.fps):config[key];
   if(input.type==='checkbox')input.checked=Boolean(value);
   else if(input.type==='color'){input.value=toHex(value);if(document.activeElement!==extra)extra.value=toHex(value).toUpperCase();}
   else{input.value=value;if(input.classList.contains('picker')){input.textContent=schema[key].options.find(o=>o.value===value)?.label||value;for(const option of input.nextElementSibling.children)option.setAttribute('aria-selected',String(option.dataset.value===value));}if(extra)extra.value=number(value);if(input.type==='range')input.style.setProperty('--fill',((value-Number(input.min))/(Number(input.max)-Number(input.min))*100)+'%');}
   input.disabled=false;
   rows.get(key).hidden=!visible(key);
  }
  const open=Boolean(config.settingsPanel);panel.classList.toggle('open',open);document.body.classList.toggle('xmb-panel-open',open);panel.setAttribute('aria-hidden',String(!open));panel.inert=!open;launch.setAttribute('aria-expanded',String(open));
  panel.querySelector('.profile-note').textContent=window.waveStatus.performance.description+' Frame targets also respect Wallpaper Engine’s global limit.';
  filter();requestAnimationFrame(updateScrollThumb);
 }
 // Browsing shows one category page; a search spans every category, with
 // each page title kept as a group heading over its matches.
 function filter(){
  const term=panel.querySelector('.search').value.trim().toLowerCase();
  for(const [key,row] of rows)row.hidden=!visible(key)||Boolean(term&&!row.dataset.label.includes(term));
  for(const [title,page] of pages){const any=Array.from(page.querySelectorAll('.control')).some(r=>!r.hidden);page.hidden=term?!any:title!==activePage;}
  for(const tab of nav.children){const on=!term&&tab.dataset.title===activePage;tab.classList.toggle('active',on);tab.setAttribute('aria-selected',String(on));tab.tabIndex=on||(term&&tab===nav.firstElementChild)?0:-1;}
  panel.classList.toggle('searching',Boolean(term));
 }
 function status(message,error=false){sync.textContent=message;sync.classList.toggle('error',error);}
 async function request(route,body){const response=await fetch(bridge.url+route,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-XMB-Token':bridge.token},...(body?{body:JSON.stringify(body)}:{})});const result=await response.json();if(!response.ok)throw Error(result.error||'Sidebar unavailable');return result;}
 function change(values){
  if('settingsPanel' in values)setOpen(Boolean(values.settingsPanel));
  const current=api.get();
  if(current.performancePreset!=='custom'&&['fpsMode','resolution','glow','blur'].some(k=>k in values)){
   const effective=window.resolvePerformanceSettings(current);
   values={performancePreset:'custom',fpsMode:String(effective.fps),resolution:effective.resolution,glow:effective.glow,blur:effective.blur,particleDensity:Math.max(.2,current.particleDensity*effective.particleScale),...values};
  }
  api.set(values,'panel');const normalized=api.get();Object.assign(pending,Object.fromEntries([...new Set([...Object.keys(values),...Object.keys(normalized).filter(key=>normalized[key]!==current[key])])].map(key=>[key,normalized[key]])));clearTimeout(sendTimer);sendTimer=setTimeout(flush,70);
 }
 async function flush(){
  if(sending)return;if(!Object.keys(pending).length)return;
  const values=pending;pending={};sending=true;status('Saving to sidebar…');
  try{const result=await request('/properties',values);revision=result.revision;connected=true;status('Synced with sidebar');}
  catch(e){Object.assign(pending,values,pending);connected=false;status('Live preview · sidebar unavailable',true);}
  finally{sending=false;if(Object.keys(pending).length&&connected)sendTimer=setTimeout(flush,70);}
 }
 window.addEventListener('xmb-settings',e=>{
  scheduleRefresh();if(e.detail.source==='host'){
   // Echo host changes to the companion, never back to Wallpaper Engine.
   const values=Object.fromEntries(Object.keys(e.detail.props).filter(k=>k in schema).map(k=>[k,api.get()[k]]));
   Object.assign(observed,values);clearTimeout(observeTimer);observeTimer=setTimeout(async()=>{const values=observed;observed={};try{const result=await request('/observed',values);revision=result.revision;connected=true;status('Synced with sidebar');}catch(e){Object.assign(observed,values,observed);status('Live preview · sidebar unavailable',true);}},100);
  }
 });
 async function poll(){
  try{if(Object.keys(pending).length&&!sending)await flush();if(!sending&&!Object.keys(pending).length){const result=await request('/state');window.XMBDisplays?.accept(result.displayLayout);if(revision!==result.revision){api.set(result.values,'bridge');revision=result.revision;}connected=true;status('Synced with sidebar');}}
  catch(e){connected=false;status('Live preview · sidebar unavailable',true);}
  setTimeout(poll,750);
 }
 let wheelEvents=0,bridgeWheelEvents=0;
 panel.addEventListener('wheel',e=>{wheelEvents++;
  if(!api.get().settingsPanel||!e.deltaY)return;
  const menu=e.target.closest('.picker-menu'),scroller=menu&&!menu.hidden?menu:sections;
  const delta=e.deltaY*(e.deltaMode===1?24:e.deltaMode===2?scroller.clientHeight:1);
  scroller.scrollTop+=delta;e.preventDefault();e.stopPropagation();
 },{passive:false});
 sections.tabIndex=0;sections.setAttribute('aria-label','Scrollable settings');
 launch.addEventListener('click',()=>{change({settingsPanel:!api.get().settingsPanel});if(api.get().settingsPanel)panel.querySelector('.close').focus();});
 panel.querySelector('.close').addEventListener('click',()=>{change({settingsPanel:false});launch.focus();});panel.querySelector('.search').addEventListener('input',filter);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&api.get().settingsPanel){change({settingsPanel:false});launch.focus();}else if(e.key.toLowerCase()==='s'&&!e.ctrlKey&&!e.altKey&&!/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)){change({settingsPanel:!api.get().settingsPanel});e.preventDefault();}});
 let metricFrames=window.waveStatus.frames,metricTime=window.performance.now();
 function metrics(){const now=window.performance.now(),s=window.waveStatus,elapsed=now-metricTime,fps=(s.frames-metricFrames)*1000/elapsed;metricFrames=s.frames;metricTime=now;
  panel.querySelector('#xmb-size').textContent=(s.fullRenderSize||s.backgroundRenderSize).join(' × ');
  panel.querySelector('#xmb-cadence').textContent=s.paused?'Paused':fps.toFixed(1)+' fps';
  panel.querySelector('#xmb-aa').textContent=s.effects.warning?'AA unavailable':s.effects.sceneSamples?s.effects.sceneSamples+'× MSAA · local':'Off · local';
  // Keep one local measurement available after the temporary debugger is off.
  request('/telemetry',{panel:{open:api.get().settingsPanel,rect:(()=>{const r=panel.getBoundingClientRect();return {left:r.left/innerWidth,top:r.top/innerHeight,right:r.right/innerWidth,bottom:r.bottom/innerHeight};})(),viewport:[innerWidth,innerHeight],scrollTop:sections.scrollTop,scrollHeight:sections.scrollHeight,clientHeight:sections.clientHeight,transparency:api.get().panelTransparency,width:panel.clientWidth,height:panel.clientHeight,wheelEvents,bridgeWheelEvents,meshVertices:s.meshVertices,aaRequested:s.effects.requestedSamples,aaIndependent:s.effects.independentAA,aaWarning:s.effects.warning},time:Date.now(),drawFps:fps,frames:s.frames,paused:s.paused,nativeSize:s.nativeSize,fullRenderSize:s.fullRenderSize,backgroundRenderSize:s.backgroundRenderSize,waveRenderSize:s.renderSize,msaa:s.effects.active?s.effects.sceneSamples:s.antialiasSamples,target:s.targetFps,desktopXmb:s.desktopXmb,displayMapping:s.span,displayTransition:window.XMBDisplayRuntime?.stats(),breathingGlow:s.breathingGlow,breathingRuntime:s.effects.breathing,waveAppearance:s.waveAppearance,waveTintColor:s.waveTintColor,physicalPresentationMeasured:false}).catch(()=>{});
  setTimeout(metrics,1000);
 }
 const track=panel.querySelector('.scroll-track'),thumb=panel.querySelector('.scroll-thumb');
 function updateScrollThumb(){
  if(!track)return;const total=sections.scrollHeight,visible=sections.clientHeight,travel=track.clientHeight;
  const height=Math.max(36,travel*visible/Math.max(total,1));thumb.style.height=Math.min(travel,height)+'px';thumb.style.top=(travel-height)*sections.scrollTop/Math.max(1,total-visible)+'px';track.hidden=total<=visible;
 }
 sections.addEventListener('scroll',updateScrollThumb,{passive:true});sections.addEventListener('toggle',()=>requestAnimationFrame(updateScrollThumb),true);
 new ResizeObserver(updateScrollThumb).observe(sections);
 panel.querySelector('.scroll-up').addEventListener('click',()=>{sections.scrollTop-=sections.clientHeight*.7;});panel.querySelector('.scroll-down').addEventListener('click',()=>{sections.scrollTop+=sections.clientHeight*.7;});
 let drag=null;
 function beginDrag(e,kind){if(e.button!==0)return;e.preventDefault();drag={kind,x:e.clientX,y:e.clientY,width:panel.clientWidth,height:panel.clientHeight,scroll:sections.scrollTop};}
 thumb.addEventListener('mousedown',e=>{e.stopPropagation();beginDrag(e,'scroll');});
 track.addEventListener('mousedown',e=>{if(e.target===thumb)return;const rect=track.getBoundingClientRect();sections.scrollTop=(e.clientY-rect.top)/rect.height*(sections.scrollHeight-sections.clientHeight);});
 panel.querySelector('.resize-handle').addEventListener('mousedown',e=>beginDrag(e,'resize'));
 document.addEventListener('mousemove',e=>{
  if(!drag)return;e.preventDefault();
  if(drag.kind==='scroll'){const travel=track.clientHeight-thumb.clientHeight;sections.scrollTop=drag.scroll+(e.clientY-drag.y)/Math.max(1,travel)*(sections.scrollHeight-sections.clientHeight);}
  else{const width=Math.round(Math.max(360,Math.min(1600,innerWidth-48,drag.width+drag.x-e.clientX))/10)*10,height=Math.round(Math.max(420,Math.min(1800,innerHeight-48,drag.height+e.clientY-drag.y))/10)*10;
   // Reflow the menu immediately. Save size after the drag, avoiding disk writes during movement.
   api.set({panelWidth:width,panelHeight:height},'resize');}
 });
 document.addEventListener('mouseup',()=>{if(!drag)return;if(drag.kind==='resize')change({panelWidth:api.get().panelWidth,panelHeight:api.get().panelHeight});drag=null;});
 window.addEventListener('blur',()=>{drag=null;});window.addEventListener('resize',()=>{controlsSignature='';refresh();});window.addEventListener('xmb-viewport',()=>{controlsSignature='';refresh();});
 let lastInput=0;
 async function pollDesktopInput(){
  if(api.get().settingsPanel)try{
   const result=await request('/input');
   for(const event of result.events||[]){if(event.id<=lastInput)continue;lastInput=event.id;if(event.time<performance.timeOrigin)continue;
    const target=document.elementFromPoint(event.x*innerWidth,event.y*innerHeight);if(!target||!panel.contains(target))continue;
    const menu=target.closest('.picker-menu');(menu&&!menu.hidden?menu:sections).scrollTop+=event.delta;bridgeWheelEvents++;
   }
  }catch(e){}
  setTimeout(pollDesktopInput,api.get().settingsPanel?40:500);
 }
 pollDesktopInput();

 refresh();metrics();
 // Let the host's initial property callback arrive before companion polling.
 setTimeout(async()=>{try{await request('/observed',api.get());}catch(e){}poll();},600);
})();
