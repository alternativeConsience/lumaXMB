'use strict';
// Retain a composited frame during framebuffer resizing. The retained frame
// uses cover/crop (never stretch), and is replaced on rapid retargeting.
window.createDisplayTransition=function(){
 let overlay=null,timer=0,count=0;
 function cover(ctx,image,w,h){const scale=Math.max(w/image.width,h/image.height),sw=w/scale,sh=h/scale;ctx.drawImage(image,(image.width-sw)/2,(image.height-sh)/2,sw,sh,0,0,w,h);}
 return {capture({width,height,background,wave,backgroundBounds,waveBounds}){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){clearTimeout(timer);overlay?.remove();overlay=null;return;}
  if(!width||!height)return;
  const retained=document.createElement('canvas');retained.width=width;retained.height=height;
  const ctx=retained.getContext('2d',{alpha:false});if(!ctx)return;
  ctx.fillStyle='#000';ctx.fillRect(0,0,width,height);
  ctx.drawImage(background,0,backgroundBounds[0]*height,width,(backgroundBounds[1]-backgroundBounds[0])*height);
  ctx.drawImage(wave,0,waveBounds[0]*height,width,(waveBounds[1]-waveBounds[0])*height);
  if(overlay){ctx.globalAlpha=Number(getComputedStyle(overlay).opacity);cover(ctx,overlay,width,height);ctx.globalAlpha=1;overlay.remove();}
  clearTimeout(timer);overlay=retained;count++;
  retained.id='xmb-display-transition';retained.setAttribute('aria-hidden','true');
  retained.style.cssText='position:fixed;inset:0;width:100%;height:100%;object-fit:cover;object-position:center;pointer-events:none;z-index:2;opacity:1;transition:opacity 360ms ease;';
  document.body.appendChild(retained);
 },reveal(){
  if(!overlay)return;const current=overlay;current.getBoundingClientRect();
  requestAnimationFrame(()=>{if(overlay===current)current.style.opacity='0';});
  timer=setTimeout(()=>{current.remove();if(overlay===current)overlay=null;},420);
 },stats(){return {active:!!overlay,count,rendererRestarted:false};},dispose(){clearTimeout(timer);overlay?.remove();overlay=null;}};
};
